/**
 * slots
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SlotsTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 下限 */
	public int slotsNum;
		/** 下限 */
	public int turn;
		/** 种类 */
	public int type;
		/** 支付表所在页数，0：不显示，1：第一页，2：第二页 */
	public int pages;
	
}