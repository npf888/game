/**
 * AchievementTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class AchievementTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 客户端类型 */
	public int clientType;
		/** 服务器类型 */
	public int serverType;
		/** 小类型 */
	public int smallType;
		/** 参数类型  1 单个 2 多个 */
	public int paramType;
		/** 条件一 */
	public int condition1;
		/** 条件二 */
	public int condition2;
		/** 奖励类型 */
	public int reward1Id;
		/** 奖励数量 */
	public int reward1Num;
		/** 奖励类型 */
	public int reward2Id;
		/** 奖励数量 */
	public int reward2Num;
	
}