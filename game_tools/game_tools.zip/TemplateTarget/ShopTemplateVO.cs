/**
 * 商品
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ShopTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 分类 */
	public int category;
		/** 金钱类型 */
	public int currencyType;
		/** 分类 */
	public int smallCategory;
		/** 花费数量 */
	public int num;
		/** 道具id */
	public int itemId;
		/** 道具数量 */
	public int itemNum;
		/** 额外比例 万分比 */
	public int upRate;
	
}