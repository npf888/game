/**
 * levelGift.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class LevelGiftVO
{
		/** 策划表数据主键 */
	public int id;
		/** 达到等级 */
	public int level;
		/** 奖励ID 3为金钱 */
	public int reward1Id;
		/** 金钱数1 */
	public int reward1Num;
		/** 奖励ID 3为金钱 */
	public int reward2Id;
		/** 金钱数2 */
	public int reward2Num;
		/** 奖励ID 3为金钱 */
	public int reward3Id;
		/** 金钱数3 */
	public int reward3Num;
	
}