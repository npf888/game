/**
 * viproom
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class VipRoomTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** vip等级 */
	public int smallBlind;
		/** 服务费1 */
	public int serviceValue1;
		/** 筹码 */
	public int watchNum;
		/** 赠送经验 */
	public int serviceValue2;
		/** 经验速度 */
	public int victoryExp;
		/** 魅力值 */
	public int joinExp;
		/** 每天奖励 */
	public int dealerCost;
		/** 房间人数 */
	public int roomNum;
		/** 最小携带 */
	public int minCarry;
		/** 最大携带 */
	public int maxCarry;
	
}