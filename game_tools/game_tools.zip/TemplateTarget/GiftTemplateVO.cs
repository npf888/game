/**
 * GiftTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class GiftTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 描述 */
	public string langDesc;
		/** 图片 */
	public string icon;
		/** 礼包类型 1 商店礼包 2新手礼包 3 多种礼包 */
	public int giftType;
		/** 等级下限 */
	public int levelDown;
		/** 等级上限 */
	public int levelUp;
		/** vip等级限制 */
	public int vipLevel;
		/** 礼包1 */
	public int gift1;
		/** 礼包2 */
	public int gift2;
		/** 礼包3 */
	public int gift3;
		/** 非VIP持续时间 */
	public int noVipGiftTime;
		/** VIP持续时间 */
	public int vipGiftTime;
		/** 没钱持续时间 */
	public int noMoneyInGame;
		/**  */
	public int buyTimes;
	
}