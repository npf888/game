/**
 * ClubTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ClubTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 俱乐部等级 */
	public int clubLevel;
		/** 最大人数 */
	public int cluNum;
		/** 捐献数量min */
	public int donateMin;
		/** 捐献数量max */
	public int donateMax;
		/** 捐献数量max */
	public int donate;
		/** 捐献间隔 */
	public int donateTime;
		/** 好友活跃度 */
	public int inviteActive;
		/** 签到活跃度 */
	public int signActive;
		/** 签到刷新时间 */
	public int signTime;
		/** 转化率 */
	public int convert;
		/** 赛季持续时间 */
	public int rankTime;
		/** 创建消耗 */
	public int clubFound;
		/** 名字长度 */
	public int clubName;
		/** 描述长度 */
	public int clubDescribe;
		/** 留言板条数 */
	public int clubBoard;
		/** 俱乐部申请上线 */
	public int clubapply;
		/** 消息存放时间 */
	public int newtime;
		/** 副会长人数 */
	public int deputy;
		/** 消息存放上限 */
	public int newmax;
		/** 俱乐部被申请上限 */
	public int clubapplied;
		/** 弹劾失败冷却时间 */
	public int accusetime;
		/** 申请冷却时间 */
	public int invitetime;
		/** 赛季结算获得奖励最低活跃值 */
	public int activelimit;
	
}