/**
 * ShavePrizeTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ShavePrizeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 奖池类型 */
	public int poolType;
		/** 物品ID */
	public int itemID;
		/** 数量 */
	public int rewardNum;
		/** 权重 */
	public int probability;
	
}