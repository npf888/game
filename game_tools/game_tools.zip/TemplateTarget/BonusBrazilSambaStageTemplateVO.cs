/**
 * BonusBrazilSambaStageTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusBrazilSambaStageTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 作者: 力度条颜色 （前端上传）1：黄色 2：黄绿色 3：绿色 */
	public int velocity;
		/** 1.奖励类型 */
	public int type;
		/** 单线下注额倍数,(百分比，实际值除以100） */
	public int reward;
		/** 权值 */
	public int weight;
	
}