/**
 * NoviceSlotsTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class NoviceSlotsTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/**  */
	public string langDesc;
		/** 老虎机编号 */
	public int slotNum;
		/**  */
	public int step;
		/** 机器线数 */
	public int payLinesNum;
		/**  */
	public int bet1;
		/**  */
	public int bet2;
		/**  */
	public int bet3;
		/**  */
	public int bet4;
		/**  */
	public int bet5;
		/** 下注额度 */
	public int bet;
		/** 线数倍数 */
	public int WinNum;
		/**  */
	public int openLv;
		/** 线类型 */
	public int lineType;
		/** 转动后卷轴位置 */
	public int firstReel1;
		/** 转动后卷轴位置 */
	public int firstReel2;
		/** 转动后卷轴位置 */
	public int firstReel3;
		/** 转动后卷轴位置 */
	public int firstReel4;
		/** 转动后卷轴位置 */
	public int firstReel5;
	
}