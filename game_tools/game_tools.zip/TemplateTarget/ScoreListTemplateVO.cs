/**
 * ScoreListTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScoreListTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 段位 */
	public int grades;
		/** 星级 */
	public int starLv;
		/**  */
	public int rewardId;
		/**  */
	public int rewardNum;
		/** 积分下限 */
	public int scoreLower;
		/** 积分上限 */
	public int scoreUpper;
		/** 0没有奖励 1有奖励 */
	public int rewardState;
	
}