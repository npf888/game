/**
 * SlotJackpot
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SlotJackpotTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string langDesc;
		/** 老虎机ID */
	public int slotId;
		/** 转轴图案组合ID */
	public int payId;
		/** 老虎机下注额ID */
	public int bet;
		/** 彩金池获奖比例 万分比 */
	public int rewardPer;
		/** 5个jackPort彩金 */
	public int jackpotPer;
	
}