/**
 * BounsElephont1RewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsElephont1RewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机编号类型 */
	public int slotsNum;
		/** bouns个数 */
	public int stage;
		/** 初始选择次数 */
	public int type;
		/** 两个相同元素 取 reward的值, 要根据 typeNum的数量来定 */
	public int reward;
		/** 初始选择次数 */
	public int weight;
		/** 同类型元素数量 */
	public int typeNum;
	
}