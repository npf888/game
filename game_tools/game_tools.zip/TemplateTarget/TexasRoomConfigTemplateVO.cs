/**
 * 德州配置
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class TexasRoomConfigTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 房间等待时间 */
	public int waitingTime;
		/** 玩家行为时间 */
	public int actTime;
		/** 下盘开始时间 */
	public int nextTime;
		/** preflop时间 */
	public int preflopTime;
		/** flop时间 */
	public int flopTime;
		/** turn时间 */
	public int turnTime;
		/** river时间 */
	public int riverTime;
		/** 比牌时间 */
	public int compareTime;
		/** 结算时间 */
	public int settleTime;
		/** 震动时间 */
	public int vibrationTime;
	
}