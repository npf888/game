/**
 * NoviceStepTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class NoviceStepTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string stepDesc;
		/** 步骤 */
	public int step;
		/** 小步 */
	public int substep;
	
}