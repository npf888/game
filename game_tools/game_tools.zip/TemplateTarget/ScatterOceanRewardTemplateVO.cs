/**
 * ScatterOceanRewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScatterOceanRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 老虎机类型 */
	public int slotsNum;
		/** 玩家所选乌龟的排名 */
	public int rank;
		/** 翻开贝壳后的奖励，单线下注额的倍数，数值除以100使用 */
	public int rewardNum;
		/** 权值 */
	public int value;
	
}