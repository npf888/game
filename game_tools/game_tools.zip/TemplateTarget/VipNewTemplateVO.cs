/**
 * vipnew
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class VipNewTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** vip等级 */
	public int vipLv;
		/** vip最大点 */
	public int vipPoint;
		/** 是否开启表情 */
	public int expression;
		/** vip房间 */
	public int vipRoom;
		/** 连赢次数 */
	public int winTimes;
		/** 购买加成比例 */
	public float buyingRatio;
		/** vip点数加成 */
	public int vipPointRatio;
		/** 签到加成 */
	public int siginRatio;
		/** 百家乐明灯复活权限 */
	public int beaconRevive;
		/** vip加成系数 */
	public int dailyreward;
	
}