/**
 * DailyTaskLevel
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class DailyTaskLevelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** 最大分类 */
	public int categoryMissionLevel;
		/** 随机个数 */
	public int num;
	
}