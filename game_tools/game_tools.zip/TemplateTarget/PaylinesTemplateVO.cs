/**
 * pay lines
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class PaylinesTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 下限 */
	public int position1;
		/** 下限 */
	public int position2;
		/** 下限 */
	public int position3;
		/** 下限 */
	public int position4;
		/** 下限 */
	public int position5;
		/** 连线类型 1：3*5老虎机 2： 4*5老虎机 */
	public int lineType;
	
}