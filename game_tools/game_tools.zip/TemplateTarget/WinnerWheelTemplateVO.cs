/**
 * WinnerWheelTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class WinnerWheelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 客户端类型 */
	public int itemId;
		/** 服务器类型 */
	public int itemMul;
		/** 转盘1权值 */
	public int value1;
		/** 转盘2权值 */
	public int value2;
		/** 转盘3权值 */
	public int value3;
		/** 转盘4权值 */
	public int value4;
		/** 转盘5权值 */
	public int value5;
		/** 转盘6权值 */
	public int value6;
	
}