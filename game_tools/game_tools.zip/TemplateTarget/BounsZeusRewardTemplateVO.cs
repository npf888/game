/**
 * BounsZeusRewardTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsZeusRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 多语言描述 */
	public string langDesc;
		/** 老虎机编号类型 */
	public int slotsNum;
		/** 类型 1 单线压住额倍数 , 2 增加免费次数 */
	public int type;
		/** 数据都除100 */
	public double times;
		/** 权重 */
	public int weight;
	
}