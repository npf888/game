/**
 * 游戏
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class CityTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 城镇名称多语言Id */
	public int cityNameLangId;
		/** 城镇名称 */
	public string cityName;
		/** 下一个场景id */
	public int nextCityId;
		/** 城镇最低等级 */
	public int minLevel;
		/** 城镇最高等级 */
	public int maxLevel;
		/** 城镇场景名 */
	public string citySceneName;
		/** 需求任务ID */
	public int needTaskId;
		/** 背景场景 */
	public string backgroundScence;
	
}