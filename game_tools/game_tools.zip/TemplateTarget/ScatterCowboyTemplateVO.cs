/**
 * ScatterCowboyTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScatterCowboyTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机类型 */
	public int slotsNum;
		/** scatterNum */
	public int scatterNum;
		/** 1 总线中奖翻倍 2 免费次数 3 金矿游戏 */
	public int gameType;
		/**  */
	public int rewardNum;
	
}