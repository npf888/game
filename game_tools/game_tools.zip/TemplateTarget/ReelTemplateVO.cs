/**
 * reel
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ReelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机 */
	public int slotsNum;
		/** 位置 */
	public int turn;
		/** 卷轴1 */
	public int reel1;
		/** 卷轴2 */
	public int reel2;
		/** 卷轴3 */
	public int reel3;
		/** 卷轴4 */
	public int reel4;
		/** 卷轴5 */
	public int reel5;
		/** 等级下限 */
	public int levelDown;
		/** 等级上限 */
	public int levelUp;
	
}