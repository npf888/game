/**
 * MultipleWheel.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class MultipleWheelVO
{
		/** 策划表数据主键 */
	public int id;
		/**  */
	public int type;
		/** 多语言描述id */
	public string descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 翻倍倍数 */
	public int multiple;
		/** 权重 */
	public int value;
		/** PID */
	public int pidID;
	
}