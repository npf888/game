/**
 * ExchangeTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ExchangeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 消耗类型 */
	public int itemId;
		/** 数量 */
	public int consumeCount;
		/** 物品ID */
	public int exchangeID;
		/** 数量 */
	public int exchangeCount;
		/** 类型 */
	public int sort;
	
}