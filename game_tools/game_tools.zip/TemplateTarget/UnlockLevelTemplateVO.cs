/**
 * UnlockLevelTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class UnlockLevelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 俱乐部解锁 */
	public int clubunlock;
		/** 收集解锁 */
	public int collection;
	
}