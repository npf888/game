/**
 * BonusStoneAgePreyTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusStoneAgePreyTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 捕住猎物的个数，最终奖励为：个数*单个倍数 */
	public int PreyNum;
		/** 权值 */
	public int weight;
	
}