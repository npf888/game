/**
 * WinMultipleTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class WinMultipleTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 倍数 */
	public int times;
		/** 权重 */
	public int weight;
	
}