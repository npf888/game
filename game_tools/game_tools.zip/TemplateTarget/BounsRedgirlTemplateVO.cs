/**
 * BounsRedgirlTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsRedgirlTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机类型 */
	public int slotsNum;
		/** bonus元素个数 */
	public int bonusNum;
		/** 初始选取次数 */
	public int selectNum;
	
}