/**
 * BounsGame
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsGameTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 1 单线下注额 2 总下注额 */
	public int type;
		/** 倍数 */
	public int times;
		/** 权重 */
	public int weight;
	
}