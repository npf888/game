/**
 * BounsPirate1Step1Template.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsPirate1Step1TemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** 奖励类型： 0.金币  1.炮弹 */
	public int type;
		/** 炮弹的数量或者炮弹个数 */
	public int num;
		/** 免费转动次数 */
	public int weight;
	
}