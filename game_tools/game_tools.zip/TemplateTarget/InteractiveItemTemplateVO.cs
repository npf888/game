/**
 * interactiveItem
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class InteractiveItemTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 语言Id */
	public int nameId;
		/** 名称 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** 图标 */
	public string icon;
		/** 花费筹码 */
	public int costChips;
		/** 魅力值改变 */
	public int changeCharm;
		/** 品质 */
	public int quality;
	
}