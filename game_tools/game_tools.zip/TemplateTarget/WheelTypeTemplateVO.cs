/**
 * WheelType
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class WheelTypeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 1 gold 2 free */
	public int type;
		/** 权重 */
	public int weight;
	
}