/**
 * CategoryLevel
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class CategoryLevelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public string descrip;
		/** 第二大分类 */
	public int category;
		/** 最大分类 */
	public int categoryMissionLevel;
		/** 随机个数 */
	public int num;
	
}