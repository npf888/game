/**
 * 累计签到
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class CumulativeSignInTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 天数 */
	public int day;
		/** 道具id */
	public int itemId;
		/** 道具 */
	public int itemNum;
	
}