/**
 * 角色经验
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class RoleExpTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 角色经验 */
	public long exp;
		/** 角色升级奖励筹码 */
	public int rewardChips;
	
}