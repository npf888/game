/**
 * Jackpot
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class JackpotTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 下限 */
	public int downLimit;
		/** 上限 */
	public int upLimit;
		/** 比例1 */
	public int ratio1;
		/** 比例2 */
	public int ratio2;
		/** 比例3 */
	public int ratio3;
		/** 几率1 */
	public int chance1;
		/** 几率2 */
	public int chance2;
		/** 几率3 */
	public int chance3;
		/** 复活1 */
	public int reviveNum1;
		/** 复活2 */
	public int reviveNum2;
		/** 复活3 */
	public int reviveNum3;
		/** 复活4 */
	public int reviveNum4;
		/** 复活5 */
	public int reviveNum5;
		/** 复活6 */
	public int reviveNum6;
		/** 复活7 */
	public int reviveNum7;
		/** 复活8 */
	public int reviveNum8;
		/** 复活9 */
	public int reviveNum9;
	
}