/**
 * ScoreListRewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScoreListRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 名次 */
	public int list1;
		/** 名次 */
	public int list2;
		/**  */
	public int reward;
		/**  */
	public int rewardNum;
	
}