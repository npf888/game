/**
 * slots list
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SlotsListTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 下限 */
	public int payLinesNum;
		/** 下注1 */
	public int bet1;
		/** 下注2 */
	public int bet2;
		/** 下注3 */
	public int bet3;
		/** 下注4 */
	public int bet4;
		/** 下注5 */
	public int bet5;
		/** 卷轴1随机数范围 */
	public int reel1Num;
		/** 卷轴2随机数范围 */
	public int reel2Num;
		/** 卷轴3随机数范围 */
	public int reel3Num;
		/** 卷轴4随机数范围 */
	public int reel4Num;
		/** 卷轴5随机数范围 */
	public int reel5Num;
		/** 行数 */
	public int rows;
		/** 列数 */
	public int columns;
		/** 列数 */
	public int bigWinNum;
		/** 列数 */
	public int megaWinNum;
		/** 列数 */
	public int superWinNum;
		/** 列数 */
	public int epicWinNum;
		/** 进入等级 */
	public int openLv;
		/** 类型 */
	public int type;
		/** 显示类型 */
	public int list;
		/** 房间是否开jackpot 1.开 2.关 */
	public int jackpotswitch;
		/** 压注最小等级 */
	public int bet1Lv;
		/** 压注最小等级 */
	public int bet2Lv;
		/** 压注最小等级 */
	public int bet3Lv;
		/** 压注最小等级 */
	public int bet4Lv;
		/** 压注最小等级 */
	public int bet5Lv;
		/** 彩金初始值 */
	public int jackpotOriValue;
		/** 彩金初始值 */
	public int jackpotOriValue1;
		/** 彩金初始值 */
	public int jackpotOriValue2;
		/** 彩金初始值 */
	public int jackpotOriValue3;
		/** 彩金初始值 */
	public int jackpotOriValue4;
		/** 彩金初始值 */
	public int jackpotOriValue5;
		/**  */
	public int jackpotPoolPer;
		/**  */
	public int jackpotAddPoolPer;
		/** 添加奖池比例 */
	public int raceReward;
		/** 第一名获得比例 */
	public int firstReward;
		/** 第二名获得比例 */
	public int secondReward;
		/** 第三名获得比例 */
	public int thirdReward;
		/** 连线类型 1：3*5老虎机 2： 4*5老虎机 */
	public int lineType;
		/** 初始坐标 */
	public int firstReel1;
		/** 初始坐标 */
	public int firstReel2;
		/** 初始坐标 */
	public int firstReel3;
		/** 初始坐标 */
	public int firstReel4;
		/** 初始坐标 */
	public int firstReel5;
		/** 游戏类型 1 普通scatter 2 表示 大转盘玩法 */
	public int gameType;
		/** 物品ID */
	public int ticketID;
		/** 出现的次数 */
	public int count1;
		/** 摇的次数 */
	public int count2;
	
}