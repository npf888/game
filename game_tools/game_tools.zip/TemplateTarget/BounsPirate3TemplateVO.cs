/**
 * BounsPirate3Template.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsPirate3TemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/**  */
	public string icon;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** bonus的数量 */
	public int bonusNum;
	
}