/**
 * CountryTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class CountryTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 国家编号 */
	public string country;
		/** 对应中文名称 */
	public string langDesc;
		/** 国家对应的icon */
	public string icon;
		/** 国家名称 */
	public int nameId;
	
}