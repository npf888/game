/**
 * WinnerWheelConfigTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class WinnerWheelConfigTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 转盘编号 */
	public int wheeltype;
		/** 金币区间开始 */
	public long start;
		/** 金币区间结束 */
	public long end;
		/** 中奖开关 0.关 1.开 */
	public int bigswitch;
		/** 中奖开关 0.关 1.开 */
	public int megaswitch;
		/** 中奖开关 0.关 1.开 */
	public int superswitch;
		/** 中奖开关 0.关 1.开 */
	public int epicswitch;
		/** 中奖开关 0.关 1.开 */
	public int jackpotswitch;
		/** 对应商品的ID */
	public int pid;
	
}