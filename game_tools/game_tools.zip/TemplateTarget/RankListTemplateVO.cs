/**
 * RankListTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class RankListTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 排行榜类型 1 今日单  2 今日总 */
	public int rankListId;
		/** 描述 */
	public string langDesc;
		/** 名次 */
	public int list1;
		/** 名次 */
	public int list2;
		/** 奖励类型3金钱 */
	public int reward;
		/** 奖励数量 */
	public int rewardNum;
	
}