/**
 * BounsTigerTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsTigerTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** bonus个数 */
	public int bonusNum;
		/** 相同元素的数量 */
	public int samNum;
	
}