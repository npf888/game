/**
 * pay
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class PayTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机号 */
	public int slotsNum;
		/** 5个 */
	public int combination1;
		/** 4个 */
	public int combination2;
		/** 3个 */
	public int combination3;
		/** 2个 */
	public int combination4;
		/** 1个 */
	public int combination5;
		/** 赔率 */
	public int pay;
		/** 中jackpot类型 1.中5个 2.中4个 3.中3个 4.不中 */
	public int jackpotid;
	
}