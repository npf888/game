/**
 * DirtywordsTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class DirtywordsVO
{
		/** 策划表数据主键 */
	public int id;
		/**  */
	public string words;
	
}