/**
 * 在线奖励
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class OnlineRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 语言Id */
	public int nameId;
		/** 名称 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** 图标 */
	public string icon;
		/** 在线时长 */
	public int onlineTime;
		/** 奖励id */
	public int rewardId;
		/** 奖励数量 */
	public int rewardNum;
	
}