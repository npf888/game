/**
 * vip
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class VipTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** vip等级 */
	public int vipLv;
		/** 花费钻石 */
	public int costDiamonds;
		/** 筹码 */
	public int giftChips;
		/** 赠送经验 */
	public int giftExp;
		/** 经验速度 */
	public int expUp;
		/** 魅力值 */
	public int charmValue;
		/** 每天奖励 */
	public int dailyReward;
		/** 表情是否开启 */
	public int expression;
		/** vip房间 */
	public int vipRoom;
		/** 连赢次数 */
	public int winTimes;
	
}