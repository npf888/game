/**
 * lucky match
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class LuckyMatchTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** itemId */
	public int itemId;
		/** itemNum */
	public int itemNum;
		/** 池子1 */
	public int value1;
		/** 池子1 */
	public int value2;
		/** 池子1 */
	public int value3;
		/** 池子1 */
	public int value4;
		/** 池子1 */
	public int value5;
		/** 池子1 */
	public int value6;
		/** 池子1 */
	public int value7;
		/** 池子1 */
	public int value8;
		/** 池子1 */
	public int value9;
		/** 池子1 */
	public int value10;
	
}