/**
 * TreasuryTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class TreasuryTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string langDesc;
		/** 作者:购买次数   超过5次视为5次 */
	public int typeTreasury;
		/** 初始金币 */
	public int originalChipTreasury;
		/** 金币存储系数（万分比） */
	public int factorTreasury;
		/** 作者:存储上限 */
	public int maxTreasury;
		/** 作者:VIP点数奖励 */
	public int vipPointTreasury;
		/** pid对应recharge */
	public int pid;
	
}