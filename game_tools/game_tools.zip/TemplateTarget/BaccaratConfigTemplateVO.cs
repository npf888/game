/**
 * BaccaratConfig
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BaccaratConfigTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 洗牌时间 */
	public int shuffleTime;
		/** 押注时间 */
	public int betTime;
		/** 发牌时间 */
	public int dealTime;
		/** 补牌时间 */
	public int fillTime;
		/** 展示时间 */
	public int showTime;
		/** 彩金比例 */
	public int jackpotRatio;
		/** 彩池时间 */
	public int jackpotTime;
	
}