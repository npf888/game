/**
 * BounsTigerRewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsTigerRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** 1.奖池1 , 2.奖池2 ,3.奖池3 , 4.奖池4 */
	public int rewardPool;
		/** 单线下注额倍数,选取的次数(百分比，实际值除以100） */
	public int times;
		/** 相同元素的数量 */
	public int weight;
	
}