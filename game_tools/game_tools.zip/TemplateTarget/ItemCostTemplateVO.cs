/**
 * 道具
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ItemCostTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 游戏类型 1 百家乐 2 德州 */
	public int gameId;
		/** 房间Id */
	public int roomId;
		/** 物品ID */
	public int itemId;
		/** 消耗筹码 */
	public int costChips;
		/** 魅力值 */
	public int changeCharm;
	
}