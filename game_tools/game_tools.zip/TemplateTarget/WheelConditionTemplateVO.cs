/**
 * WheelConditionTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class WheelConditionTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 跟recharge表对应的pid 表示哪个需要翻倍 */
	public int pid;
	
}