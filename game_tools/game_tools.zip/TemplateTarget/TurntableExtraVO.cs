/**
 * TurntableExtra.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class TurntableExtraVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/**  */
	public int itemId;
		/** 朋友加成 */
	public int friendreward;
		/** 等级加成 */
	public int levelreward;
		/** vip奖励描述id */
	public int vipDescrip;
		/** 好友奖励描述id */
	public int friendDescrip;
		/** 等级奖励描述id */
	public int levelDescrip;
	
}