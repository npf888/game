/**
 * BounsHallowmasJackpotTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsHallowmasJackpotTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 老虎机类型 */
	public int slotsNum;
		/** 第二次jackpot转出个数 */
	public int number;
		/** 彩金获得比例： X/100 */
	public int proportion;
		/** 权值 */
	public int weight;
	
}