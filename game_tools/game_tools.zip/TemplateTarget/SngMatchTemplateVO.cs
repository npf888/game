/**
 * interactiveItem
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SngMatchTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 房间是否开启 */
	public int openUp;
		/** 房间人数 */
	public int roomNum;
		/** dealer cost */
	public int dealerCost;
		/** 房间数 */
	public int openRoomNum;
		/** 入场费 */
	public int entryFee;
		/** 服务费 */
	public int serviceFee;
		/** 金杯筹码奖励 */
	public int chipsReward1;
		/** 金杯分数奖励 */
	public int scoreReward1;
		/** 银杯筹码奖励 */
	public int chipsReward2;
		/** 银杯分数奖励 */
	public int scoreReward2;
		/** 起始筹码 */
	public int initialChips;
		/** 门票id */
	public int ticketId;
	
}