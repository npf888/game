/**
 * LiarsDiceRoomSignInTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class LiarsDiceRoomSignInTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 名称的  int值 */
	public int nameInt;
		/** 对应提供的金币 */
	public int offerGold;
	
}