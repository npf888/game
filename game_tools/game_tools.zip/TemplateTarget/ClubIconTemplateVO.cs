/**
 * ClubIconTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ClubIconTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称id */
	public int nameId;
		/** 描述id */
	public int descrip;
		/** ico */
	public string icon;
		/** 注释 */
	public string langDesc;
		/** type */
	public int type;
		/** 条件 */
	public int condition;
		/** 值 */
	public int value;
	
}