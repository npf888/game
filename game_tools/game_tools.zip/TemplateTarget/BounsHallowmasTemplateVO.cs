/**
 * NoviceStepTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsHallowmasTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 老虎机类型 */
	public int slotsNum;
		/** bonus的个数 */
	public int bonusNum;
		/** 收集南瓜个数 */
	public int collectPumpkin;
		/** 为单线下注额的倍数，数值除以100使用 */
	public int reward;
		/** wild游戏个数 */
	public int wildNum;
		/** jackpot个数 */
	public int jackpotNum;
		/** 轮数 */
	public int turntime;
	
}