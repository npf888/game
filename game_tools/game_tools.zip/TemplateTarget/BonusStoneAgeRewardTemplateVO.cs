/**
 * BonusStoneAgeRewardTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusStoneAgeRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 单线下注倍数 */
	public int times;
		/** 权重 */
	public int weight;
	
}