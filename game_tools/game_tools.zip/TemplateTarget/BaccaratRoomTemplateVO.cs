/**
 * baccaratRoom
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BaccaratRoomTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 最小携带 */
	public int minCarry;
		/** 最大携带 */
	public int maxCarry;
		/** 最大人数 */
	public int maxNum;
		/** 初始库存 */
	public int stock;
		/** 开启 */
	public int openUp;
		/** 赢钱税 */
	public int tax;
		/** 彩金 */
	public int jackpot;
		/** 押注1 */
	public int bet1;
		/** 押注2 */
	public int bet2;
		/** 押注3 */
	public int bet3;
		/** 押注4 */
	public int bet4;
		/** 押注5 */
	public int bet5;
		/** 进入等级 */
	public int openLv;
		/** 显示类型 */
	public int list;
	
}