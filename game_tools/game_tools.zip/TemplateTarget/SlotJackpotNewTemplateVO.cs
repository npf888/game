/**
 * SlotJackpotNew
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SlotJackpotNewTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string langDesc;
		/** SlotsListTemplateVO id列 */
	public int slotNum;
		/** PayTemplateVO */
	public int jackpotid;
		/** jackpot中奖获得奖金比（万分比） */
	public int jackpotreward;
	
}