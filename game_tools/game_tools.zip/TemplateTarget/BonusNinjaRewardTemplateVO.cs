/**
 * BonusNinjaRewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusNinjaRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 是否中奖 1 中，0 否 */
	public int type;
		/** 单线下注额倍数,选取的次数(百分比，实际值除以100） */
	public int times;
		/** 权值 */
	public int weight;
	
}