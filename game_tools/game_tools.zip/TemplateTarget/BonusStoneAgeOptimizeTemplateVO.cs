/**
 * BonusStoneAgeOptimizeTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusStoneAgeOptimizeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称ID */
	public int nameId;
		/** 描述ID */
	public int descrip;
		/** 描述（自己看） */
	public string langDesc;
		/** 图标ID */
	public string icon;
		/** 老虎机类型 */
	public int slotsNum;
		/** bonus个数 */
	public int bonusNum;
		/** 翻符文游戏相同元素数量 */
	public int samNum;
		/** 摘苹果游戏次数 */
	public int appleGameNum;
		/** 单线下注额倍数,(百分比，实际值除以100） */
	public int appleReward;
		/** 狩猎游戏，夹子数量 */
	public int preyNum;
		/** 狩猎游戏单线下注额倍数 */
	public int preyReward;
	
}