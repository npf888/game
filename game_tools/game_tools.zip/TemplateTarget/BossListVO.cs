/**
 * BossList.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BossListVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** icon */
	public string icon1;
		/** 1、击杀榜 2、未击杀榜 */
	public int rankListId;
		/** 多语言描述 */
	public string langDesc;
		/** 富豪榜伤害名次 */
	public int list1;
		/** 排名名次 */
	public int list2;
		/** 奖励2：物品id */
	public int itemid2;
		/** 奖励数量 奖励物品数量 */
	public int rewardNum2;
	
}