/**
 * 金钱
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class CurrencyTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
	
}