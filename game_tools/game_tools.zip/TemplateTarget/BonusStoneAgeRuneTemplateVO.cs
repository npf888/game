/**
 * BonusStoneAgeRuneTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusStoneAgeRuneTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 转盘游戏奖池 */
	public int rewardPool;
		/** 单线下注额倍数,选取的次数(百分比，实际值除以100） */
	public int times;
		/** 权值 */
	public int weight;
	
}