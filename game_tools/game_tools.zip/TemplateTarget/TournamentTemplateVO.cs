/**
 * TournamentTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class TournamentTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/**  */
	public int tournamentType;
		/**  */
	public int slotNum1;
		/**  */
	public int slotNum2;
		/**  */
	public int slotNum3;
		/**  */
	public int slotNum4;
		/**  */
	public int slotNum5;
		/**  */
	public int duration1;
		/**  */
	public int duration2;
		/**  */
	public int duration3;
		/**  */
	public int totalTime;
		/**  */
	public int raceReward;
		/**  */
	public int intervalRaceReward;
	
}