/**
 * ScatterWheel
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScatterWheelTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotType;
		/** 中奖图标数量 */
	public int scatterNum;
	
}