/**
 * RiyuetanMultipleTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class RiyuetanMultipleTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 倍数值除100 */
	public int times;
		/** 权重 */
	public int weight;
	
}