/**
 * MagicSymbolTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class MagicSymbolTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机编号 */
	public int slotNum;
		/** 卷轴ID */
	public int reel1;
		/** 权重 */
	public int value1;
		/** 卷轴ID */
	public int reel2;
		/** 权重 */
	public int value2;
		/** 卷轴ID */
	public int reel3;
		/** 权重 */
	public int value3;
		/** 卷轴ID */
	public int reel4;
		/** 权重 */
	public int value4;
		/** 卷轴ID */
	public int reel5;
		/** 权重 */
	public int value5;
	
}