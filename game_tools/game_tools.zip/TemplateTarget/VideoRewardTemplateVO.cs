/**
 * VideoRewardTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class VideoRewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** itemId */
	public int itemId;
		/** itemNum */
	public int itemNum;
	
}