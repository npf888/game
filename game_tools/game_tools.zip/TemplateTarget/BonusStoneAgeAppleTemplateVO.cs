/**
 * BonusStoneAgeAppleTemplate
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusStoneAgeAppleTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 接住苹果的个数，最终奖励为：个数*单个倍数 */
	public int appleNum;
		/** 权值 */
	public int weight;
	
}