/**
 * TexasJackpot
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class TexasJackpotTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public string langDesc;
		/** 牌类型 */
	public int cardType;
		/** 获取彩金池比例 万分比 */
	public int jackpotPer;
	
}