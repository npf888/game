/**
 * recharge
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class RechargeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 渠道id */
	public int channelId;
		/** pid */
	public int pid;
		/** 名字id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 花费数量 */
	public int num;
		/** 钻石数量 */
	public int itemNum;
		/** 赠送数量 */
	public int giftNum;
		/** 产品id */
	public string productId;
		/** 是否使用 */
	public int used;
		/** mark */
	public int mark;
		/** 物品ID */
	public int itemId;
		/** 物品类型 */
	public int smallCategory;
		/** vip点 */
	public int vipPoint;
		/** 类型 */
	public int category;
		/** 支付类型1mycard */
	public int payType;
		/** 物品类型 */
	public int itemType;
	
}