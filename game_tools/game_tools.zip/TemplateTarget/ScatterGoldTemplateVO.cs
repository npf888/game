/**
 * ScatterGoldTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ScatterGoldTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 老虎机类型 */
	public int slotsNum;
		/** 单线倍数 */
	public int times;
		/**  */
	public int weight;
	
}