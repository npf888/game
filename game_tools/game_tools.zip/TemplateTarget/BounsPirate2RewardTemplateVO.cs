/**
 * BounsPirate2RewardTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsPirate2RewardTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** 第几个奖池 */
	public int rewardPool;
		/** 奖励的数量 */
	public int multiplier;
		/** 权重 */
	public int weight;
	
}