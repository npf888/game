/**
 * NewComerTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class NewComerTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 礼包购买限时 单位,秒 */
	public int timeLimit;
		/** 礼包购买限时开关  0,开  1,关 */
	public int type;
		/** 判定玩家游戏天数 单位,天 */
	public int gameTime1;
		/** 判定玩家游戏天数  单位,天 */
	public int gameTime2;
		/** 对应recharge表内pid值 */
	public int pid;
	
}