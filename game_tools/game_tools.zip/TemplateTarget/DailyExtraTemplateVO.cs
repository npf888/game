/**
 * DailyExtraTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class DailyExtraTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称 */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 完成任务个数 */
	public int finishNum;
		/** 奖励 */
	public int reward1Num;
		/**  */
	public int itemId;
	
}