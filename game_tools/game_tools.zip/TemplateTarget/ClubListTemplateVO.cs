/**
 * ClubList.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ClubListTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名称id */
	public int nameId;
		/** 描述 */
	public int descrip;
		/** 奖励筹码ico */
	public string icon1;
		/** 类型 */
	public int rankListId;
		/** 注释 */
	public string langDesc;
		/** 名词 */
	public int list1;
		/** 名次 */
	public int list2;
		/** 奖励1 */
	public int reward1;
		/** 奖励物品 */
	public string reward2;
		/** 人均奖励数量 */
	public int rewardNum1;
	
}