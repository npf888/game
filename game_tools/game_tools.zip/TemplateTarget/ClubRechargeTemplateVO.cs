/**
 * ClubRecharge.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class ClubRechargeTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 描述 */
	public int descrip;
		/** 注释 */
	public string langDesc;
		/** ico */
	public string icon;
		/** 物品id */
	public int item1Id;
		/** 购买者获得金币数量 */
	public int itemNum1;
		/** 物品id */
	public int item2Id;
		/** 购买者获得金币数量 */
	public int itemNum2;
		/** 物品id */
	public int item3Id;
		/** 购买者获得数量 */
	public int itemNum3;
	
}