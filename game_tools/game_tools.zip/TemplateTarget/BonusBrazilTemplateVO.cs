/**
 * BonusBrazilTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BonusBrazilTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** 小游戏类型 1：喝酒小游戏 2：桑巴小游戏 */
	public int type;
		/** icon */
	public string icon;
		/** 老虎机类型 */
	public int slotsNum;
		/** bonus的个数 */
	public int bonusNum;
		/** 权值 */
	public int value;
		/** 机会数量 */
	public int chance;
	
}