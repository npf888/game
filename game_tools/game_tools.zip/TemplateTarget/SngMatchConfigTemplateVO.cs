/**
 * interactiveItem
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class SngMatchConfigTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int lv;
		/** sng id */
	public int fieldId;
		/** 起始小盲注 */
	public int smallBlind;
		/** 升盲时间 */
	public int blindTime;
	
}