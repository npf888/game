/**
 * BounsElephontTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class BounsElephontTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/** 多语言描述 */
	public string langDesc;
		/** icon */
	public string icon;
		/** 老虎机机器编号 */
	public int slotsNum;
		/** bonus个数 */
	public int bonusNum;
		/** 宝箱倍数 除以100 */
	public int box1;
		/** 权重 */
	public int value1;
		/**  */
	public int box2;
		/**  */
	public int value2;
		/**  */
	public int box3;
		/**  */
	public int value3;
		/**  */
	public int box4;
		/**  */
	public int value4;
	
}