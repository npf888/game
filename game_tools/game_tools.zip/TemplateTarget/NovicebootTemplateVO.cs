/**
 * NovicebootTemplate.txt
 * 
 * @author CodeGenerator, don't	modify this file please.
 * 
 */
 public class NovicebootTemplateVO
{
		/** 策划表数据主键 */
	public int id;
		/** 名字id */
	public int nameId;
		/** 多语言描述id */
	public int descrip;
		/**  */
	public string langDesc;
		/**  */
	public string stepDesc;
		/** 老虎机编号 */
	public int slotNum;
		/** 老虎机场景 */
	public int type;
		/**  */
	public int step;
		/** 0非强制1强制 */
	public int force;
		/** 0不可跳过      1可跳过 */
	public int ignore;
	
}