module game 
{
	export class GCBazooSignin
	{
		public gold:number;
		public nameInt:number;
		public diceValues:number[];
	}
}