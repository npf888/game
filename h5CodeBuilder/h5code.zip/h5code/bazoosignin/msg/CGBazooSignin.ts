module game 
{
	export class CGBazooSignin
	{
	}
}