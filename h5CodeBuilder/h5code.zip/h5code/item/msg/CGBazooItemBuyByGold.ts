module game 
{
	export class CGBazooItemBuyByGold
	{
		public itemId:number;
	}
}