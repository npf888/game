module game 
{
	export class CGGroupSendInteractiveItem
	{
		public itemId:number;
	}
}