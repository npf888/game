module game 
{
	export class CGBazooItemClockChange
	{
		public itemId:number;
	}
}