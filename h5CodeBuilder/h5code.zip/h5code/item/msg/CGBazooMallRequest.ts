module game 
{
	export class CGBazooMallRequest
	{
	}
}