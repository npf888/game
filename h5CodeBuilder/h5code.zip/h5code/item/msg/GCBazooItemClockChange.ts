module game 
{
	export class GCBazooItemClockChange
	{
		public itemId:number;
	}
}