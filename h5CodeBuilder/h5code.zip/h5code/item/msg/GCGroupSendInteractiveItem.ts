module game 
{
	export class GCGroupSendInteractiveItem
	{
		public fromId:number;
		public itemId:number;
	}
}