module game 
{
	export class GCBazooItemClockChangeToAll
	{
		public playerId:number;
		public itemId:number;
		public img:string;
	}
}