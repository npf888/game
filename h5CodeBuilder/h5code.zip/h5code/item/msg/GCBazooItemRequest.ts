module game 
{
	export class GCBazooItemRequest
	{
		public itemInfoDataNew:ItemInfoDataNew[];
	}
}