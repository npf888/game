module game 
{
	export class CGBazooItemRequest
	{
		public itemType:number;
	}
}