module game 
{
	export class GCBazooItemBuyByGold
	{
		public isSucess:number;
		public langId:number;
		public paramsList:string[];
	}
}