module game 
{
	export class CGSendInteractiveItem
	{
		public itemId:number;
		public playerId:number;
	}
}