module game 
{
	export class GCSendInteractiveItem
	{
		public fromId:number;
		public itemId:number;
		public toId:number;
	}
}