module game 
{
	export class GCBazooMallRequest
	{
		public itemInfoDataNew:ItemInfoDataNew[];
	}
}