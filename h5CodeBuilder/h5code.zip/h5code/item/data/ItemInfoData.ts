module game 
{
	export class ItemInfoData
	{
		public uuid:string;
		public templateId:number;
		public overlap:number;
		public beginTime:number;
		public duration:number;
	}
}