module game 
{
	export class ItemInfoDataNew
	{
		public fromPlayerId:number;
		public itemId:number;
		public itemType:number;
		public itemName:string;
		public price:number;
		public img:string;
		public usingClockItemId:number;
		public isExist:number;
	}
}