module game 
{
	export class StrangerData
	{
		public userId:number;
		public img:string;
		public name:string;
		public vipLevel:number;
		public level:number;
		public sex:number;
		public countries:string;
		public isRequest:number;
	}
}