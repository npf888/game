module game 
{
	export class FriendRequestInfoData
	{
		public playerId:number;
	}
}