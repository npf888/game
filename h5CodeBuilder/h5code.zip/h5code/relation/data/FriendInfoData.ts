module game 
{
	export class FriendInfoData
	{
		public playerId:number;
	}
}