module game 
{
	export class FriendGiftInfoData
	{
		public giftId:number;
		public playerId:number;
		public name:string;
		public img:string;
		public sendTime:number;
		public getTime:number;
	}
}