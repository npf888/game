module game 
{
	export class FriendAlreadyGiftListData
	{
		public playId:number;
	}
}