module game 
{
	export class CGRequestFriend
	{
		public playerId:number;
	}
}