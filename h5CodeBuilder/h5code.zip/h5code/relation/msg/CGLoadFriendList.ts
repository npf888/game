module game 
{
	export class CGLoadFriendList
	{
	}
}