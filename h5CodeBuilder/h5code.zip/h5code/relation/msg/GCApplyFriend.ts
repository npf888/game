module game 
{
	export class GCApplyFriend
	{
		public playId:number;
		public result:number;
	}
}