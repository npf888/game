module game 
{
	export class GCRequestFriendSync
	{
		public friendRequestInfoData:PlayerInfoData;
	}
}