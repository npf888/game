module game 
{
	export class CGDeleteFriend
	{
		public friendId:number;
	}
}