module game 
{
	export class GCDeleteFriend
	{
		public friendId:number;
	}
}