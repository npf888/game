module game 
{
	export class GCFacebookFriendsSync
	{
		public friendRequestInfoData:FriendDetailInfoData[];
	}
}