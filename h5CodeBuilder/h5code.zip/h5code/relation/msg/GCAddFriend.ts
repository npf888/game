module game 
{
	export class GCAddFriend
	{
		public friendDetailInfoData:FriendDetailInfoData;
	}
}