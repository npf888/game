module game 
{
	export class GCLoadFriendList
	{
		public friendDetailInfoDatalist:FriendDetailInfoData[];
	}
}