module game 
{
	export class GCLoadFriendRequestList
	{
		public friendRequestInfoDataList:PlayerInfoData[];
	}
}