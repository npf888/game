module game 
{
	export class CGLoadFriendRequestList
	{
	}
}