module game 
{
	export class GCRequestFriend
	{
		public playerId:number;
	}
}