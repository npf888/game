module game 
{
	export class CGApplyFriend
	{
		public playerId:number;
		public result:number;
	}
}