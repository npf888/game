module game 
{
	export class CGFacebookFriendsSync
	{
		public friendList:string[];
	}
}