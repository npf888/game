module game 
{
	export class CGBazooRedPackage
	{
		public itemId:number;
	}
}