module game 
{
	export class CGBazooSendGift
	{
		public itemType:number;
		public toPlayerId:number;
		public itemId:number;
		public number:number;
	}
}