module game 
{
	export class GCBazooRedPackage
	{
		public isSucess:number;
		public langId:number;
		public paramsList:string[];
	}
}