module game 
{
	export class GCBazooSendGift
	{
		public fromPlayerGold:number;
		public fromPlayerId:number;
		public toPlayerId:number;
		public itemId:number;
		public number:number;
		public itemType:number;
	}
}