module game 
{
	export class MailInfoData
	{
		public mailId:number;
		public sendId:number;
		public sendName:string;
		public mailCdTime:number;
		public isRead:number;
		public hasAttachment:number;
		public mailStatus:number;
		public mailTitle:string;
		public mailCreatTime:number;
		public isFriendSend:number;
		public headName:string;
		public vipLevel:number;
	}
}