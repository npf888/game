module game 
{
	export class GCUpdateMailList
	{
		public mailKind:number;
		public mailId:number;
		public mailInfoData:MailInfoData;
	}
}