module game 
{
	export class CGLoadMailList
	{
		public mailKind:number;
	}
}