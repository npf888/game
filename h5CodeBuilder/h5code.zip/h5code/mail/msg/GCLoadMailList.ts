module game 
{
	export class GCLoadMailList
	{
		public mailKind:number;
		public mailInfoDataList:MailInfoData[];
	}
}