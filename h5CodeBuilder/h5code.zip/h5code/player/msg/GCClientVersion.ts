module game 
{
	export class GCClientVersion
	{
	}
}