module game 
{
	export class CGPlayerEnter
	{
	}
}