module game 
{
	export class GCEnterScene
	{
	}
}