module game 
{
	export class CGQueryPlayerInfo
	{
		public userId:number;
	}
}