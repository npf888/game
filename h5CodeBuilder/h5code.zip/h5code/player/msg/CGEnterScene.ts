module game 
{
	export class CGEnterScene
	{
		public sceneId:number;
	}
}