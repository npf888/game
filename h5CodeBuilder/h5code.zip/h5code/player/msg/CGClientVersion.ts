module game 
{
	export class CGClientVersion
	{
		public version:string;
	}
}