module game 
{
	export class GCQueryPlayerInfoName
	{
		public playerInfoData:PlayerInfoData[];
	}
}