module game 
{
	export class GCCheckPlayerLogin
	{
		public loginId:number;
		public facebookId:string;
		public accountId:string;
		public img:string;
		public utcOffset:number;
		public playerRole:number;
	}
}