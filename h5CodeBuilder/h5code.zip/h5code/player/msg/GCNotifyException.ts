module game 
{
	export class GCNotifyException
	{
		public code:number;
		public msg:string;
	}
}