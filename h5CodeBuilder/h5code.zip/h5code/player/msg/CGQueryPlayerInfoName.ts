module game 
{
	export class CGQueryPlayerInfoName
	{
		public userName:string;
	}
}