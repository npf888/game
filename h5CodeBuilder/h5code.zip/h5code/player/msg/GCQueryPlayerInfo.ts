module game 
{
	export class GCQueryPlayerInfo
	{
		public playerInfoData:PlayerInfoData;
		public bazooPersonalInfo:BazooPersonalInfo[];
	}
}