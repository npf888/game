module game 
{
	export class ChargeKindData
	{
		public chargeKindId:number;
	}
}