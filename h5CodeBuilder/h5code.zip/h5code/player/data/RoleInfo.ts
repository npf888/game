module game 
{
	export class RoleInfo
	{
		public roleUUID:number;
		public vocation:number;
		public name:string;
		public level:number;
		public equipquality:number;
		public passportId:number;
		public firstLogin:number;
		public deleted:number;
	}
}