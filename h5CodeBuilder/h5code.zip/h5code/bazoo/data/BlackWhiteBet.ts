module game 
{
	export class BlackWhiteBet
	{
		public passportId:number;
		public bet:number[];
		public winPassportIds:number[];
		public gold:number;
	}
}