module game 
{
	export class DiceInfo
	{
		public passportId:number;
		public diceValues:number[];
		public cowNameInt:number;
		public redDiceValues:number[];
	}
}