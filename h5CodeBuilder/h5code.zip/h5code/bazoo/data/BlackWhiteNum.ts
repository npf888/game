module game 
{
	export class BlackWhiteNum
	{
		public red:number;
		public black:number;
		public single:number;
		public doubles:number;
	}
}