module game 
{
	export class ShowHandBet
	{
		public passportId:number;
		public bet:number;
		public gold:number;
		public personTotalGold:number;
	}
}