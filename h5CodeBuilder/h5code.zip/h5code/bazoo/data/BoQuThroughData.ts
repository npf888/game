module game 
{
	export class BoQuThroughData
	{
		public timestamp:number;
	}
}