module game 
{
	export class BetTotalNum
	{
		public bet:number;
		public totalNum:number;
	}
}