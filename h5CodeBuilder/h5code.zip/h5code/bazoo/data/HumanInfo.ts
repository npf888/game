module game 
{
	export class HumanInfo
	{
		public curPassportId:number;
	}
}