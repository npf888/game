module game 
{
	export class EndCountInfo
	{
		public passportId:number;
		public multiple:number;
		public gold:number;
		public name:string;
		public winPassportId:number[];
		public winMultiple:number[];
		public diceValues:number[];
		public personTotalGold:number;
	}
}