module game 
{
	export class NewGuyProcess
	{
		public classicCompleted:number;
		public niuniuCompleted:number;
		public showhandCompleted:number;
		public redblackCompleted:number;
	}
}