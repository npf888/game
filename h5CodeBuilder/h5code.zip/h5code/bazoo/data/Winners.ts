module game 
{
	export class Winners
	{
		public passportId:number;
		public multiple:number;
	}
}