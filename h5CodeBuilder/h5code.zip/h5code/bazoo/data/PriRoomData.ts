module game 
{
	export class PriRoomData
	{
		public roomNumber:string;
		public creater:string;
		public createrPassportId:number;
		public flag:number;
		public vip:number;
		public modeType:number;
		public bet:number;
		public img:string;
		public numTotalNum:string;
		public isNeedPassword:number;
	}
}