module game 
{
	export class BlackWhiteDiceInfo
	{
		public passportId:number;
		public isOut:number;
		public diceValues:number[];
		public removeDiceValues:number[];
	}
}