module game 
{
	export class GCStateRoomRoundBegin
	{
		public status:number;
	}
}