module game 
{
	export class GCStateRoomRoundGuess
	{
		public status:number;
	}
}