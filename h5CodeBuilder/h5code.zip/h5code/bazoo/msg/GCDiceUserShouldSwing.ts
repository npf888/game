module game 
{
	export class GCDiceUserShouldSwing
	{
		public shouldCallPassportId:number;
	}
}