module game 
{
	export class GCStateRoomCallDice
	{
		public status:number;
	}
}