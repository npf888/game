module game 
{
	export class CGBazooBoqu
	{
		public pcOrMobile:string;
	}
}