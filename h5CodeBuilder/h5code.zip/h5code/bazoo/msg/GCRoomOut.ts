module game 
{
	export class GCRoomOut
	{
		public beRemovedPassportIds:number[];
	}
}