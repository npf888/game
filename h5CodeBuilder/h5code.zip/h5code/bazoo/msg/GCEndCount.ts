module game 
{
	export class GCEndCount
	{
		public finalDiceNum:number;
		public endCountInfo:EndCountInfo[];
	}
}