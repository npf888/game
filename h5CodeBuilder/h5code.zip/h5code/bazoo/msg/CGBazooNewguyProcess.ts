module game 
{
	export class CGBazooNewguyProcess
	{
		public ModeType:number;
	}
}