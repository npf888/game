module game 
{
	export class CGModeChose
	{
		public modeType:number;
	}
}