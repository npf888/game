module game 
{
	export class GCRoomBeRemoveed
	{
	}
}