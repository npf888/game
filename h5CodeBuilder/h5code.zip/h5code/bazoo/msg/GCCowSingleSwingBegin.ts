module game 
{
	export class GCCowSingleSwingBegin
	{
	}
}