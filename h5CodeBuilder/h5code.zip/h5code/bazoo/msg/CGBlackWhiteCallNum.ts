module game 
{
	export class CGBlackWhiteCallNum
	{
		public diceType:number;
	}
}