module game 
{
	export class GCBlackWhiteEndCount
	{
		public endCountInfo:EndCountInfo[];
	}
}