module game 
{
	export class CGDiceSingleSwing
	{
	}
}