module game 
{
	export class CGRoomPriJoin
	{
		public roomNumber:string;
		public password:string;
	}
}