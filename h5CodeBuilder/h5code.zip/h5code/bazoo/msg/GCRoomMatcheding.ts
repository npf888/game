module game 
{
	export class GCRoomMatcheding
	{
	}
}