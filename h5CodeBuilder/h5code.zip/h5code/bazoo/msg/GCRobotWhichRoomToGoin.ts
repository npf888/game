module game 
{
	export class GCRobotWhichRoomToGoin
	{
		public passportId:number;
		public roomNumber:string;
	}
}