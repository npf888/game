module game 
{
	export class CGRoomPubJoin
	{
		public roomNumber:string;
	}
}