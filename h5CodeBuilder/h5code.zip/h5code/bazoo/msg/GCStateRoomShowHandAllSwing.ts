module game 
{
	export class GCStateRoomShowHandAllSwing
	{
		public status:number;
		public leftTimes:number;
		public leftSecond:number;
		public diceInfo:DiceInfo[];
	}
}