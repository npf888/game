module game 
{
	export class CGRoomOut
	{
		public bet:number;
	}
}