module game 
{
	export class GCModeChose
	{
		public betTotalNum:BetTotalNum[];
	}
}