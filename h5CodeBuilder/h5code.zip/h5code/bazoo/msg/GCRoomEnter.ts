module game 
{
	export class GCRoomEnter
	{
		public returnPlayerInfo:ReturnPlayerInfo[];
	}
}