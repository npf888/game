module game 
{
	export class CGGuessBigSmall
	{
		public bigSmall:number;
	}
}