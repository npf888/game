module game 
{
	export class GCRoomPriSearch
	{
		public roomNumber:string;
	}
}