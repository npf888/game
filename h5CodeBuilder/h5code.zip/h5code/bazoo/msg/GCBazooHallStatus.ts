module game 
{
	export class GCBazooHallStatus
	{
		public signInStatus:number;
		public taskNumber:number;
	}
}