module game 
{
	export class GCBazooChangeName
	{
		public nickname:string;
	}
}