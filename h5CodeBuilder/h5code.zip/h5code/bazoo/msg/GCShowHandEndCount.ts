module game 
{
	export class GCShowHandEndCount
	{
		public endCountInfo:EndCountInfo[];
	}
}