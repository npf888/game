module game 
{
	export class GCRoomEnterNotAllow
	{
		public langId:number;
		public paramsList:string[];
	}
}