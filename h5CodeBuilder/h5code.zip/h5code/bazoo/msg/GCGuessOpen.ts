module game 
{
	export class GCGuessOpen
	{
	}
}