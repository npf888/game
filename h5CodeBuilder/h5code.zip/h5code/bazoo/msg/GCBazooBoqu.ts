module game 
{
	export class GCBazooBoqu
	{
		public htmlPage:string;
	}
}