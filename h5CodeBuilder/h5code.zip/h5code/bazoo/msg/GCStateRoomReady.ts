module game 
{
	export class GCStateRoomReady
	{
		public status:number;
		public leftSecond:number;
	}
}