module game 
{
	export class GCStateRoomBlackWhiteEnd
	{
		public endCountInfo:EndCountInfo[];
	}
}