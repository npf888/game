module game 
{
	export class GCCowSingleSwingEnd
	{
		public diceInfo:DiceInfo[];
	}
}