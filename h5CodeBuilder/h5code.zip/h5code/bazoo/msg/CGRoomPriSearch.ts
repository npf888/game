module game 
{
	export class CGRoomPriSearch
	{
		public roomNumber:string;
	}
}