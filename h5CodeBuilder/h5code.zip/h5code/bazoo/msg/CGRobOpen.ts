module game 
{
	export class CGRobOpen
	{
	}
}