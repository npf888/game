module game 
{
	export class CGTalkBig
	{
		public diceNum:number;
		public diceValue:number;
	}
}