module game 
{
	export class CGBazooHallStatus
	{
	}
}