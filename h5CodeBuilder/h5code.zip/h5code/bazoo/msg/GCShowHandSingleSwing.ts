module game 
{
	export class GCShowHandSingleSwing
	{
		public passportId:number;
		public diceValues:number[];
		public nameInt:number;
		public leftTimes:number;
		public showHandBet:ShowHandBet[];
	}
}