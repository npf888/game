module game 
{
	export class GCStateRoomEnter
	{
		public status:number;
	}
}