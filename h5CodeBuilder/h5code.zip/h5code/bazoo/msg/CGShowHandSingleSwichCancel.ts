module game 
{
	export class CGShowHandSingleSwichCancel
	{
		public diceIndex:number;
	}
}