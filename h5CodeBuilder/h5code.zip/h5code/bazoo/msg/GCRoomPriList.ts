module game 
{
	export class GCRoomPriList
	{
		public priRoomData:PriRoomData[];
	}
}