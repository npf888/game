module game 
{
	export class GCRoomState
	{
		public roomState:number;
	}
}