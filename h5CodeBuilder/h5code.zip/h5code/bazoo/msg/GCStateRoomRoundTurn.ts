module game 
{
	export class GCStateRoomRoundTurn
	{
		public status:number;
		public whoTurnPassportId:number;
		public leftSecond:number;
	}
}