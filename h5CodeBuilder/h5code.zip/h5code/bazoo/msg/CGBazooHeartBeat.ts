module game 
{
	export class CGBazooHeartBeat
	{
	}
}