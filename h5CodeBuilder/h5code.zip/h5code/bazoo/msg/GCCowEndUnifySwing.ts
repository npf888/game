module game 
{
	export class GCCowEndUnifySwing
	{
		public endCountInfo:EndCountInfo[];
	}
}