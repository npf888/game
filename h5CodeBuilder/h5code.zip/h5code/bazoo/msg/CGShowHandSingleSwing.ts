module game 
{
	export class CGShowHandSingleSwing
	{
		public diceValues:number[];
	}
}