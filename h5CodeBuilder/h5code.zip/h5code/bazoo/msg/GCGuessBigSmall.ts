module game 
{
	export class GCGuessBigSmall
	{
		public passportId:number;
		public agreePassportId:number;
	}
}