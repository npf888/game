module game 
{
	export class GCCowSingleSwing
	{
		public passportId:number;
		public cowNameInt:number;
		public diceValues:number[];
		public redDiceValues:number[];
	}
}