module game 
{
	export class GCStateRoomMatching
	{
		public status:number;
	}
}