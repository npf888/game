module game 
{
	export class CGRoomEnter
	{
		public bet:number;
	}
}