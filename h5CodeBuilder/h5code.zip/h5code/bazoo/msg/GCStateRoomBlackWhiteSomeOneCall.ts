module game 
{
	export class GCStateRoomBlackWhiteSomeOneCall
	{
		public whoCallPassportId:number;
		public diceType:number;
		public killNum:number;
		public multiple:number;
		public blackWhiteBet:BlackWhiteBet[];
		public blackWhiteDiceInfo:BlackWhiteDiceInfo[];
	}
}