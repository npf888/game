module game 
{
	export class CGBazooChangeName
	{
		public nickname:string;
	}
}