module game 
{
	export class GCTalkBig
	{
		public WhoTurnPassportId:number;
		public curPassportId:number;
		public callDiceNum:number;
		public callDiceValue:number;
		public onePoint:number;
	}
}