module game 
{
	export class CGShowHandSingleSwich
	{
		public diceIndex:number;
	}
}