module game 
{
	export class GCBlackWhiteCallNum
	{
		public whoCallPassportId:number;
		public diceType:number;
		public killNum:number;
		public multiple:number;
		public blackWhiteBet:BlackWhiteBet[];
		public blackWhiteDiceInfo:BlackWhiteDiceInfo[];
	}
}