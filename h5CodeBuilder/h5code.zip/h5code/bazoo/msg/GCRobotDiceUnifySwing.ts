module game 
{
	export class GCRobotDiceUnifySwing
	{
		public diceInfo:DiceInfo[];
	}
}