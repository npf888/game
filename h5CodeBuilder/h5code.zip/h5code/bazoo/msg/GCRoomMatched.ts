module game 
{
	export class GCRoomMatched
	{
		public waitTime:number;
	}
}