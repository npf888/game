module game 
{
	export class GCShowHandLittleSwing
	{
		public passportId:number[];
	}
}