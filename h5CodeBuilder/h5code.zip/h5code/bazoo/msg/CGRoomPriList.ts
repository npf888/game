module game 
{
	export class CGRoomPriList
	{
	}
}