module game 
{
	export class GCStateRoomBlackWhiteWaitSomeOne
	{
		public whoTurnPassportId:number;
		public leftSecond:number;
	}
}