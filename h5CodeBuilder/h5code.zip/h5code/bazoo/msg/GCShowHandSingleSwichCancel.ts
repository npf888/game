module game 
{
	export class GCShowHandSingleSwichCancel
	{
		public passportId:number;
		public diceIndex:number;
	}
}