module game 
{
	export class GCStateRoomBlackWhiteSwingLeft
	{
		public multiple:number;
		public passportId:number[];
		public leftDiceNum:number[];
	}
}