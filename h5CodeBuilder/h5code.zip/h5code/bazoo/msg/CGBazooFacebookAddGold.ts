module game 
{
	export class CGBazooFacebookAddGold
	{
		public gold:number;
	}
}