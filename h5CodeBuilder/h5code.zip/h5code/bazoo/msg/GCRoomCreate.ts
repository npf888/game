module game 
{
	export class GCRoomCreate
	{
		public isSuccess:number;
	}
}