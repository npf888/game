module game 
{
	export class GCBlackWhiteAllSwing
	{
		public passportId:number[];
		public leftDiceNum:number[];
		public diceValues:number[];
		public multiple:number;
		public blackWhiteNum:BlackWhiteNum;
	}
}