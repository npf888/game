module game 
{
	export class GCStateRoomSingleSwingBegin
	{
		public status:number;
	}
}