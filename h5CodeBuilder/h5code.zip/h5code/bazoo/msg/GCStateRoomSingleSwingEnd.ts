module game 
{
	export class GCStateRoomSingleSwingEnd
	{
		public status:number;
		public diceInfo:DiceInfo[];
	}
}