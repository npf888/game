module game 
{
	export class GCDiceSingleSwing
	{
		public passportId:number;
		public diceValues:number[];
	}
}