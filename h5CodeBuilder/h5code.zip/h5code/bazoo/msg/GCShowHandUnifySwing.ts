module game 
{
	export class GCShowHandUnifySwing
	{
		public leftTimes:number;
		public diceInfo:DiceInfo[];
	}
}