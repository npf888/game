module game 
{
	export class GCCowUnifySwing
	{
		public oneRoundTime:number;
		public cowNameInt:number;
		public diceValues:number[];
		public redDiceValues:number[];
		public passportId:number;
	}
}