module game 
{
	export class GCShowHandSingleSwich
	{
		public passportId:number;
		public diceIndex:number;
	}
}