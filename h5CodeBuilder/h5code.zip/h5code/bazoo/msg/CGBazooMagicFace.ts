module game 
{
	export class CGBazooMagicFace
	{
		public sendPassportId:number;
		public receivePassportId:number;
		public magicFace:string;
	}
}