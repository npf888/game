module game 
{
	export class GCBazooHeartBeat
	{
	}
}