module game 
{
	export class GCStateRoomRoundResult
	{
		public status:number;
		public endCountInfo:EndCountInfo[];
	}
}