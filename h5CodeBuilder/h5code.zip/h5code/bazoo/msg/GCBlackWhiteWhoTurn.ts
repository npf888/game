module game 
{
	export class GCBlackWhiteWhoTurn
	{
		public whoTurnPassportId:number;
		public leftSecond:number;
	}
}