module game 
{
	export class CGCowSingleSwing
	{
		public diceValues:number[];
	}
}