module game 
{
	export class GCRoomPriJoin
	{
		public modeType:number;
		public isSuccess:number;
	}
}