module game 
{
	export class GCStateRoomRoundOpen
	{
		public status:number;
		public robPassportId:number;
		public robMultiple:number;
	}
}