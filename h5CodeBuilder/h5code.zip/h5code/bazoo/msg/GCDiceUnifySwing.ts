module game 
{
	export class GCDiceUnifySwing
	{
		public passportId:number;
		public diceValues:number[];
	}
}