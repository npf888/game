module game 
{
	export class GCRobOpen
	{
		public robPassportId:number;
		public multiple:number;
	}
}