module game 
{
	export class GCBazooMagicFace
	{
		public sendPassportId:number;
		public receivePassportId:number;
		public magicFace:string;
	}
}