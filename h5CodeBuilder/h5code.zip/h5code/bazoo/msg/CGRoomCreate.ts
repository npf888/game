module game 
{
	export class CGRoomCreate
	{
		public modeType:number;
		public bet:number;
		public password:string;
	}
}