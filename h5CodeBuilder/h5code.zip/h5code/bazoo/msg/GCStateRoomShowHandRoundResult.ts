module game 
{
	export class GCStateRoomShowHandRoundResult
	{
		public status:number;
		public endCountInfo:EndCountInfo[];
	}
}