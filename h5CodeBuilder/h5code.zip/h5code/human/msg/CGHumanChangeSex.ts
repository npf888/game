module game 
{
	export class CGHumanChangeSex
	{
		public sex:number;
	}
}