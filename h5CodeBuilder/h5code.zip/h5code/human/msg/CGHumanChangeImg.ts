module game 
{
	export class CGHumanChangeImg
	{
		public img:string;
	}
}