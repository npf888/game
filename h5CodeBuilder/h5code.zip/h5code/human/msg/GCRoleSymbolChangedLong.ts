module game 
{
	export class GCRoleSymbolChangedLong
	{
		public roleType:number;
		public roleUUID:number;
		public properties:KeyValuePair[];
	}
}