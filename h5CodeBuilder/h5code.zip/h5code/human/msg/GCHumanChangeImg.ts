module game 
{
	export class GCHumanChangeImg
	{
		public img:string;
	}
}