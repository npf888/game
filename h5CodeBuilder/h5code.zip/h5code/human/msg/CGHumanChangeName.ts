module game 
{
	export class CGHumanChangeName
	{
		public name:string;
	}
}