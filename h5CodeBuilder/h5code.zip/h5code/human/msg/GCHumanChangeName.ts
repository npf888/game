module game 
{
	export class GCHumanChangeName
	{
		public name:string;
		public duplicateNum:number;
	}
}