module game 
{
	export class GCChaneageCountries
	{
		public countries:string;
		public age:number;
	}
}