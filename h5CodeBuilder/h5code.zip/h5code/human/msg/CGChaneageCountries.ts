module game 
{
	export class CGChaneageCountries
	{
		public countries:string;
		public age:number;
	}
}