module game 
{
	export class GCHumanChangeSex
	{
		public sex:number;
	}
}