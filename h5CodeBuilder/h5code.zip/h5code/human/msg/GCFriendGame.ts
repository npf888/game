module game 
{
	export class GCFriendGame
	{
		public friendId:number;
	}
}