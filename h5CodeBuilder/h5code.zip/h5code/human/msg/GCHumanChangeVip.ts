module game 
{
	export class GCHumanChangeVip
	{
		public vip:number;
	}
}