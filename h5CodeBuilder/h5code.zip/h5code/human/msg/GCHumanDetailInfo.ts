module game 
{
	export class GCHumanDetailInfo
	{
		public human:HumanInfoData;
	}
}