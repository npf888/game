module game 
{
	export class HumanInfoData
	{
		public roleId:number;
		public name:string;
		public sex:number;
		public level:number;
		public vipLevel:number;
		public diamond:number;
		public gold:number;
		public curExp:number;
		public maxExp:number;
		public charm:number;
		public sceneId:number;
		public gvfirst:string;
		public newguide:string;
		public watchNum:number;
		public countries:string;
		public integral:number;
		public newGuyGift:number;
		public todayView:number;
		public bazooGold:number;
		public bazooRoom:string;
		public bazooNewGuyProcess:string;
	}
}