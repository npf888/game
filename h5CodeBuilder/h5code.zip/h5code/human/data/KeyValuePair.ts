module game 
{
	export class KeyValuePair
	{
		public key:Object;
		public value:Object;
	}
}