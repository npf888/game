module game 
{
	export class LevelMoreGiftData
	{
		public giftType:number;
		public rewardNum:number;
	}
}