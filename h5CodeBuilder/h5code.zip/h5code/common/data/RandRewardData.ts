module game 
{
	export class RandRewardData
	{
		public rewardId:number;
		public rewardCount:number;
		public vippoint:number;
	}
}