module game 
{
	export class GCHandshake
	{
	}
}