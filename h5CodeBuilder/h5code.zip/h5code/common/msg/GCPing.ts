module game 
{
	export class GCPing
	{
		public timestamp:number;
	}
}