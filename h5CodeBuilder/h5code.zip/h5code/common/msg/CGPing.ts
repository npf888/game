module game 
{
	export class CGPing
	{
	}
}