module game 
{
	export class GCSystemMessage
	{
		public code:number;
		public showType:number;
	}
}