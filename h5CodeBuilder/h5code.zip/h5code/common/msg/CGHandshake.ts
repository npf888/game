module game 
{
	export class CGHandshake
	{
		public id:string;
		public fly:number;
		public deviceId:string;
	}
}