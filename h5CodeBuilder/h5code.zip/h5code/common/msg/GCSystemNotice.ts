module game 
{
	export class GCSystemNotice
	{
		public content:string;
		public color:number;
		public speed:number;
	}
}