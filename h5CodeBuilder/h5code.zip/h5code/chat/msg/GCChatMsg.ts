module game 
{
	export class GCChatMsg
	{
		public channel:number;
		public fromRoleImg:string;
		public fromRoleName:string;
		public fromRoleUUID:number;
		public national:string;
		public lv:number;
		public viplv:number;
		public rank:number;
		public sex:number;
		public content:string;
		public roomNumber:string;
		public msgType:number;
	}
}