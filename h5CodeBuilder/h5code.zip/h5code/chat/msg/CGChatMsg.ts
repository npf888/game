module game 
{
	export class CGChatMsg
	{
		public channel:number;
		public destRoleUUID:number;
		public content:string;
		public roomNumber:string;
		public msgType:number;
	}
}