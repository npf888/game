module game 
{
	export class CGBazooNewGuyProcess
	{
		public modeType:number;
		public process:number;
	}
}