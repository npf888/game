module game 
{
	export class HumanRankInfo
	{
		public passportId:number;
		public vip:number;
		public name:string;
		public headImg:string;
		public gold:number;
	}
}