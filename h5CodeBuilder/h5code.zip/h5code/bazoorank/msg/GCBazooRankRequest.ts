module game 
{
	export class GCBazooRankRequest
	{
		public humanRankInfo:HumanRankInfo[];
	}
}