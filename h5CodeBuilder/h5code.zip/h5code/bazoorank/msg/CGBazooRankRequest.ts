module game 
{
	export class CGBazooRankRequest
	{
		public dateType:number;
	}
}