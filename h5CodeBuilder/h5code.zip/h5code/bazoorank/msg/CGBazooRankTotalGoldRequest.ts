module game 
{
	export class CGBazooRankTotalGoldRequest
	{
	}
}