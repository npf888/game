module game
{
	export class BazoopersonalCGMessage
	{
	}
}
