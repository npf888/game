module game 
{
	export class GCBazooAchieve
	{
		public bazooAchieveInfo:BazooAchieveInfo[];
	}
}