module game 
{
	export class CGBazooAchieveFirst
	{
	}
}