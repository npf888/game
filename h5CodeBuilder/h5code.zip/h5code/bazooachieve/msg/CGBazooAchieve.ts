module game 
{
	export class CGBazooAchieve
	{
	}
}