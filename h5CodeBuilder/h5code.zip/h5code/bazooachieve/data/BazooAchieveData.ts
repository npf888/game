module game 
{
	export class BazooAchieveData
	{
		public achieveId:number;
		public finished:number;
		public finishValues:number;
		public getNums:number;
	}
}