module game 
{
	export class BazooAchieveInfo
	{
		public bigtype:number;
		public modeType:number;
		public wayOfPlay:number;
		public condition:number;
		public rewardNum:number;
		public finishVlaues:number;
		public isFinish:number;
		public nameId:number;
		public descrip:number;
		public icon:string;
	}
}