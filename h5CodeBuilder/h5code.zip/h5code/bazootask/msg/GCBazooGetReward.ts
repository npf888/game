module game 
{
	export class GCBazooGetReward
	{
		public bazooTaskInfo:BazooTaskInfo[];
	}
}