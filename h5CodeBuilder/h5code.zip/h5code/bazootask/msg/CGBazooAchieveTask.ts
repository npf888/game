module game 
{
	export class CGBazooAchieveTask
	{
	}
}