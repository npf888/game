module game 
{
	export class CGBazooGetReward
	{
		public taskId:number;
	}
}