module game 
{
	export class GCBazooAchieveTask
	{
		public bazooTaskInfo:BazooTaskInfo[];
	}
}