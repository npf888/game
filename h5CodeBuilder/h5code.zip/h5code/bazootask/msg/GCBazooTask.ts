module game 
{
	export class GCBazooTask
	{
		public bazooTaskInfo:BazooTaskInfo[];
	}
}