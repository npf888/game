module game 
{
	export class CGBazooTask
	{
	}
}