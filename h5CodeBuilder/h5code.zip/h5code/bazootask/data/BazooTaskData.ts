module game 
{
	export class BazooTaskData
	{
		public taskId:number;
		public type:number;
		public finished:number;
		public finishTimes:number;
		public getNums:number;
	}
}