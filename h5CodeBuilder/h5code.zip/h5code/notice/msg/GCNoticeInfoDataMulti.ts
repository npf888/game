module game 
{
	export class GCNoticeInfoDataMulti
	{
		public langId:number;
		public paramsList:string[];
	}
}