module game 
{
	export class GCNoticeInfoData
	{
		public content:string;
	}
}