module game
{
	export class NoticeCGMessage
	{
	}
}
