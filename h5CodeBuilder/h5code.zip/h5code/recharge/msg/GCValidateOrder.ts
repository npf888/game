module game 
{
	export class GCValidateOrder
	{
		public result:number;
		public orderId:number;
		public pId:number;
		public randRewardList:RandRewardData[];
	}
}