module game 
{
	export class CGRequestOrder
	{
		public productId:number;
	}
}