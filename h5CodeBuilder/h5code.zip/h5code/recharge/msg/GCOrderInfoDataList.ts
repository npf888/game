module game 
{
	export class GCOrderInfoDataList
	{
		public orderList:HumanRechargeOrderInfoData[];
	}
}