module game 
{
	export class CGValidateOrder
	{
		public signature:string;
		public purchaseData:string;
	}
}