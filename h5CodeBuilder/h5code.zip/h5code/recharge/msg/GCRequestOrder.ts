module game 
{
	export class GCRequestOrder
	{
		public order:HumanRechargeOrderInfoData;
	}
}