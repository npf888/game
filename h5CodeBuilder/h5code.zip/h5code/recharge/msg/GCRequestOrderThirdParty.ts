module game 
{
	export class GCRequestOrderThirdParty
	{
		public htmlPage:string;
	}
}