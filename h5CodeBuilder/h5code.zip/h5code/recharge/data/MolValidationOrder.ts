module game 
{
	export class MolValidationOrder
	{
		public referenceId:string;
		public paymentId:string;
	}
}