module game 
{
	export class AmazonDelivery
	{
		public productId:number;
		public receiptId:string;
		public userId:string;
	}
}