module game 
{
	export class BoquData
	{
		public amount:number;
		public info:string;
		public status:string;
	}
}