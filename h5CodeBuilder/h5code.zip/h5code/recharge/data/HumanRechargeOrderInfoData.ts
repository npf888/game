module game 
{
	export class HumanRechargeOrderInfoData
	{
		public orderId:number;
		public productId:number;
		public orderStatus:number;
	}
}