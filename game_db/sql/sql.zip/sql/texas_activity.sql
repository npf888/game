/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50173
Source Host           : localhost:3306
Source Database       : texas_activity

Target Server Type    : MYSQL
Target Server Version : 50173
File Encoding         : 65001

Date: 2018-06-29 18:55:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activity_condition`
-- ----------------------------
DROP TABLE IF EXISTS `activity_condition`;
CREATE TABLE `activity_condition` (
  `condition_id` varchar(45) NOT NULL COMMENT '条件ID代码',
  `title` varchar(45) NOT NULL COMMENT '条件名称',
  `description` varchar(45) DEFAULT NULL COMMENT '条件描述',
  `type` varchar(5) NOT NULL COMMENT '条件类型  T表示Trigger触发条件    R表示Reward奖励',
  `create_time` varchar(45) DEFAULT NULL,
  `activity_type_id` varchar(45) DEFAULT NULL,
  `activity_type_name` varchar(45) DEFAULT NULL,
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='存储触发条件和奖励';

-- ----------------------------
-- Records of activity_condition
-- ----------------------------
INSERT INTO `activity_condition` VALUES ('1', '房间类型', '', 'T', '2015-09-18 13:53:59', '1', '', '8');
INSERT INTO `activity_condition` VALUES ('2', '获胜牌局', '', 'T', '2015-09-18 13:54:17', '1', '', '9');
INSERT INTO `activity_condition` VALUES ('3', '幸运牌型', '', 'T', '2015-09-18 13:54:27', '2', '', '10');
INSERT INTO `activity_condition` VALUES ('4', '小盲注', '', 'T', '2015-09-18 13:54:38', '2', '', '11');
INSERT INTO `activity_condition` VALUES ('5', '充值档次', '', 'T', '2015-09-18 13:54:53', '3', '', '12');
INSERT INTO `activity_condition` VALUES ('1', '平台币', '', 'R', '2015-09-18 13:55:42', '', '', '13');
INSERT INTO `activity_condition` VALUES ('3', '筹码', '', 'R', '2015-09-18 13:55:51', '', '', '14');
INSERT INTO `activity_condition` VALUES ('20002', '菜鸟场门票', '菜鸟场门票', 'R', '2015-10-20 00:42:01', '', '', '15');
INSERT INTO `activity_condition` VALUES ('20003', '普通场门票', '普通场门票', 'R', '2015-10-20 00:42:18', '', '', '16');
INSERT INTO `activity_condition` VALUES ('20004', '精英场门票', '精英场门票', 'R', '2015-10-20 00:42:32', '', '', '17');
INSERT INTO `activity_condition` VALUES ('20005', '卓越场门票', '卓越场门票', 'R', '2015-10-20 00:42:44', '', '', '18');
INSERT INTO `activity_condition` VALUES ('20006', '改名卡', '改名卡', 'R', '2015-10-20 00:42:55', '', '', '19');
INSERT INTO `activity_condition` VALUES ('6', '登录天数', '', 'T', '2016-08-18 13:54:53', '5', '', '21');
INSERT INTO `activity_condition` VALUES ('7', '经验加成系数百分比', '', 'T', '2016-08-18 13:54:54', '6', '', '22');
INSERT INTO `activity_condition` VALUES ('8', '老虎机类型', '', 'T', '2016-08-18 13:54:55', '7', '', '23');
INSERT INTO `activity_condition` VALUES ('9', '旋转次数', '', 'T', '2016-08-18 13:54:56', '7', '', '24');
INSERT INTO `activity_condition` VALUES ('10', '等级', '', 'T', '2016-08-18 13:54:57', '8', '', '25');
INSERT INTO `activity_condition` VALUES ('11', '转动老虎机次数', null, 'T', '2017-05-03 00:10:37', '9', null, '26');
INSERT INTO `activity_condition` VALUES ('12', '消耗筹码', null, 'T', '2017-05-03 00:10:37', '10', null, '27');
INSERT INTO `activity_condition` VALUES ('13', '好友增加数量', null, 'T', '2017-05-03 00:10:37', '11', null, '28');
INSERT INTO `activity_condition` VALUES ('14', '老虎机类型', null, 'T', '2017-05-03 00:10:37', '12', null, '29');
INSERT INTO `activity_condition` VALUES ('15', '转动次数', null, 'T', '2017-05-03 00:10:37', '12', null, '30');
INSERT INTO `activity_condition` VALUES ('16', '转动次数', null, 'T', '2017-05-03 00:10:37', '13', null, '31');
INSERT INTO `activity_condition` VALUES ('17', '老虎机类型', null, 'T', '2017-05-04 13:17:37', '14', null, '32');
INSERT INTO `activity_condition` VALUES ('18', '图标', null, 'T', '2017-05-04 13:18:37', '14', null, '33');
INSERT INTO `activity_condition` VALUES ('19', '出现次数', null, 'T', '2017-05-04 13:17:37', '14', null, '34');
INSERT INTO `activity_condition` VALUES ('6', 'Vip点数', null, 'R', '2017-05-04 18:128:37', null, null, '35');
INSERT INTO `activity_condition` VALUES ('20', '消耗金额', '', 'T', '2017-05-04 13:17:37', '12', '', '36');
INSERT INTO `activity_condition` VALUES ('21', '消耗金额', '', 'T', '2017-05-04 13:17:37', '13', '', '37');
INSERT INTO `activity_condition` VALUES ('22', '美元', '美元', 'T', '2017-07-19 19:31:37', '15', '', '38');
INSERT INTO `activity_condition` VALUES ('23', '次数', '次数', 'T', '2017-07-19 19:31:37', '18', '', '39');
INSERT INTO `activity_condition` VALUES ('24', '连续天数', '连续天数', 'T', '2017-07-19 19:31:37', '16', '', '40');
INSERT INTO `activity_condition` VALUES ('25', '全服累计充值', '全服累计充值', 'T', '2017-07-19 19:31:37', '17', '', '41');

-- ----------------------------
-- Table structure for `country`
-- ----------------------------
DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(32) DEFAULT NULL COMMENT '国家编号',
  `langDesc` varchar(32) DEFAULT NULL COMMENT '国家全名称',
  `icon` varchar(32) DEFAULT NULL,
  `nameId` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of country
-- ----------------------------
INSERT INTO `country` VALUES ('1', 'acl', '系统默认', 'icon_acl', '100234');
INSERT INTO `country` VALUES ('2', 'ad', '安道尔共和国', 'icon_ad', '100235');
INSERT INTO `country` VALUES ('3', 'ae', '阿拉伯联合酋长国', 'icon_ae', '100236');
INSERT INTO `country` VALUES ('4', 'af', '阿富汗', 'icon_af', '100237');
INSERT INTO `country` VALUES ('5', 'ag', '安提瓜和巴布达', 'icon_ag', '100238');
INSERT INTO `country` VALUES ('6', 'ai', '安圭拉岛', 'icon_ai', '100239');
INSERT INTO `country` VALUES ('7', 'al', '阿尔巴尼亚', 'icon_al', '100240');
INSERT INTO `country` VALUES ('8', 'am', '亚美尼亚', 'icon_am', '100241');
INSERT INTO `country` VALUES ('9', 'ao', '安哥拉', 'icon_ao', '100242');
INSERT INTO `country` VALUES ('10', 'ar', '阿根廷', 'icon_ar', '100243');
INSERT INTO `country` VALUES ('11', 'at', '奥地利', 'icon_at', '100244');
INSERT INTO `country` VALUES ('12', 'au', '澳大利亚', 'icon_au', '100245');
INSERT INTO `country` VALUES ('13', 'az', '阿塞拜疆', 'icon_az', '100246');
INSERT INTO `country` VALUES ('14', 'bb', '巴巴多斯', 'icon_bb', '100247');
INSERT INTO `country` VALUES ('15', 'bd', '孟加拉国', 'icon_bd', '100248');
INSERT INTO `country` VALUES ('16', 'be', '比利时', 'icon_be', '100249');
INSERT INTO `country` VALUES ('17', 'bf', '布基纳法索', 'icon_bf', '100250');
INSERT INTO `country` VALUES ('18', 'bg', '保加利亚', 'icon_bg', '100251');
INSERT INTO `country` VALUES ('19', 'bh', '巴林', 'icon_bh', '100252');
INSERT INTO `country` VALUES ('20', 'bi', '布隆迪', 'icon_bi', '100253');
INSERT INTO `country` VALUES ('21', 'bj', '贝宁', 'icon_bj', '100254');
INSERT INTO `country` VALUES ('22', 'bl', '巴勒斯坦', 'icon_bl', '100255');
INSERT INTO `country` VALUES ('23', 'bm', '百慕大群岛', 'icon_bm', '100256');
INSERT INTO `country` VALUES ('24', 'bn', '文莱', 'icon_bn', '100257');
INSERT INTO `country` VALUES ('25', 'bo', '玻利维亚', 'icon_bo', '100258');
INSERT INTO `country` VALUES ('26', 'br', '巴西', 'icon_br', '100259');
INSERT INTO `country` VALUES ('27', 'bs', '巴哈马', 'icon_bs', '100260');
INSERT INTO `country` VALUES ('28', 'bw', '博茨瓦纳', 'icon_bw', '100261');
INSERT INTO `country` VALUES ('29', 'by', '白俄罗斯', 'icon_by', '100262');
INSERT INTO `country` VALUES ('30', 'bz', '伯利兹', 'icon_bz', '100263');
INSERT INTO `country` VALUES ('31', 'ca', '加拿大', 'icon_ca', '100264');
INSERT INTO `country` VALUES ('32', 'cf', '中非共和国', 'icon_cf', '100265');
INSERT INTO `country` VALUES ('33', 'cg', '刚果', 'icon_cg', '100266');
INSERT INTO `country` VALUES ('34', 'ch', '瑞士', 'icon_ch', '100267');
INSERT INTO `country` VALUES ('35', 'ck', '库克群岛', 'icon_ck', '100268');
INSERT INTO `country` VALUES ('36', 'cl', '智利', 'icon_cl', '100269');
INSERT INTO `country` VALUES ('37', 'cm', '喀麦隆', 'icon_cm', '100270');
INSERT INTO `country` VALUES ('38', 'cn', '中国', 'icon_cn', '100271');
INSERT INTO `country` VALUES ('39', 'co', '哥伦比亚', 'icon_co', '100272');
INSERT INTO `country` VALUES ('40', 'cr', '哥斯达黎加', 'icon_cr', '100273');
INSERT INTO `country` VALUES ('41', 'cs', '捷克', 'icon_cs', '100274');
INSERT INTO `country` VALUES ('42', 'cu', '古巴', 'icon_cu', '100275');
INSERT INTO `country` VALUES ('43', 'cy', '塞浦路斯', 'icon_cy', '100276');
INSERT INTO `country` VALUES ('44', 'cz', '捷克', 'icon_cz', '100277');
INSERT INTO `country` VALUES ('45', 'de', '德国', 'icon_de', '100278');
INSERT INTO `country` VALUES ('46', 'dj', '吉布提', 'icon_dj', '100279');
INSERT INTO `country` VALUES ('47', 'dk', '丹麦', 'icon_dk', '100280');
INSERT INTO `country` VALUES ('48', 'do', '多米尼加共和国', 'icon_do', '100281');
INSERT INTO `country` VALUES ('49', 'dz', '阿尔及利亚', 'icon_dz', '100282');
INSERT INTO `country` VALUES ('50', 'ec', '厄瓜多尔', 'icon_ec', '100283');
INSERT INTO `country` VALUES ('51', 'ee', '爱沙尼亚', 'icon_ee', '100284');
INSERT INTO `country` VALUES ('52', 'eg', '埃及', 'icon_eg', '100285');
INSERT INTO `country` VALUES ('53', 'es', '西班牙', 'icon_es', '100286');
INSERT INTO `country` VALUES ('54', 'et', '埃塞俄比亚', 'icon_et', '100287');
INSERT INTO `country` VALUES ('55', 'fi', '芬兰', 'icon_fi', '100288');
INSERT INTO `country` VALUES ('56', 'fj', '斐济', 'icon_fj', '100289');
INSERT INTO `country` VALUES ('57', 'fr', '法国', 'icon_fr', '100290');
INSERT INTO `country` VALUES ('58', 'ga', '加蓬', 'icon_ga', '100291');
INSERT INTO `country` VALUES ('59', 'gb', '英国', 'icon_gb', '100292');
INSERT INTO `country` VALUES ('60', 'gd', '格林纳达', 'icon_gd', '100293');
INSERT INTO `country` VALUES ('61', 'ge', '格鲁吉亚', 'icon_ge', '100294');
INSERT INTO `country` VALUES ('62', 'gf', '法属圭亚那', 'icon_gf', '100295');
INSERT INTO `country` VALUES ('63', 'gh', '加纳', 'icon_gh', '100296');
INSERT INTO `country` VALUES ('64', 'gi', '直布罗陀', 'icon_gi', '100297');
INSERT INTO `country` VALUES ('65', 'gm', '冈比亚', 'icon_gm', '100298');
INSERT INTO `country` VALUES ('66', 'gn', '几内亚', 'icon_gn', '100299');
INSERT INTO `country` VALUES ('67', 'gr', '希腊', 'icon_gr', '100300');
INSERT INTO `country` VALUES ('68', 'gt', '危地马拉', 'icon_gt', '100301');
INSERT INTO `country` VALUES ('69', 'gu', '关岛', 'icon_gu', '100302');
INSERT INTO `country` VALUES ('70', 'gy', '圭亚那', 'icon_gy', '100303');
INSERT INTO `country` VALUES ('71', 'hk', '香港特别行政区', 'icon_hk', '100304');
INSERT INTO `country` VALUES ('72', 'hn', '洪都拉斯', 'icon_hn', '100305');
INSERT INTO `country` VALUES ('73', 'ht', '海地', 'icon_ht', '100306');
INSERT INTO `country` VALUES ('74', 'hu', '匈牙利', 'icon_hu', '100307');
INSERT INTO `country` VALUES ('75', 'id', '印度尼西亚', 'icon_id', '100308');
INSERT INTO `country` VALUES ('76', 'ie', '爱尔兰', 'icon_ie', '100309');
INSERT INTO `country` VALUES ('77', 'il', '以色列', 'icon_il', '100310');
INSERT INTO `country` VALUES ('78', 'in', '印度', 'icon_in', '100311');
INSERT INTO `country` VALUES ('79', 'iq', '伊拉克', 'icon_iq', '100312');
INSERT INTO `country` VALUES ('80', 'ir', '伊朗', 'icon_ir', '100313');
INSERT INTO `country` VALUES ('81', 'is', '冰岛', 'icon_is', '100314');
INSERT INTO `country` VALUES ('82', 'it', '意大利', 'icon_it', '100315');
INSERT INTO `country` VALUES ('83', 'jm', '牙买加', 'icon_jm', '100316');
INSERT INTO `country` VALUES ('84', 'jo', '约旦', 'icon_jo', '100317');
INSERT INTO `country` VALUES ('85', 'jp', '日本', 'icon_jp', '100318');
INSERT INTO `country` VALUES ('86', 'ke', '肯尼亚', 'icon_ke', '100319');
INSERT INTO `country` VALUES ('87', 'kg', '吉尔吉斯坦', 'icon_kg', '100320');
INSERT INTO `country` VALUES ('88', 'kh', '柬埔寨', 'icon_kh', '100321');
INSERT INTO `country` VALUES ('89', 'kp', '朝鲜', 'icon_kp', '100322');
INSERT INTO `country` VALUES ('90', 'kr', '韩国', 'icon_kr', '100323');
INSERT INTO `country` VALUES ('91', 'kt', '科特迪瓦共和国', 'icon_kt', '100324');
INSERT INTO `country` VALUES ('92', 'kw', '科威特', 'icon_kw', '100325');
INSERT INTO `country` VALUES ('93', 'kz', '哈萨克斯坦', 'icon_kz', '100326');
INSERT INTO `country` VALUES ('94', 'la', '老挝', 'icon_la', '100327');
INSERT INTO `country` VALUES ('95', 'lb', '黎巴嫩', 'icon_lb', '100328');
INSERT INTO `country` VALUES ('96', 'lc', '圣卢西亚', 'icon_lc', '100329');
INSERT INTO `country` VALUES ('97', 'li', '列支敦士登', 'icon_li', '100330');
INSERT INTO `country` VALUES ('98', 'lk', '斯里兰卡', 'icon_lk', '100331');
INSERT INTO `country` VALUES ('99', 'lr', '利比里亚', 'icon_lr', '100332');
INSERT INTO `country` VALUES ('100', 'ls', '莱索托', 'icon_ls', '100333');
INSERT INTO `country` VALUES ('101', 'lt', '立陶宛', 'icon_lt', '100334');
INSERT INTO `country` VALUES ('102', 'lu', '卢森堡', 'icon_lu', '100335');
INSERT INTO `country` VALUES ('103', 'lv', '拉脱维亚', 'icon_lv', '100336');
INSERT INTO `country` VALUES ('104', 'ly', '利比亚', 'icon_ly', '100337');
INSERT INTO `country` VALUES ('105', 'ma', '摩洛哥', 'icon_ma', '100338');
INSERT INTO `country` VALUES ('106', 'mc', '摩纳哥', 'icon_mc', '100339');
INSERT INTO `country` VALUES ('107', 'md', '摩尔多瓦', 'icon_md', '100340');
INSERT INTO `country` VALUES ('108', 'mg', '马达加斯加', 'icon_mg', '100341');
INSERT INTO `country` VALUES ('109', 'ml', '马里', 'icon_ml', '100342');
INSERT INTO `country` VALUES ('110', 'mm', '缅甸', 'icon_mm', '100343');
INSERT INTO `country` VALUES ('111', 'mn', '蒙古', 'icon_mn', '100344');
INSERT INTO `country` VALUES ('112', 'mo', '澳门', 'icon_mo', '100345');
INSERT INTO `country` VALUES ('113', 'ms', '蒙特塞拉特岛', 'icon_ms', '100346');
INSERT INTO `country` VALUES ('114', 'mt', '马耳他', 'icon_mt', '100347');
INSERT INTO `country` VALUES ('115', 'mu', '毛里求斯', 'icon_mu', '100348');
INSERT INTO `country` VALUES ('116', 'mv', '马尔代夫', 'icon_mv', '100349');
INSERT INTO `country` VALUES ('117', 'mw', '马拉维', 'icon_mw', '100350');
INSERT INTO `country` VALUES ('118', 'mx', '墨西哥', 'icon_mx', '100351');
INSERT INTO `country` VALUES ('119', 'my', '马来西亚', 'icon_my', '100352');
INSERT INTO `country` VALUES ('120', 'mz', '莫桑比克', 'icon_mz', '100353');
INSERT INTO `country` VALUES ('121', 'na', '纳米比亚', 'icon_na', '100354');
INSERT INTO `country` VALUES ('122', 'ne', '尼日尔', 'icon_ne', '100355');
INSERT INTO `country` VALUES ('123', 'ng', '尼日利亚', 'icon_ng', '100356');
INSERT INTO `country` VALUES ('124', 'ni', '尼加拉瓜', 'icon_ni', '100357');
INSERT INTO `country` VALUES ('125', 'nl', '荷兰', 'icon_nl', '100358');
INSERT INTO `country` VALUES ('126', 'no', '挪威', 'icon_no', '100359');
INSERT INTO `country` VALUES ('127', 'np', '尼泊尔', 'icon_np', '100360');
INSERT INTO `country` VALUES ('128', 'nr', '瑙鲁', 'icon_nr', '100361');
INSERT INTO `country` VALUES ('129', 'nz', '新西兰', 'icon_nz', '100362');
INSERT INTO `country` VALUES ('130', 'om', '阿曼', 'icon_om', '100363');
INSERT INTO `country` VALUES ('131', 'pa', '巴拿马', 'icon_pa', '100364');
INSERT INTO `country` VALUES ('132', 'pe', '秘鲁', 'icon_pe', '100365');
INSERT INTO `country` VALUES ('133', 'pf', '法属玻利尼西亚', 'icon_pf', '100366');
INSERT INTO `country` VALUES ('134', 'pg', '巴布亚新几内亚', 'icon_pg', '100367');
INSERT INTO `country` VALUES ('135', 'ph', '菲律宾', 'icon_ph', '100368');
INSERT INTO `country` VALUES ('136', 'pk', '巴基斯坦', 'icon_pk', '100369');
INSERT INTO `country` VALUES ('137', 'pl', '波兰', 'icon_pl', '100370');
INSERT INTO `country` VALUES ('138', 'pr', '波多黎各', 'icon_pr', '100371');
INSERT INTO `country` VALUES ('139', 'pt', '葡萄牙', 'icon_pt', '100372');
INSERT INTO `country` VALUES ('140', 'py', '巴拉圭', 'icon_py', '100373');
INSERT INTO `country` VALUES ('141', 'qa', '卡塔尔', 'icon_qa', '100374');
INSERT INTO `country` VALUES ('142', 'ro', '罗马尼亚', 'icon_ro', '100375');
INSERT INTO `country` VALUES ('143', 'ru', '俄罗斯', 'icon_ru', '100376');
INSERT INTO `country` VALUES ('144', 'sa', '沙特阿拉伯', 'icon_sa', '100377');
INSERT INTO `country` VALUES ('145', 'sb', '所罗门群岛', 'icon_sb', '100378');
INSERT INTO `country` VALUES ('146', 'sc', '塞舌尔', 'icon_sc', '100379');
INSERT INTO `country` VALUES ('147', 'sd', '苏丹', 'icon_sd', '100380');
INSERT INTO `country` VALUES ('148', 'se', '瑞典', 'icon_se', '100381');
INSERT INTO `country` VALUES ('149', 'sg', '新加坡', 'icon_sg', '100382');
INSERT INTO `country` VALUES ('150', 'si', '斯洛文尼亚', 'icon_si', '100383');
INSERT INTO `country` VALUES ('151', 'sk', '斯洛伐克', 'icon_sk', '100384');
INSERT INTO `country` VALUES ('152', 'sl', '塞拉利昂', 'icon_sl', '100385');
INSERT INTO `country` VALUES ('153', 'sm', '圣马力诺', 'icon_sm', '100386');
INSERT INTO `country` VALUES ('154', 'sn', '塞内加尔', 'icon_sn', '100387');
INSERT INTO `country` VALUES ('155', 'so', '索马里', 'icon_so', '100388');
INSERT INTO `country` VALUES ('156', 'sr', '苏里南', 'icon_sr', '100389');
INSERT INTO `country` VALUES ('157', 'st', '圣多美和普林西比', 'icon_st', '100390');
INSERT INTO `country` VALUES ('158', 'sv', '萨尔瓦多', 'icon_sv', '100391');
INSERT INTO `country` VALUES ('159', 'sy', '叙利亚', 'icon_sy', '100392');
INSERT INTO `country` VALUES ('160', 'sz', '斯威士兰', 'icon_sz', '100393');
INSERT INTO `country` VALUES ('161', 'td', '乍得', 'icon_td', '100394');
INSERT INTO `country` VALUES ('162', 'tg', '多哥', 'icon_tg', '100395');
INSERT INTO `country` VALUES ('163', 'th', '泰国', 'icon_th', '100396');
INSERT INTO `country` VALUES ('164', 'tj', '塔吉克斯坦', 'icon_tj', '100397');
INSERT INTO `country` VALUES ('165', 'tm', '土库曼斯坦', 'icon_tm', '100398');
INSERT INTO `country` VALUES ('166', 'tn', '突尼斯', 'icon_tn', '100399');
INSERT INTO `country` VALUES ('167', 'to', '汤加', 'icon_to', '100400');
INSERT INTO `country` VALUES ('168', 'tr', '土耳其', 'icon_tr', '100401');
INSERT INTO `country` VALUES ('169', 'tt', '特立尼达和多巴哥', 'icon_tt', '100402');
INSERT INTO `country` VALUES ('170', 'tw', '台湾省', 'icon_tw', '100403');
INSERT INTO `country` VALUES ('171', 'tz', '坦桑尼亚', 'icon_tz', '100404');
INSERT INTO `country` VALUES ('172', 'ua', '乌克兰', 'icon_ua', '100405');
INSERT INTO `country` VALUES ('173', 'ug', '乌干达', 'icon_ug', '100406');
INSERT INTO `country` VALUES ('174', 'us', '美国', 'icon_us', '100407');
INSERT INTO `country` VALUES ('175', 'uy', '乌拉圭', 'icon_uy', '100408');
INSERT INTO `country` VALUES ('176', 'uz', '乌兹别克斯坦', 'icon_uz', '100409');
INSERT INTO `country` VALUES ('177', 'vc', '圣文森特岛', 'icon_vc', '100410');
INSERT INTO `country` VALUES ('178', 've', '委内瑞拉', 'icon_ve', '100411');
INSERT INTO `country` VALUES ('179', 'vn', '越南', 'icon_vn', '100412');
INSERT INTO `country` VALUES ('180', 'ye', '也门', 'icon_ye', '100413');
INSERT INTO `country` VALUES ('181', 'yu', '南斯拉夫', 'icon_yu', '100414');
INSERT INTO `country` VALUES ('182', 'za', '南非', 'icon_za', '100415');
INSERT INTO `country` VALUES ('183', 'zm', '赞比亚', 'icon_zm', '100416');
INSERT INTO `country` VALUES ('184', 'zr', '扎伊尔', 'icon_zr', '100417');
INSERT INTO `country` VALUES ('185', 'zw', '津巴布韦', 'icon_zw', '100418');

-- ----------------------------
-- Table structure for `t_activity`
-- ----------------------------
DROP TABLE IF EXISTS `t_activity`;
CREATE TABLE `t_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `activityType` int(11) DEFAULT '0' COMMENT '活动类型',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `desc` varchar(100) DEFAULT NULL COMMENT '描述',
  `pic` varchar(50) DEFAULT NULL COMMENT '活动图片',
  `rulePack` varchar(5000) DEFAULT NULL COMMENT '活动',
  `daily` int(11) DEFAULT '0' COMMENT '每天刷新',
  `startTime` bigint(20) DEFAULT '0' COMMENT '开始时间',
  `endTime` bigint(20) DEFAULT '0' COMMENT '结束时间',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_activity
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_task_template`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_task_template`;
CREATE TABLE `t_human_task_template` (
  `id` bigint(20) NOT NULL,
  `conditions` bigint(20) DEFAULT NULL COMMENT '条件(判断是否完成的条件，大于等于此条件）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_task_template
-- ----------------------------
INSERT INTO `t_human_task_template` VALUES ('30000', '1');
INSERT INTO `t_human_task_template` VALUES ('30001', '5');
INSERT INTO `t_human_task_template` VALUES ('30002', '10');
INSERT INTO `t_human_task_template` VALUES ('30003', '30');
INSERT INTO `t_human_task_template` VALUES ('30004', '50');
INSERT INTO `t_human_task_template` VALUES ('30005', '100');
INSERT INTO `t_human_task_template` VALUES ('30006', '1');
INSERT INTO `t_human_task_template` VALUES ('30007', '5');
INSERT INTO `t_human_task_template` VALUES ('30008', '10');
INSERT INTO `t_human_task_template` VALUES ('30009', '30');
INSERT INTO `t_human_task_template` VALUES ('30010', '50');
INSERT INTO `t_human_task_template` VALUES ('30011', '100');
INSERT INTO `t_human_task_template` VALUES ('30012', '4000');
INSERT INTO `t_human_task_template` VALUES ('30013', '40000');
INSERT INTO `t_human_task_template` VALUES ('30014', '400000');
INSERT INTO `t_human_task_template` VALUES ('30015', '1');
INSERT INTO `t_human_task_template` VALUES ('30016', '5');
INSERT INTO `t_human_task_template` VALUES ('30017', '10');
INSERT INTO `t_human_task_template` VALUES ('30018', '30');
INSERT INTO `t_human_task_template` VALUES ('30019', '50');
INSERT INTO `t_human_task_template` VALUES ('30020', '100');
INSERT INTO `t_human_task_template` VALUES ('30021', '1');
INSERT INTO `t_human_task_template` VALUES ('30022', '5');
INSERT INTO `t_human_task_template` VALUES ('30023', '10');
INSERT INTO `t_human_task_template` VALUES ('30024', '30');
INSERT INTO `t_human_task_template` VALUES ('30025', '50');
INSERT INTO `t_human_task_template` VALUES ('30026', '100');
INSERT INTO `t_human_task_template` VALUES ('30027', '4000');
INSERT INTO `t_human_task_template` VALUES ('30028', '40000');
INSERT INTO `t_human_task_template` VALUES ('30029', '400000');
INSERT INTO `t_human_task_template` VALUES ('30030', '1');
INSERT INTO `t_human_task_template` VALUES ('30031', '1');
INSERT INTO `t_human_task_template` VALUES ('30032', '1');
INSERT INTO `t_human_task_template` VALUES ('30033', '5');
INSERT INTO `t_human_task_template` VALUES ('30034', '10');
INSERT INTO `t_human_task_template` VALUES ('30035', '1');
INSERT INTO `t_human_task_template` VALUES ('30036', '1');
INSERT INTO `t_human_task_template` VALUES ('30037', '10');
INSERT INTO `t_human_task_template` VALUES ('30038', '25');
INSERT INTO `t_human_task_template` VALUES ('30039', '50');
INSERT INTO `t_human_task_template` VALUES ('30040', '1');
INSERT INTO `t_human_task_template` VALUES ('30041', '1');
INSERT INTO `t_human_task_template` VALUES ('30042', '10');
INSERT INTO `t_human_task_template` VALUES ('30043', '25');
INSERT INTO `t_human_task_template` VALUES ('30044', '50');
INSERT INTO `t_human_task_template` VALUES ('30045', '1');
INSERT INTO `t_human_task_template` VALUES ('30046', '1');
INSERT INTO `t_human_task_template` VALUES ('30047', '10');
INSERT INTO `t_human_task_template` VALUES ('30048', '25');
INSERT INTO `t_human_task_template` VALUES ('30049', '50');
INSERT INTO `t_human_task_template` VALUES ('30050', '1');

-- ----------------------------
-- Table structure for `t_recharge`
-- ----------------------------
DROP TABLE IF EXISTS `t_recharge`;
CREATE TABLE `t_recharge` (
  `id` int(11) NOT NULL DEFAULT '0',
  `channelId` int(11) DEFAULT NULL COMMENT '渠道ID',
  `pid` int(11) DEFAULT NULL,
  `nameId` int(11) DEFAULT NULL,
  `descrip` int(11) DEFAULT NULL,
  `langDesc` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `itemNum` int(11) DEFAULT NULL,
  `giftNum` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL COMMENT '产品ID',
  `used` tinyint(1) DEFAULT NULL COMMENT '是否使用，1：是，0：否',
  `mark` int(11) DEFAULT NULL COMMENT '显示标签：0：没有，1：best value，2：most popular',
  `itemId` int(11) DEFAULT NULL COMMENT '对应物品表的ID',
  `smallCategory` int(11) DEFAULT NULL COMMENT '小类：1、筹码2、周卡3、月卡4、门票5、改名卡 6、付费转盘,7、翻倍转盘8、奖券9、俱乐部礼包10、金库（小金猪）11、新手礼包',
  `vipPoint` int(11) DEFAULT NULL COMMENT '购买获得的vip点数',
  `category` int(5) DEFAULT NULL COMMENT '类别：1、筹码；2:物品3、礼包 4、功能性付费',
  `payType` int(11) DEFAULT NULL COMMENT '支付方式：0：其他 1：mycard，2：Mol',
  `itemType` int(11) DEFAULT NULL COMMENT '0.无分页 1.金币 2.道具 3.奖券',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_recharge
-- ----------------------------
INSERT INTO `t_recharge` VALUES ('1', '0', '1', '100000', '100000', '筹码', 'icon_chips1', '199', '200000', '0', 'goddesscasino.gems.1', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('2', '0', '2', '100000', '100000', '筹码', 'icon_chips2', '499', '600000', '0', 'goddesscasino.gems.2', '1', '0', '3', '1', '50', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('3', '0', '3', '100000', '100000', '筹码', 'icon_chips3', '999', '1500000', '0', 'goddesscasino.gems.3', '1', '0', '3', '1', '100', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('4', '0', '4', '100000', '100000', '筹码', 'icon_chips4', '1999', '3500000', '0', 'goddesscasino.gems.4', '1', '2', '3', '1', '200', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('5', '0', '5', '100000', '100000', '筹码', 'icon_chips5', '4999', '10000000', '0', 'goddesscasino.gems.5', '1', '1', '3', '1', '500', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('6', '0', '7', '100000', '100000', '筹码', 'icon_chips1', '199', '1', '0', 'android.test.purchased', '0', '0', '3', '1', '10', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('7', '0', '10', '100055', '100056', '改名卡', 'icon_changeName', '99', '1', '0', 'goddesscasino_chips7', '1', '0', '20006', '5', '2', '2', '0', '0');
INSERT INTO `t_recharge` VALUES ('8', '0', '11', '100000', '100000', '商店礼包', 'icon_chips1', '199', '230000', '0', 'goddesscasino_chips10', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('9', '0', '12', '100000', '100000', '礼包', 'icon_chips1', '199', '220000', '0', 'goddesscasino_chips1', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('10', '0', '13', '100000', '100000', '礼包', 'icon_chips1', '499', '660000', '0', 'goddesscasino_chips2', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('11', '0', '14', '100000', '100000', '礼包', 'icon_chips1', '999', '1650000', '0', 'goddesscasino_chips3', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('12', '0', '15', '100000', '100000', '礼包', 'icon_chips1', '1999', '3850000', '0', 'goddesscasino_chips4', '1', '0', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('13', '0', '16', '100000', '100000', '礼包', 'icon_chips1', '4999', '11000000', '0', 'goddesscasino_chips5', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('14', '0', '17', '100000', '100000', '礼包', 'icon_chips1', '9999', '33000000', '0', 'goddesscasino_chips6', '1', '0', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('15', '0', '18', '100000', '100000', 'mycard充值', 'icon_chips2', '50', '150000', '0', 'mycard50', '1', '0', '3', '1', '10', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('16', '0', '19', '100000', '100000', 'mycard充值', 'icon_chips3', '150', '540000', '0', 'mycard150', '1', '0', '3', '1', '30', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('17', '0', '20', '100000', '100000', 'mycard充值', 'icon_chips4', '300', '1380000', '0', 'mycard300', '1', '0', '3', '1', '60', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('18', '0', '21', '100000', '100000', 'mycard充值', 'icon_chips5', '350', '1680000', '0', 'mycard350', '1', '0', '3', '1', '70', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('19', '0', '22', '100000', '100000', 'mycard充值', 'icon_chips6', '400', '2000000', '0', 'mycard400', '1', '0', '3', '1', '80', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('20', '0', '23', '100000', '100000', 'mycard充值', 'icon_chips7', '450', '2340000', '0', 'mycard450', '1', '0', '3', '1', '90', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('21', '0', '24', '100000', '100000', 'mycard充值', 'icon_chips8', '500', '2700000', '0', 'mycard500', '1', '0', '3', '1', '100', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('22', '0', '25', '100000', '100000', 'mycard充值', 'icon_chips9', '1000', '5800000', '0', 'mycard1000', '1', '0', '3', '1', '200', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('23', '0', '26', '100000', '100000', 'mycard充值', 'icon_chips10', '1150', '6900000', '0', 'mycard1150', '1', '0', '3', '1', '230', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('24', '0', '27', '100000', '100000', 'mycard充值', 'icon_chips11', '2000', '14000000', '0', 'mycard2000', '1', '0', '3', '1', '400', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('25', '0', '28', '100000', '100000', 'mycard充值', 'icon_chips12', '3000', '24000000', '0', 'mycard3000', '1', '0', '3', '1', '600', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('26', '0', '29', '100000', '100000', 'mycard充值', 'icon_chips13', '5000', '50000000', '0', 'mycard5000', '1', '0', '3', '1', '1000', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('27', '0', '30', '100000', '100000', 'mycard充值', 'icon_chips14', '10000', '120000000', '0', 'mycard10000', '1', '0', '3', '1', '2000', '1', '1', '0');
INSERT INTO `t_recharge` VALUES ('28', '0', '-1', '100000', '100000', 'MOL充值专用', 'icon_chips2', '500', '150000', '0', 'MOL专用', '1', '0', '3', '1', '10', '1', '2', '0');
INSERT INTO `t_recharge` VALUES ('29', '7', '1', '100000', '100000', '筹码', 'icon_chips1', '1000000', '200000', '0', 'goddesscasino.gems.1', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('30', '7', '2', '100000', '100000', '筹码', 'icon_chips2', '2000000', '600000', '0', 'goddesscasino.gems.2', '1', '0', '3', '1', '50', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('31', '7', '3', '100000', '100000', '筹码', 'icon_chips3', '5000000', '1500000', '0', 'goddesscasino.gems.3', '1', '0', '3', '1', '100', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('32', '7', '4', '100000', '100000', '筹码', 'icon_chips4', '10000000', '3500000', '0', 'goddesscasino.gems.4', '1', '2', '3', '1', '200', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('33', '7', '5', '100000', '100000', '筹码', 'icon_chips5', '30000000', '10000000', '0', 'goddesscasino.gems.5', '1', '0', '3', '1', '500', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('34', '14', '1', '100000', '100000', 'GV商店筹码', 'icon_chips1', '199', '200000', '0', '200000', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('35', '14', '2', '100000', '100000', 'GV商店筹码', 'icon_chips1', '499', '600000', '0', '600000', '1', '0', '3', '1', '50', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('36', '14', '3', '100000', '100000', 'GV商店筹码', 'icon_chips1', '999', '1500000', '0', '1500000', '1', '0', '3', '1', '100', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('37', '14', '4', '100000', '100000', 'GV商店筹码', 'icon_chips1', '1999', '3500000', '0', '3500000', '1', '0', '3', '1', '200', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('38', '14', '5', '100000', '100000', 'GV商店筹码', 'icon_chips1', '4999', '10000000', '0', '10000000', '1', '0', '3', '1', '500', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('39', '14', '6', '100000', '100000', 'GV商店筹码', 'icon_chips1', '9999', '30000000', '0', '30000000', '1', '0', '3', '1', '1000', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('40', '14', '9', '100003', '100009', 'GV月卡', 'item_aceelitepass_30d', '499', '1', '0', '50', '1', '0', '20000', '3', '50', '2', '0', '0');
INSERT INTO `t_recharge` VALUES ('41', '14', '10', '100055', '100056', 'GV改名卡', 'icon_changeName', '99', '1', '0', '10', '1', '0', '20006', '5', '10', '2', '0', '0');
INSERT INTO `t_recharge` VALUES ('42', '14', '11', '100000', '100000', 'GV商店礼包', 'icon_chips1', '199', '230000', '0', '230000', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('43', '14', '12', '100000', '100000', 'GV礼包', 'icon_chips1', '199', '220000', '0', '220000', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('44', '14', '13', '100000', '100000', 'GV礼包', 'icon_chips1', '499', '660000', '0', '660000', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('45', '14', '14', '100000', '100000', 'GV礼包', 'icon_chips1', '999', '1650000', '0', '1650000', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('46', '14', '15', '100000', '100000', 'GV礼包', 'icon_chips1', '1999', '3850000', '0', '3850000', '1', '2', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('47', '14', '16', '100000', '100000', 'GV礼包', 'icon_chips1', '4999', '11000000', '0', '11000000', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('48', '14', '17', '100000', '100000', 'GV礼包', 'icon_chips1', '9999', '33000000', '0', '33000000', '1', '1', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('49', '15', '1', '100000', '100000', '筹码', 'icon_chips1', '199', '200000', '0', 'goddesscasino.gems.1', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('50', '15', '2', '100000', '100000', '筹码', 'icon_chips2', '499', '600000', '0', 'goddesscasino.gems.2', '1', '0', '3', '1', '50', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('51', '15', '3', '100000', '100000', '筹码', 'icon_chips3', '999', '1500000', '0', 'goddesscasino.gems.3', '1', '0', '3', '1', '100', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('52', '15', '4', '100000', '100000', '筹码', 'icon_chips4', '1999', '3500000', '0', 'goddesscasino.gems.4', '1', '2', '3', '1', '200', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('53', '15', '5', '100000', '100000', '筹码', 'icon_chips5', '4999', '10000000', '0', 'goddesscasino.gems.5', '1', '1', '3', '1', '500', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('54', '15', '10', '100055', '100056', '改名卡', 'icon_changeName', '99', '1', '0', 'goddesscasino_chips7', '1', '0', '20006', '5', '2', '2', '0', '0');
INSERT INTO `t_recharge` VALUES ('55', '15', '11', '100000', '100000', '商店礼包', 'icon_chips1', '199', '230000', '0', 'goddesscasino_chips10', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('56', '15', '12', '100000', '100000', '礼包', 'icon_chips1', '199', '220000', '0', 'goddesscasino_chips1', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('57', '15', '13', '100000', '100000', '礼包', 'icon_chips1', '499', '660000', '0', 'goddesscasino_chips2', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('58', '15', '14', '100000', '100000', '礼包', 'icon_chips1', '999', '1650000', '0', 'goddesscasino_chips3', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('59', '15', '15', '100000', '100000', '礼包', 'icon_chips1', '1999', '3850000', '0', 'goddesscasino_chips4', '1', '0', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('60', '15', '16', '100000', '100000', '礼包', 'icon_chips1', '4999', '11000000', '0', 'goddesscasino_chips5', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('61', '15', '17', '100000', '100000', '礼包', 'icon_chips1', '9999', '33000000', '0', 'goddesscasino_chips6', '1', '0', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('62', '15', '31', '100000', '100000', '转盘价格', 'icon_chips1', '199', '1', '0', 'goddesscasino_chips15', '1', '0', '3', '6', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('63', '15', '32', '100000', '100000', '翻倍转盘', 'icon_chips1', '199', '1', '0', 'goddesscasino_chips16', '1', '0', '3', '7', '0', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('64', '15', '33', '100000', '100000', '铜券', 'icon_copperTicken', '100', '1', '0', 'goddesscasino_chips17', '1', '0', '20007', '8', '10', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('65', '15', '34', '100000', '100000', '银券', 'icon_silverTicken', '200', '1', '0', 'goddesscasino_chips18', '1', '0', '20008', '8', '20', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('66', '15', '35', '100000', '100000', '金券', 'icon_goldTicken', '300', '1', '0', 'goddesscasino_chips19', '1', '0', '20009', '8', '30', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('67', '15', '36', '100000', '100000', '五张铜券', 'icon_copperTicken5', '400', '5', '0', 'goddesscasino_chips20', '1', '0', '20007', '8', '40', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('68', '15', '37', '100000', '100000', '一打铜券', 'icon_copperTicken10', '500', '10', '0', 'goddesscasino_chips21', '1', '0', '20007', '8', '50', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('69', '15', '38', '100000', '100000', '一箱铜券', 'icon_copperTicken50', '600', '50', '0', 'goddesscasino_chips22', '1', '0', '20007', '8', '60', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('70', '15', '39', '100000', '100000', '五张银券', 'icon_silverTicken5', '700', '5', '0', 'goddesscasino_chips23', '1', '0', '20008', '8', '70', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('71', '15', '40', '100000', '100000', '一打银券', 'icon_silverTicken10', '800', '10', '0', 'goddesscasino_chips24', '1', '0', '20008', '8', '80', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('72', '15', '41', '100000', '100000', '一箱银券', 'icon_silverTicken50', '900', '50', '0', 'goddesscasino_chips25', '1', '0', '20008', '8', '90', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('73', '15', '42', '100000', '100000', '五张金券', 'icon_goldTicken5', '1000', '5', '0', 'goddesscasino_chips26', '1', '0', '20009', '8', '100', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('74', '15', '43', '100000', '100000', '一打金券', 'icon_goldTicken10', '1100', '10', '0', 'goddesscasino_chips27', '1', '0', '20009', '8', '110', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('75', '15', '44', '100000', '100000', '一箱金券', 'icon_goldTicken50', '1200', '50', '0', 'goddesscasino_chips28', '1', '0', '20009', '8', '120', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('76', '15', '45', '100000', '100000', '周卡', 'item_acepass_7d', '2999', '1', '0', 'goddesscasino_chips29', '1', '0', '20001', '2', '200', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('77', '15', '46', '100000', '100000', '月卡', 'item_aceelitepass_30d', '9999', '1', '0', 'goddesscasino_chips30', '1', '0', '20000', '3', '300', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('78', '15', '47', '100000', '100000', '双倍经验卡', 'icon_experience1', '299', '1', '0', 'goddesscasino_experience1', '1', '0', '20022', '9', '30', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('79', '15', '48', '100000', '100000', '金库0', 'icon_chips1', '199', '1', '0', 'goddesscasino_treasury0', '1', '0', '1', '1', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('80', '15', '49', '100000', '100000', '金库1', 'icon_chips1', '399', '1', '0', 'goddesscasino_treasury1', '1', '0', '1', '1', '40', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('81', '15', '50', '100000', '100000', '金库2', 'icon_chips1', '599', '1', '0', 'goddesscasino_treasury2', '1', '0', '1', '1', '60', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('82', '15', '51', '100000', '100000', '金库3', 'icon_chips1', '1199', '1', '0', 'goddesscasino_treasury3', '1', '0', '1', '1', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('83', '15', '52', '100000', '100000', '金库4', 'icon_chips1', '2999', '1', '0', 'goddesscasino_treasury4', '1', '0', '1', '1', '300', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('84', '15', '53', '100000', '100000', '金库5', 'icon_chips1', '3999', '1', '0', 'goddesscasino_treasury5', '1', '0', '1', '1', '400', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('85', '15', '54', '100000', '100000', '周礼包V0、V1', 'icon_chips1', '999', '3000000', '0', 'goddesscasino_weeklypack1', '1', '0', '1', '1', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('86', '15', '55', '100000', '100000', '周礼包V2及以上', 'icon_chips1', '1499', '4500000', '0', 'goddesscasino_weeklypack2', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('87', '15', '56', '100000', '100000', '月礼包V0、V1', 'icon_chips1', '1499', '7500000', '0', 'goddesscasino_monthlypack1', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('88', '15', '57', '100000', '100000', '月礼包V2及以上', 'icon_chips1', '1999', '10000000', '0', 'goddesscasino_monthlypack2', '1', '0', '1', '1', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('89', '15', '58', '100000', '100000', '新手礼包', 'icon_newpack', '499', '660000', '0', 'goddesscasino_newpack', '1', '0', '3', '11', '5000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('90', '15', '59', '100000', '100000', '俱乐部礼包', 'icon_clubpack', '599', '700000', '0', 'goddesscasino_clubpack', '1', '0', '60000', '9', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('91', '15', '60', '100000', '100000', '俱乐部改名卡', 'icon_clubname', '499', '1', '0', 'goddesscasino_clubname', '1', '0', '20027', '1', '50', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('92', '16', '1', '100000', '100000', '筹码', 'icon_chips1', '299', '90000', '0', 'gundemcasino.chips1', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('93', '16', '2', '100000', '100000', '筹码', 'icon_chips2', '999', '360000', '0', 'gundemcasino.chips2', '1', '0', '3', '1', '50', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('94', '16', '3', '100000', '100000', '筹码', 'icon_chips3', '2999', '1350000', '0', 'gundemcasino.chips3', '1', '0', '3', '1', '100', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('95', '16', '4', '100000', '100000', '筹码', 'icon_chips4', '6999', '3675000', '0', 'gundemcasino.chips4', '1', '2', '3', '1', '200', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('96', '16', '5', '100000', '100000', '筹码', 'icon_chips5', '9999', '6000000', '0', 'gundemcasino.chips5', '1', '0', '3', '1', '500', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('97', '16', '6', '100000', '100000', '筹码', 'icon_chips6', '19999', '18000000', '0', 'gundemcasino.chips6', '1', '1', '3', '1', '1000', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('98', '16', '10', '100055', '100056', '改名卡', 'icon_changeName', '299', '1', '0', 'gundemcasino.chips7', '1', '0', '20006', '5', '2', '2', '0', '0');
INSERT INTO `t_recharge` VALUES ('99', '16', '11', '100000', '100000', '商店礼包', 'icon_chips1', '299', '9900', '0', 'gundemcasino.chips8', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('100', '16', '12', '100000', '100000', '礼包', 'icon_chips1', '299', '9900', '0', 'gundemcasino.chips9', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('101', '16', '13', '100000', '100000', '礼包', 'icon_chips1', '999', '396000', '0', 'gundemcasino.chips10', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('102', '16', '14', '100000', '100000', '礼包', 'icon_chips1', '2999', '1485000', '0', 'gundemcasino.chips11', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('103', '16', '15', '100000', '100000', '礼包', 'icon_chips1', '6999', '4042500', '0', 'gundemcasino.chips12', '1', '0', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('104', '16', '16', '100000', '100000', '礼包', 'icon_chips1', '9999', '6600000', '0', 'gundemcasino.chips13', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('105', '16', '17', '100000', '100000', '礼包', 'icon_chips1', '19999', '19800000', '0', 'gundemcasino.chips14', '1', '0', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('106', '16', '31', '100000', '100000', '转盘价格', 'icon_chips1', '199', '1', '0', 'gundemcasino.chips15', '1', '0', '3', '6', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('107', '16', '32', '100000', '100000', '翻倍转盘', 'icon_chips1', '999', '1', '0', 'gundemcasino.chips16', '1', '0', '3', '7', '0', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('108', '16', '33', '100000', '100000', '铜券', 'icon_copperTicken', '100', '1', '0', 'gundemcasino.chips17', '1', '0', '20007', '8', '10', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('109', '16', '34', '100000', '100000', '银券', 'icon_silverTicken', '200', '1', '0', 'gundemcasino.chips18', '1', '0', '20008', '8', '20', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('110', '16', '35', '100000', '100000', '金券', 'icon_goldTicken', '300', '1', '0', 'gundemcasino.chips19', '1', '0', '20009', '8', '30', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('111', '16', '36', '100000', '100000', '五张铜券', 'icon_copperTicken5', '400', '5', '0', 'gundemcasino.chips20', '1', '0', '20007', '8', '40', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('112', '16', '37', '100000', '100000', '一打铜券', 'icon_copperTicken10', '500', '10', '0', 'gundemcasino.chips21', '1', '0', '20007', '8', '50', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('113', '16', '38', '100000', '100000', '一箱铜券', 'icon_copperTicken50', '600', '50', '0', 'gundemcasino.chips22', '1', '0', '20007', '8', '60', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('114', '16', '39', '100000', '100000', '五张银券', 'icon_silverTicken5', '700', '5', '0', 'gundemcasino.chips23', '1', '0', '20008', '8', '70', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('115', '16', '40', '100000', '100000', '一打银券', 'icon_silverTicken10', '800', '10', '0', 'gundemcasino.chips24', '1', '0', '20008', '8', '80', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('116', '16', '41', '100000', '100000', '一箱银券', 'icon_silverTicken50', '900', '50', '0', 'gundemcasino.chips25', '1', '0', '20008', '8', '90', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('117', '16', '42', '100000', '100000', '五张金券', 'icon_goldTicken5', '1000', '5', '0', 'gundemcasino.chips26', '1', '0', '20009', '8', '100', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('118', '16', '43', '100000', '100000', '一打金券', 'icon_goldTicken10', '1100', '10', '0', 'gundemcasino.chips27', '1', '0', '20009', '8', '110', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('119', '16', '44', '100000', '100000', '一箱金券', 'icon_goldTicken50', '1200', '50', '0', 'gundemcasino.chips28', '1', '0', '20009', '8', '120', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('120', '16', '45', '100000', '100000', '周卡', 'item_acepass_7d', '2999', '1', '0', 'gundemcasino.chips29', '1', '0', '20001', '2', '200', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('121', '16', '46', '100000', '100000', '月卡', 'item_aceelitepass_30d', '9999', '1', '0', 'gundemcasino.chips30', '1', '0', '20000', '3', '300', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('122', '16', '47', '100000', '100000', '双倍经验卡', 'icon_experience1', '299', '1', '0', 'gundemcasino_experience1', '1', '0', '20022', '9', '30', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('123', '16', '48', '100000', '100000', '金库0', 'icon_chips1', '199', '1', '0', 'gundemcasino_treasury0', '1', '0', '1', '10', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('124', '16', '49', '100000', '100000', '金库1', 'icon_chips1', '399', '1', '0', 'gundemcasino_treasury1', '1', '0', '1', '10', '40', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('125', '16', '50', '100000', '100000', '金库2', 'icon_chips1', '599', '1', '0', 'gundemcasino_treasury2', '1', '0', '1', '10', '60', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('126', '16', '51', '100000', '100000', '金库3', 'icon_chips1', '1199', '1', '0', 'gundemcasino_treasury3', '1', '0', '1', '10', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('127', '16', '52', '100000', '100000', '金库4', 'icon_chips1', '2999', '1', '0', 'gundemcasino_treasury4', '1', '0', '1', '10', '300', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('128', '16', '53', '100000', '100000', '金库5', 'icon_chips1', '3999', '1', '0', 'gundemcasino_treasury5', '1', '0', '1', '10', '400', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('129', '16', '54', '100000', '100000', '周礼包V0、V1', 'icon_chips1', '999', '3000000', '0', 'gundemcasino_weeklypack1', '1', '0', '1', '1', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('130', '16', '55', '100000', '100000', '周礼包V2及以上', 'icon_chips1', '1499', '4500000', '0', 'gundemcasino_weeklypack2', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('131', '16', '56', '100000', '100000', '月礼包V0、V1', 'icon_chips1', '1499', '7500000', '0', 'gundemcasino_monthlypack1', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('132', '16', '57', '100000', '100000', '月礼包V2及以上', 'icon_chips1', '1999', '10000000', '0', 'gundemcasino_monthlypack2', '1', '0', '1', '1', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('133', '16', '58', '100000', '100000', '新手礼包', 'icon_newpack', '499', '660000', '0', 'goddesscasino_newpack', '1', '0', '3', '11', '5000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('134', '16', '59', '100000', '100000', '俱乐部礼包', 'icon_clubpack', '599', '1', '0', 'goddesscasino_clubpack', '1', '0', '60000', '9', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('135', '16', '60', '100000', '100000', '俱乐部改名卡', 'icon_clubname', '499', '1', '0', 'goddesscasino_clubname', '1', '0', '20027', '1', '50', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('136', '17', '1', '100000', '100000', '筹码', 'icon_chips1', '199', '200000', '0', 'goddesscasino.gems.1', '1', '0', '3', '1', '20', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('137', '17', '2', '100000', '100000', '筹码', 'icon_chips2', '499', '600000', '0', 'goddesscasino.gems.2', '1', '0', '3', '1', '50', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('138', '17', '3', '100000', '100000', '筹码', 'icon_chips3', '999', '1500000', '0', 'goddesscasino.gems.3', '1', '0', '3', '1', '100', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('139', '17', '4', '100000', '100000', '筹码', 'icon_chips4', '1999', '3500000', '0', 'goddesscasino.gems.4', '1', '2', '3', '1', '200', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('140', '17', '5', '100000', '100000', '筹码', 'icon_chips5', '4999', '10000000', '0', 'goddesscasino.gems.5', '1', '1', '3', '1', '500', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('142', '17', '10', '100055', '100056', '改名卡', 'icon_changeName', '99', '1', '0', 'goddesscasino_chips7', '1', '0', '20006', '5', '2', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('143', '17', '11', '100000', '100000', '商店礼包', 'icon_chips1', '199', '230000', '0', 'goddesscasino_chips10', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('144', '17', '12', '100000', '100000', '礼包', 'icon_chips1', '199', '220000', '0', 'goddesscasino_chips1', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('145', '17', '13', '100000', '100000', '礼包', 'icon_chips1', '499', '660000', '0', 'goddesscasino_chips2', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('146', '17', '14', '100000', '100000', '礼包', 'icon_chips1', '999', '1650000', '0', 'goddesscasino_chips3', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('147', '17', '15', '100000', '100000', '礼包', 'icon_chips1', '1999', '3850000', '0', 'goddesscasino_chips4', '1', '0', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('148', '17', '16', '100000', '100000', '礼包', 'icon_chips1', '4999', '11000000', '0', 'goddesscasino_chips5', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('149', '17', '17', '100000', '100000', '礼包', 'icon_chips1', '9999', '33000000', '0', 'goddesscasino_chips6', '1', '0', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('150', '17', '31', '100000', '100000', '转盘价格', 'icon_chips1', '199', '1', '0', 'goddesscasino_chips15', '1', '0', '3', '6', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('151', '17', '32', '100000', '100000', '翻倍转盘', 'icon_chips1', '999', '1', '0', 'goddesscasino_chips16', '1', '0', '3', '7', '0', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('152', '17', '33', '100000', '100000', '铜券', 'icon_copperTicken', '99', '1', '0', 'goddesscasino_chips17', '1', '0', '20007', '8', '10', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('153', '17', '34', '100000', '100000', '银券', 'icon_silverTicken', '199', '1', '0', 'goddesscasino_chips18', '1', '0', '20008', '8', '20', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('154', '17', '35', '100000', '100000', '金券', 'icon_goldTicken', '499', '1', '0', 'goddesscasino_chips19', '1', '0', '20009', '8', '30', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('155', '17', '36', '100000', '100000', '五张铜券', 'icon_copperTicken5', '499', '5', '0', 'goddesscasino_chips20', '1', '0', '20007', '8', '40', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('156', '17', '37', '100000', '100000', '一打铜券', 'icon_copperTicken10', '999', '10', '0', 'goddesscasino_chips21', '1', '0', '20007', '8', '50', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('157', '17', '38', '100000', '100000', '一箱铜券', 'icon_copperTicken50', '1999', '20', '0', 'goddesscasino_chips22', '1', '0', '20007', '8', '60', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('158', '17', '39', '100000', '100000', '五张银券', 'icon_silverTicken5', '999', '5', '0', 'goddesscasino_chips23', '1', '0', '20008', '8', '70', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('159', '17', '40', '100000', '100000', '一打银券', 'icon_silverTicken10', '1999', '10', '0', 'goddesscasino_chips24', '1', '0', '20008', '8', '80', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('160', '17', '41', '100000', '100000', '一箱银券', 'icon_silverTicken50', '3999', '20', '0', 'goddesscasino_chips25', '1', '0', '20008', '8', '90', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('161', '17', '42', '100000', '100000', '五张金券', 'icon_goldTicken5', '2499', '5', '0', 'goddesscasino_chips26', '1', '0', '20009', '8', '100', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('162', '17', '43', '100000', '100000', '一打金券', 'icon_goldTicken10', '4999', '10', '0', 'goddesscasino_chips27', '1', '0', '20009', '8', '110', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('163', '17', '44', '100000', '100000', '一箱金券', 'icon_goldTicken50', '9999', '20', '0', 'goddesscasino_chips28', '1', '0', '20009', '8', '120', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('164', '17', '45', '100000', '100000', '周卡', 'item_acepass_7d', '2999', '1', '0', 'goddesscasino_chips29', '1', '0', '20001', '2', '200', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('165', '17', '46', '100000', '100000', '月卡', 'item_aceelitepass_30d', '9999', '1', '0', 'goddesscasino_chips30', '1', '0', '20000', '3', '300', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('166', '17', '47', '100000', '100000', '双倍经验卡', 'icon_experience1', '299', '1', '0', 'goddesscasino_experience1', '1', '0', '20022', '9', '30', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('167', '17', '48', '100000', '100000', '金库0', 'icon_chips1', '399', '1', '0', 'goddesscasino_treasury0', '1', '0', '1', '10', '40', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('168', '17', '49', '100000', '100000', '金库1', 'icon_chips1', '499', '1', '0', 'goddesscasino_treasury1', '1', '0', '1', '10', '50', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('169', '17', '50', '100000', '100000', '金库2', 'icon_chips1', '999', '1', '0', 'goddesscasino_treasury2', '1', '0', '1', '10', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('170', '17', '51', '100000', '100000', '金库3', 'icon_chips1', '1999', '1', '0', 'goddesscasino_treasury3', '1', '0', '1', '10', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('171', '17', '52', '100000', '100000', '金库4', 'icon_chips1', '4999', '1', '0', 'goddesscasino_treasury4', '1', '0', '1', '10', '500', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('172', '17', '53', '100000', '100000', '金库5', 'icon_chips1', '9999', '1', '0', 'goddesscasino_treasury5', '1', '0', '1', '10', '1000', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('173', '17', '54', '100000', '100000', '周礼包V0、V1', 'icon_chips1', '999', '3000000', '0', 'goddesscasino_weeklypack1', '1', '0', '1', '1', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('174', '17', '55', '100000', '100000', '周礼包V2及以上', 'icon_chips1', '1499', '4500000', '0', 'goddesscasino_weeklypack2', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('175', '17', '56', '100000', '100000', '月礼包V0、V1', 'icon_chips1', '1499', '7500000', '0', 'goddesscasino_monthlypack1', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('176', '17', '57', '100000', '100000', '月礼包V2及以上', 'icon_chips1', '1999', '10000000', '0', 'goddesscasino_monthlypack2', '1', '0', '1', '1', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('177', '17', '58', '100000', '100000', '新手礼包', 'icon_newpack', '499', '660000', '0', 'goddesscasino_newpack', '1', '0', '3', '11', '5000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('178', '17', '59', '100000', '100000', '俱乐部礼包', 'icon_clubpack', '599', '1', '0', 'goddesscasino_clubpack', '1', '0', '60000', '9', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('179', '17', '60', '100000', '100000', '俱乐部改名卡', 'icon_clubname', '499', '1', '0', 'goddesscasino_clubname', '1', '0', '20027', '1', '50', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('180', '18', '1', '100000', '100000', '筹码', 'Handful of Gems', '199', '200000', '0', 'casinolegends.gems.1', '1', '0', '3', '1', '20', '1', '0', '0');
INSERT INTO `t_recharge` VALUES ('181', '18', '2', '100000', '100000', '筹码', 'Pile of Chip', '499', '600000', '0', 'casinolegends.gems.2', '1', '0', '3', '1', '50', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('182', '18', '3', '100000', '100000', '筹码', 'Bag of Chips', '999', '1500000', '0', 'casinolegends.gems.3', '1', '0', '3', '1', '100', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('183', '18', '4', '100000', '100000', '筹码', 'Sack of Chips', '1999', '3500000', '0', 'casinolegends.gems.4', '1', '2', '3', '1', '200', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('184', '18', '5', '100000', '100000', '筹码', 'Box of Chips', '4999', '10000000', '0', 'casinolegends.gems.5', '1', '1', '3', '1', '500', '1', '0', '1');
INSERT INTO `t_recharge` VALUES ('186', '18', '10', '100055', '100056', '改名卡', 'ChangeName', '99', '1', '0', 'casinolegends_chips7', '1', '0', '20006', '5', '2', '2', '0', '1');
INSERT INTO `t_recharge` VALUES ('187', '18', '11', '100000', '100000', '商店礼包', 'Value Pack', '199', '230000', '0', 'casinolegends_chips10', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('188', '18', '12', '100000', '100000', '礼包', 'Snack Chips', '199', '220000', '0', 'casinolegends_chips1', '1', '0', '3', '1', '20', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('189', '18', '13', '100000', '100000', '礼包', 'Ante UP Pack', '499', '660000', '0', 'casinolegends_chips2', '1', '0', '3', '1', '50', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('190', '18', '14', '100000', '100000', '礼包', 'Popular Pack', '999', '1650000', '0', 'casinolegends_chips3', '1', '0', '3', '1', '100', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('191', '18', '15', '100000', '100000', '礼包', 'Real Pack', '1999', '3850000', '0', 'casinolegends_chips4', '1', '0', '3', '1', '200', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('192', '18', '16', '100000', '100000', '礼包', 'High Pack', '4999', '11000000', '0', 'casinolegends_chips5', '1', '0', '3', '1', '500', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('193', '18', '17', '100000', '100000', '礼包', 'Super Pack', '9999', '33000000', '0', 'casinolegends_chips6', '1', '0', '3', '1', '1000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('194', '18', '31', '100000', '100000', '转盘价格', 'Recharge Wheel', '199', '1', '0', 'casinolegends_chips15', '1', '0', '3', '6', '20', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('195', '18', '32', '100000', '100000', '翻倍转盘', 'Fortune Wheel', '999', '1', '0', 'casinolegends_chips16', '1', '0', '3', '7', '0', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('196', '18', '33', '100000', '100000', '铜券', 'Bronze Ticket', '100', '1', '0', 'casinolegends_chips17', '1', '0', '20007', '8', '10', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('197', '18', '34', '100000', '100000', '银券', 'Silver Ticket', '200', '1', '0', 'casinolegends_chips18', '1', '0', '20008', '8', '20', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('198', '18', '35', '100000', '100000', '金券', 'Gold Ticket', '300', '1', '0', 'casinolegends_chips19', '1', '0', '20009', '8', '30', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('199', '18', '36', '100000', '100000', '五张铜券', 'Bronze Ticket*5', '400', '5', '0', 'casinolegends_chips20', '1', '0', '20007', '8', '40', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('200', '18', '37', '100000', '100000', '一打铜券', 'Bronze Ticket*10', '500', '10', '0', 'casinolegends_chips21', '1', '0', '20007', '8', '50', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('201', '18', '38', '100000', '100000', '一箱铜券', 'A box of Bronze Tickets', '600', '50', '0', 'casinolegends_chips22', '1', '0', '20007', '8', '60', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('202', '18', '39', '100000', '100000', '五张银券', 'Silver Ticket*5', '700', '5', '0', 'casinolegends_chips23', '1', '0', '20008', '8', '70', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('203', '18', '40', '100000', '100000', '一打银券', 'Silver Ticket*10', '800', '10', '0', 'casinolegends_chips24', '1', '0', '20008', '8', '80', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('204', '18', '41', '100000', '100000', '一箱银券', 'A box of Silver Tickets', '900', '50', '0', 'casinolegends_chips25', '1', '0', '20008', '8', '90', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('205', '18', '42', '100000', '100000', '五张金券', 'Gold Ticket*5', '1000', '5', '0', 'casinolegends_chips26', '1', '0', '20009', '8', '100', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('206', '18', '43', '100000', '100000', '一打金券', 'Gold Ticket*10', '1100', '10', '0', 'casinolegends_chips27', '1', '0', '20009', '8', '110', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('207', '18', '44', '100000', '100000', '一箱金券', 'A box of Gold Tickets', '1200', '50', '0', 'casinolegends_chips28', '1', '0', '20009', '8', '120', '2', '0', '3');
INSERT INTO `t_recharge` VALUES ('208', '18', '45', '100000', '100000', '周卡', 'Week Card', '2999', '1', '0', 'casinolegends_chips29', '1', '0', '20001', '2', '200', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('209', '18', '46', '100000', '100000', '月卡', 'Month Card', '9999', '1', '0', 'casinolegends_chips30', '1', '0', '20000', '3', '300', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('210', '18', '47', '100000', '100000', '双倍经验卡', '200% EXP Booster', '299', '1', '0', 'casinolegends_experience1', '1', '0', '20022', '9', '30', '2', '0', '2');
INSERT INTO `t_recharge` VALUES ('211', '18', '48', '100000', '100000', '金库0', 'Mini Storage', '399', '1', '0', 'casinolegends_treasury0', '1', '0', '1', '10', '40', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('212', '18', '49', '100000', '100000', '金库1', 'Small Storage', '499', '1', '0', 'casinolegends_treasury1', '1', '0', '1', '10', '50', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('213', '18', '50', '100000', '100000', '金库2', 'Middle Storage', '999', '1', '0', 'casinolegends_treasury2', '1', '0', '1', '10', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('214', '18', '51', '100000', '100000', '金库3', 'Big Storage', '1999', '1', '0', 'casinolegends_treasury3', '1', '0', '1', '10', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('215', '18', '52', '100000', '100000', '金库4', 'Large Storage', '4999', '1', '0', 'casinolegends_treasury4', '1', '0', '1', '10', '500', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('216', '18', '53', '100000', '100000', '金库5', 'Giant Storage', '9999', '1', '0', 'casinolegends_treasury5', '1', '0', '1', '10', '1000', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('217', '18', '54', '100000', '100000', '周礼包V0、V1', 'Small Week Pack', '999', '3000000', '0', 'casinolegends_weeklypack1', '1', '0', '1', '1', '100', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('218', '18', '55', '100000', '100000', '周礼包V2及以上', 'Large Week Pack', '1499', '4500000', '0', 'casinolegends_weeklypack2', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('219', '18', '56', '100000', '100000', '月礼包V0、V1', 'Small Month Pack', '1499', '7500000', '0', 'casinolegends_monthlypack1', '1', '0', '1', '1', '150', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('220', '18', '57', '100000', '100000', '月礼包V2及以上', 'Large Month Pack', '1999', '10000000', '0', 'casinolegends_monthlypack2', '1', '0', '1', '1', '200', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('221', '18', '58', '100000', '100000', '新手礼包', 'Newbie Pack', '499', '660000', '0', 'goddesscasino_newpack', '1', '0', '3', '11', '5000', '3', '0', '0');
INSERT INTO `t_recharge` VALUES ('222', '18', '59', '100000', '100000', '俱乐部礼包', 'Club Pack', '599', '1', '0', 'casinolegends_clubpack', '1', '0', '60000', '9', '120', '4', '0', '0');
INSERT INTO `t_recharge` VALUES ('223', '18', '60', '100000', '100000', '俱乐部改名卡', 'Club ChangeName', '499', '1', '0', 'casinolegends_clubname', '1', '0', '20027', '1', '50', '2', '0', '2');

-- ----------------------------
-- Table structure for `t_robot_statis_data_useless`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_statis_data_useless`;
CREATE TABLE `t_robot_statis_data_useless` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slotId` bigint(20) DEFAULT NULL,
  `chartId` bigint(20) DEFAULT NULL,
  `rewardCount` bigint(20) DEFAULT NULL COMMENT '赢取次数：在转动中赢得筹码的次数',
  `rewardUsed` bigint(20) DEFAULT NULL COMMENT '消耗筹码数：所有转动结束后所消耗的筹码',
  `payCount` bigint(20) DEFAULT NULL COMMENT '支付线筹码数：支付线中奖获得的筹码数量',
  `scatterNum` bigint(20) DEFAULT NULL COMMENT 'Scatter筹码数：中scatter游戏获得的筹码数量；',
  `bonusNum` bigint(20) DEFAULT NULL COMMENT 'Bonus筹码数：中bonus游戏获得的筹码数量；',
  `scatterTriggerCount` bigint(20) DEFAULT NULL COMMENT 'scatter的次数：scatter游戏触发的次数；',
  `bonusTriggerCount` bigint(20) DEFAULT NULL COMMENT 'bonus的次数：bonus游戏触发的次数',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_statis_data_useless
-- ----------------------------

-- ----------------------------
-- Table structure for `t_slot_icon`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot_icon`;
CREATE TABLE `t_slot_icon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_id` int(11) DEFAULT NULL,
  `lang_desc` varchar(64) DEFAULT NULL COMMENT '图标中文',
  `icon` varchar(64) DEFAULT NULL COMMENT '图标英文',
  `slots_num` int(11) DEFAULT NULL COMMENT '老虎机类型（哪个老虎机）',
  `turn` int(11) DEFAULT NULL COMMENT '元素编号',
  `type` int(11) DEFAULT NULL COMMENT '0：普通、1：万能符，2、scatter，3、wild1:放大1倍4、wild2放大2倍，5、wild3，6、wild47、jackpot；8、BONUS GAME;9、大转盘游戏；10、大号wild；11、bonus13，12、神秘符号（可以随机出其他符号）13、bonus14；14、wild（随机倍数）；15、bouns15,16、拼图碎片功能17、bouns16',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot_icon
-- ----------------------------
INSERT INTO `t_slot_icon` VALUES ('1', '100000', 'wild', 'icon_universal', '1', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('2', '100000', 'scatter', 'icon_scatter1', '1', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('3', '100000', '777图标', 'icon_777', '1', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('4', '100000', '7图标', 'icon_7', '1', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('5', '100000', '3bar', 'icon_3bar', '1', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('6', '100000', '2bar', 'icon_2bar', '1', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('7', '100000', 'bar', 'icon_bar', '1', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('8', '100000', '黑桃', 'icon_spade1', '1', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('9', '100000', '红桃', 'icon_heart1', '1', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('10', '100000', '梅花', 'icon_plum1', '1', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('11', '100000', '方块', 'icon_block', '1', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('12', '100000', 'wild扇子', 'icon_wildFb', '2', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('13', '100000', 'scatter扇子', 'icon_scatterFb', '2', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('14', '100000', '西施', 'icon_xishi', '2', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('15', '100000', '王昭君', 'icon_zhaojun', '2', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('16', '100000', '貂蝉', 'icon_diaochan', '2', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('17', '100000', '杨玉环', 'icon_yuhuan', '2', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('18', '100000', '琵琶', 'icon_pipa', '2', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('19', '100000', '绿玉佩', 'icon_greenJade', '2', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('20', '100000', '红玉佩', 'icon_redJade', '2', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('21', '100000', '花朵', 'icon_flower', '2', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('22', '100000', '字母A', 'icon_letterA', '2', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('23', '100000', 'wild', 'icon_wild3', '3', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('24', '100000', 'scatter', 'icon_scatter3', '3', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('25', '100000', '西瓜', 'icon_watermelon', '3', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('26', '100000', '橘子', 'icon_orange', '3', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('27', '100000', '葡萄', 'icon_grape', '3', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('28', '100000', '樱桃', 'icon_cherry', '3', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('29', '100000', 'F', 'icon_F', '3', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('30', '100000', 'R', 'icon_R', '3', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('31', '100000', 'U', 'icon_U', '3', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('32', '100000', 'I', 'icon_I', '3', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('33', '100000', 'T', 'icon_T', '3', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('34', '100000', '沙滩wild', 'icon_wild4', '4', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('35', '100000', '沙滩scatter', 'icon_scatter4', '4', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('36', '100000', '美女1', 'icon_beauty1', '4', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('37', '100000', '美女2', 'icon_beauty2', '4', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('38', '100000', '轮船', 'icon_beauty3', '4', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('39', '100000', '饮料', 'icon_drinks', '4', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('40', '100000', '漂流瓶', 'icon_bottle', '4', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('41', '100000', '椰果', 'icon_coconut', '4', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('42', '100000', '海星', 'icon_starfish', '4', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('43', '100000', '排球', 'icon_volleyball', '4', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('44', '100000', '眼镜', 'icon_glasses', '4', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('45', '100000', '吸血鬼wild', 'icon_wild5', '5', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('46', '100000', 'scatter', 'icon_scatter5', '5', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('47', '100000', '蝙蝠', 'icon_bat', '5', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('48', '100000', '棺材', 'icon_coffin', '5', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('49', '100000', '骷髅', 'icon_skull', '5', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('50', '100000', '血瓶', 'icon_bloodbottle', '5', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('51', '100000', '匕首', 'icon_dagger', '5', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('52', '100000', '圣经', 'icon_bible', '5', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('53', '100000', '手枪', 'icon_gun', '5', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('54', '100000', '蜡烛', 'icon_candle', '5', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('55', '100000', '帽子', 'icon_hat', '5', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('56', '100000', '艳后wild', 'icon_wild6', '6', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('57', '100000', '金字塔scatter', 'icon_scatter6', '6', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('58', '100000', '法老', 'icon_pharaoh', '6', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('59', '100000', '狗头人', 'icon_kobold', '6', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('60', '100000', '黑狗', 'icon_blackdog', '6', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('61', '100000', '蛇', 'icon_snake', '6', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('62', '100000', '鹰', 'icon_eagle', '6', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('63', '100000', '戒指', 'icon_ring', '6', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('64', '100000', '十字架', 'icon_cross', '6', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('65', '100000', '蝎子', 'icon_scorpion', '6', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('66', '100000', '甲壳虫', 'icon_beatles', '6', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('67', '100000', '美人鱼wild', 'icon_wild7', '7', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('68', '100000', '王子scatter', 'icon_scatter7', '7', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('69', '100000', '鲨鱼', 'icon_shark', '7', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('70', '100000', '海豚', 'icon_dolphin', '7', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('71', '100000', '海马', 'icon_hippocampus', '7', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('72', '100000', '三叉戟', 'icon_trident', '7', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('73', '100000', '珍珠', 'icon_pearl', '7', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('74', '100000', '小丑鱼', 'icon_fish', '7', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('75', '100000', '项链', 'icon_necklace', '7', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('76', '100000', '珊瑚', 'icon_coral', '7', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('77', '100000', '海螺', 'icon_conch', '7', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('78', '100000', '澳门scatter8', 'icon_scatter8', '8', '1', '9');
INSERT INTO `t_slot_icon` VALUES ('79', '100000', '澳门BONUS', 'icon_bonus8', '8', '2', '8');
INSERT INTO `t_slot_icon` VALUES ('80', '100000', '澳门WILD', 'icon_wild8', '8', '3', '1');
INSERT INTO `t_slot_icon` VALUES ('81', '100000', '澳门JACKPOT', 'icon_jackpot8', '8', '4', '7');
INSERT INTO `t_slot_icon` VALUES ('82', '100000', '女神1', 'icon_goddess1', '8', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('83', '100000', '女神2', 'icon_goddess2', '8', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('84', '100000', '女神3', 'icon_goddess3', '8', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('85', '100000', '高跟鞋', 'icon_shoe', '8', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('86', '100000', '字母A', 'icon_8A', '8', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('87', '100000', '字母B', 'icon_8K', '8', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('88', '100000', '字母Q', 'icon_8Q', '8', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('89', '100000', '字母J', 'icon_8J', '8', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('90', '100000', '数字10', 'icon_10', '8', '13', '0');
INSERT INTO `t_slot_icon` VALUES ('91', '100000', '白娘子wild', 'icon_baishewild', '9', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('92', '100000', 'wild1倍', 'icon_baishewild1', '9', '2', '3');
INSERT INTO `t_slot_icon` VALUES ('93', '100000', 'wild2倍', 'icon_baishewild2', '9', '3', '4');
INSERT INTO `t_slot_icon` VALUES ('94', '100000', 'wild3倍', 'icon_baishewild3', '9', '4', '5');
INSERT INTO `t_slot_icon` VALUES ('95', '100000', 'wild4倍', 'icon_baishewild4', '9', '5', '6');
INSERT INTO `t_slot_icon` VALUES ('96', '100000', '酒罐scatter', 'icon_scatterbaishe', '9', '6', '2');
INSERT INTO `t_slot_icon` VALUES ('97', '100000', 'jackpot', 'icon_baishejackpot', '9', '7', '7');
INSERT INTO `t_slot_icon` VALUES ('98', '100000', '许仙', 'icon_xuxian', '9', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('99', '100000', '小青', 'icon_xiaoqing', '9', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('100', '100000', '雷峰塔', 'icon_leifengta', '9', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('101', '100000', '断桥', 'icon_bridge', '9', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('102', '100000', '湖心亭', 'icon_pavilion', '9', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('103', '100000', '伞', 'icon_umbrella', '9', '13', '0');
INSERT INTO `t_slot_icon` VALUES ('104', '100000', '乌篷船', 'icon_ship', '9', '14', '0');
INSERT INTO `t_slot_icon` VALUES ('105', '100000', '锦鲤', 'icon_koi', '9', '15', '0');
INSERT INTO `t_slot_icon` VALUES ('106', '100000', '荷花', 'icon_lotus', '9', '16', '0');
INSERT INTO `t_slot_icon` VALUES ('107', '100000', 'scatter10', 'icon_scatter10', '10', '1', '2');
INSERT INTO `t_slot_icon` VALUES ('108', '100000', 'jackpot10', 'icon_jackpot10', '10', '2', '7');
INSERT INTO `t_slot_icon` VALUES ('109', '100000', '黄发网红', 'icon_wanghong1', '10', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('110', '100000', '马尾网红', 'icon_wanghong2', '10', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('111', '100000', '运动网红', 'icon_wanghong3', '10', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('112', '100000', '酒杯', 'icon_wineglass', '10', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('113', '100000', '榴莲', 'icon_durian', '10', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('114', '100000', '杨桃', 'icon_carambola', '10', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('115', '100000', '火龙果', 'icon_pitaya', '10', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('116', '100000', '红毛丹', 'icon_hongmaodan', '10', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('117', '100000', '山竹', 'icon_mangosteen', '10', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('118', '100000', 'scatter', 'icon_scatter11', '11', '1', '2');
INSERT INTO `t_slot_icon` VALUES ('119', '100000', 'jackpot', 'icon_jackpot11', '11', '2', '7');
INSERT INTO `t_slot_icon` VALUES ('120', '100000', '红领美女', 'icon_hongling11', '11', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('121', '100000', '绿领美女', 'icon_lvling11', '11', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('122', '100000', '马尾美女', 'icon_mawei11', '11', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('123', '100000', '富士山', 'icon_fushishan', '11', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('124', '100000', '招财猫', 'icon_zhaocaimao', '11', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('125', '100000', '寿司', 'icon_shousi', '11', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('126', '100000', '扇子', 'icon_heshan', '11', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('127', '100000', '鲤鱼旗', 'icon_liyuqi', '11', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('128', '100000', '木屐', 'icon_muji', '11', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('129', '100000', 'wild12', 'icon_wild12', '12', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('130', '100000', 'scatter12', 'icon_scatter12', '12', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('131', '100000', '金发模特', 'icon_goldmodel12', '12', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('132', '100000', '黄发模特', 'icon_yellomodel12', '12', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('133', '100000', '皇冠', 'icon_f12', '12', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('134', '100000', '钻石', 'icon_a12', '12', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('135', '100000', '红心', 'icon_s12', '12', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('136', '100000', '嘴唇', 'icon_h12', '12', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('137', '100000', '高跟鞋', 'icon_i12', '12', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('138', '100000', '香水', 'icon_o12', '12', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('139', '100000', '口红', 'icon_n12', '12', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('140', '100000', 'wild13', 'icon_wild13', '13', '1', '10');
INSERT INTO `t_slot_icon` VALUES ('141', '100000', 'scatter13', 'icon_scatter13', '13', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('142', '100000', 'bonus13', 'icon_bonus13', '13', '3', '11');
INSERT INTO `t_slot_icon` VALUES ('143', '100000', '赫拉', 'icon_hl', '13', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('144', '100000', '海神波塞冬', 'icon_bsd', '13', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('145', '100000', '雅典娜', 'icon_ydn', '13', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('146', '100000', '阿波罗', 'icon_abl', '13', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('147', '100000', '头盔', 'icon_rm', '13', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('148', '100000', '神戒', 'icon_jiezhi', '13', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('149', '100000', '神瓶', 'icon_shengbei', '13', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('150', '100000', '盾牌', 'icon_dun', '13', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('151', '100000', '弓箭', 'icon_gongjian', '13', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('152', '100000', 'wild14', 'icon_wild14', '14', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('153', '100000', 'scatter14', 'icon_scatter14', '14', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('154', '100000', 'bonus14', 'icon_bonus14', '14', '3', '13');
INSERT INTO `t_slot_icon` VALUES ('155', '100000', '神秘符号', 'icon_magicSymbol', '14', '4', '12');
INSERT INTO `t_slot_icon` VALUES ('156', '100000', '恐龙', 'icon_long', '14', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('157', '100000', '器皿', 'icon_bottle', '14', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('158', '100000', '火把', 'icon_huoba', '14', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('159', '100000', '锤子', 'icon_chuizi', '14', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('160', '100000', '字母s', 'icon_s14', '14', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('161', '100000', '字母t', 'icon_t14', '14', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('162', '100000', '字母o', 'icon_o14', '14', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('163', '100000', '字母n', 'icon_n14', '14', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('164', '100000', '字母e', 'icon_e14', '14', '13', '0');
INSERT INTO `t_slot_icon` VALUES ('165', '100000', 'wild15', 'icon_wild15', '15', '1', '14');
INSERT INTO `t_slot_icon` VALUES ('166', '100000', 'scatter15', 'icon_scatter15', '15', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('167', '100000', 'bouns15', 'icon_bouns15', '15', '3', '15');
INSERT INTO `t_slot_icon` VALUES ('168', '100000', '金字塔', 'icon_eye', '15', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('169', '100000', '木乃伊', 'icon_mummy', '15', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('170', '100000', '宝箱', 'icon_box15', '15', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('171', '100000', '虫子', 'icon_stone15', '15', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('172', '100000', '发卡', 'icon_bottle15', '15', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('173', '100000', '豹子', 'icon_round15', '15', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('174', '100000', '狗', 'icon_sriangle15', '15', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('175', '100000', '法眼', 'icon_square15', '15', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('176', '100000', '罐子', 'icon_rhombus15', '15', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('177', '100000', 'wild16', 'icon_wild16', '16', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('178', '100000', 'scatter16', 'icon_scatter16', '16', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('179', '100000', '拼图碎片', 'icon_puzzle', '16', '3', '16');
INSERT INTO `t_slot_icon` VALUES ('180', '100000', '阿兹特克战士', 'icon_aztecSoldier', '16', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('181', '100000', '阿兹特克图腾', 'icon_aztecTotem', '16', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('182', '100000', '匕首', 'icon_aztecDagger', '16', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('183', '100000', '字母A', 'icon_a16', '16', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('184', '100000', '字母z', 'icon_z16', '16', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('185', '100000', '字母t', 'icon_t16', '16', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('186', '100000', '字母e', 'icon_e16', '16', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('187', '100000', '字母c', 'icon_c16', '16', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('188', '100000', '夜月', 'icon_wild17', '17', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('189', '100000', '狼牙', 'icon_scatter17', '17', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('190', '100000', '狼头', 'icon_bouns17', '17', '3', '17');
INSERT INTO `t_slot_icon` VALUES ('191', '100000', '黑狼', 'icon_black17', '17', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('192', '100000', '白狼', 'icon_white17', '17', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('193', '100000', '狼爪', 'icon_claw17', '17', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('194', '100000', '狼套', 'icon_cover17', '17', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('195', '100000', '狼仔', 'icon_wolfing17', '17', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('196', '100000', '字母W', 'icon_W17', '17', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('197', '100000', '字母O', 'icon_O17', '17', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('198', '100000', '字母L', 'icon_L17', '17', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('199', '100000', '字母F', 'icon_F17', '17', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('200', '100000', '波斯猫wild18', 'icon_wild18', '18', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('201', '100000', 'scatter18', 'icon_scatter18', '18', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('202', '100000', 'jackpot18', 'icon_jackpot18', '18', '3', '7');
INSERT INTO `t_slot_icon` VALUES ('203', '100000', '东方短毛猫', 'icon_dfCat', '18', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('204', '100000', '猫粮', 'icon_catFood', '18', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('205', '100000', '符号777', 'icon_fuhao777', '18', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('206', '100000', '符号7', 'icon_fuhao7', '18', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('207', '100000', '符号3bar', 'icon_fuhao3bar', '18', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('208', '100000', '符号bar', 'icon_fuhaoBar', '18', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('209', '100000', '水晶球wild19', 'icon_wild19', '19', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('210', '100000', '转盘scatter19', 'icon_scatter19', '19', '2', '18');
INSERT INTO `t_slot_icon` VALUES ('211', '100000', '蝴蝶紫水晶', 'icon_amethyst', '19', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('212', '100000', '蝴蝶黄水晶', 'icon_topaz', '19', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('213', '100000', '魔法水晶盾', 'icon_shield', '19', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('214', '100000', '蓝宝石', 'icon_sapphire', '19', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('215', '100000', '红宝石', 'icon_ruby', '19', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('216', '100000', '字母A19', 'icon_A19', '19', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('217', '100000', '字母K19', 'icon_K19', '19', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('218', '100000', '字母Q19', 'icon_Q19', '19', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('219', '100000', '字母J19', 'icon_J19', '19', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('220', '100000', '绿宝石', 'icon_emerald', '19', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('221', '100000', '泰国象wild', 'icon_wild20', '20', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('222', '100000', '睡莲scatter', 'icon_scatter20', '20', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('223', '100000', '泰国凉亭bonus', 'icon_bonus20', '20', '3', '20');
INSERT INTO `t_slot_icon` VALUES ('224', '100000', '泰国象神大wild', 'icon_elephantWild', '20', '4', '19');
INSERT INTO `t_slot_icon` VALUES ('225', '100000', '火背鹇', 'icon_bird20', '20', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('226', '100000', '泰国佛牌', 'icon_amulets', '20', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('227', '100000', '泰式手镯', 'icon_bracelet20', '20', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('228', '100000', '泰国瓶子', 'icon_bottle20', '20', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('229', '100000', '字母a', 'icon_a20', '20', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('230', '100000', '字母K20', 'icon_k20', '20', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('231', '100000', '字母q', 'icon_q20', '20', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('232', '100000', '字母J', 'icon_j20', '20', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('233', '100000', '金虎wild', 'icon_wild21', '21', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('234', '100000', '银虎scatter', 'icon_scatter21', '21', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('235', '100000', '红棕虎bouns', 'icon_bonus21', '21', '3', '21');
INSERT INTO `t_slot_icon` VALUES ('236', '100000', '猩猩', 'icon_orangutan', '21', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('237', '100000', '豹子', 'icon_leopard', '21', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('238', '100000', '狮子', 'icon_lion', '21', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('239', '100000', '麋鹿', 'icon_elk', '21', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('240', '100000', '梅花', 'icon_plum', '21', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('241', '100000', '黑桃', 'icon_spade21', '21', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('242', '100000', '红心', 'icon_heart21', '21', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('243', '100000', '方块', 'icon_diamond21', '21', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('244', '100000', '虎牙', 'icon_teeth21', '21', '12', '0');
INSERT INTO `t_slot_icon` VALUES ('245', '100000', '金矿车wild', 'icon_wild22', '22', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('246', '100000', '钱袋scatter', 'icon_scatter22', '22', '2', '22');
INSERT INTO `t_slot_icon` VALUES ('247', '100000', '西部牛仔', 'icon_cowboy22', '22', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('248', '100000', '帽子', 'icon_hat22', '22', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('249', '100000', '靴子', 'icon_boots22', '22', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('250', '100000', '左轮手枪', 'icon_revolver22', '22', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('251', '100000', '矿灯', 'icon_light22', '22', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('252', '100000', '炸药', 'icon_bomb22', '22', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('253', '100000', '镐头', 'icon_pick22', '22', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('254', '100000', '铁楸', 'icon_iron22', '22', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('255', '100000', '中国龙', 'icon_jackpot23', '23', '1', '23');
INSERT INTO `t_slot_icon` VALUES ('256', '100000', '石狮子scatter', 'icon_scatter23', '23', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('257', '100000', '鲤鱼跃', 'icon_carp23', '23', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('258', '100000', '灯笼', 'icon_lantern', '23', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('259', '100000', '如意', 'icon_wish23', '23', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('260', '100000', '金钱龟', 'icon_turtle23', '23', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('261', '100000', '字母A', 'icon_A23', '23', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('262', '100000', '字母K', 'icon_K23', '23', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('263', '100000', '字母Q', 'icon_Q23', '23', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('264', '100000', '字母J', 'icon_J23', '23', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('265', '100000', '面具wild', 'icon_wild24', '24', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('266', '100000', '耶稣scatter', 'icon_scatter24', '24', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('267', '100000', '足球bonus', 'icon_bonus24', '24', '3', '11');
INSERT INTO `t_slot_icon` VALUES ('268', '100000', '里约美女', 'icon_riogrile24', '24', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('269', '100000', '巴西鼓', 'icon_drum24', '24', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('270', '100000', '排箫', 'icon_xiao24', '24', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('271', '100000', '巴西鸟', 'icon_trumpet24', '24', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('272', '100000', '字母a', 'icon_a24', '24', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('273', '100000', '字母k', 'icon_k24', '24', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('274', '100000', '字母q', 'icon_q24', '24', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('275', '100000', '字母j', 'icon_j24', '24', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('276', '100000', '忍者wild25', 'icon_wild25', '25', '1', '10');
INSERT INTO `t_slot_icon` VALUES ('277', '100000', '卷轴bouns', 'icon_bouns25', '25', '2', '24');
INSERT INTO `t_slot_icon` VALUES ('278', '100000', '扇子scatter', 'icon_fan25', '25', '3', '2');
INSERT INTO `t_slot_icon` VALUES ('279', '100000', '日本女', 'icon_katana', '25', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('280', '100000', '武士', 'icon_weapon25', '25', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('281', '100000', '手势', 'icon_dart25', '25', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('282', '100000', '武士刀', 'icon_A25', '25', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('283', '100000', '苦无', 'icon_K25', '25', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('284', '100000', '飞镖', 'icon_Q25', '25', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('285', '100000', '钩子', 'icon_J25', '25', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('286', '100000', '女巫wild', 'icon_wild26', '26', '1', '25');
INSERT INTO `t_slot_icon` VALUES ('287', '100000', '魔法棒scatter', 'icon_scatter26', '26', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('288', '100000', '法阵bonus', 'icon_bonus26', '26', '3', '13');
INSERT INTO `t_slot_icon` VALUES ('289', '100000', '法师帽', 'icon_magicCap26', '26', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('290', '100000', '魔法书', 'icon_magicBook26', '26', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('291', '100000', '魔法卷轴', 'icon_magicScroll26', '26', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('292', '100000', '魔瓶', 'icon_magicBottle26', '26', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('293', '100000', '魔法锅', 'icon_blueRune', '26', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('294', '100000', '魔法扫帚', 'icon_greenRune', '26', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('295', '100000', '南瓜头', 'icon_redRune', '26', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('296', '100000', '魔法牌', 'icon_pinkRune', '26', '11', '0');
INSERT INTO `t_slot_icon` VALUES ('297', '100000', '犀牛wild', 'icon_wild27', '27', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('298', '100000', '徽章scatter', 'icon_scatter27', '27', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('299', '100000', '犀牛头bonus', 'icon_bonus27', '27', '3', '26');
INSERT INTO `t_slot_icon` VALUES ('300', '100000', '斑马', 'icon_zebra27', '27', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('301', '100000', '羚羊', 'icon_antelope27', '27', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('302', '100000', '豺狗', 'icon_dhole', '27', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('303', '100000', '字母A', 'icon_A27', '27', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('304', '100000', '字母K', 'icon_K27', '27', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('305', '100000', '字母Q', 'icon_Q27', '27', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('306', '100000', '字母J', 'icon_J27', '27', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('307', '100000', '美人鱼wild28', 'icon_wild28', '28', '1', '28');
INSERT INTO `t_slot_icon` VALUES ('308', '100000', '蚌bonus28', 'icon_bonus28', '28', '2', '27');
INSERT INTO `t_slot_icon` VALUES ('309', '100000', '鲨鱼28', 'icon_shark28', '28', '3', '0');
INSERT INTO `t_slot_icon` VALUES ('310', '100000', '乌龟28', 'icon_tortoise28', '28', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('311', '100000', '龙虾28', 'icon_lobster28', '28', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('312', '100000', '海星28', 'icon_starfish28', '28', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('313', '100000', '字母A', 'icon_A28', '28', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('314', '100000', '字母K', 'icon_K28', '28', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('315', '100000', '字母Q', 'icon_Q28', '28', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('316', '100000', '字母J', 'icon_J28', '28', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('317', '100000', '龙wild29', 'icon_wild29', '29', '1', '28');
INSERT INTO `t_slot_icon` VALUES ('318', '100000', '龙蛋bonus29', 'icon_bonus29', '29', '2', '29');
INSERT INTO `t_slot_icon` VALUES ('319', '100000', '龙眼scatter29', 'icon_longan29', '29', '3', '2');
INSERT INTO `t_slot_icon` VALUES ('320', '100000', '龙崽', 'icon_shield29', '29', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('321', '100000', '龙女', 'icon_knife29', '29', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('322', '100000', '龙血', 'icon_box29', '29', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('323', '100000', '龙爪', 'icon_A29', '29', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('324', '100000', '头盔', 'icon_K29', '29', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('325', '100000', '龙刀', 'icon_Q29', '29', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('326', '100000', '书', 'icon_J29', '29', '10', '0');
INSERT INTO `t_slot_icon` VALUES ('327', '100000', 'wild30', 'icon_wild30', '30', '1', '1');
INSERT INTO `t_slot_icon` VALUES ('328', '100000', 'scatter30', 'icon_scatter30', '30', '2', '2');
INSERT INTO `t_slot_icon` VALUES ('329', '100000', 'bonus30', 'icon_bonus30', '30', '3', '30');
INSERT INTO `t_slot_icon` VALUES ('330', '100000', '帽子', 'icon_cap30', '30', '4', '0');
INSERT INTO `t_slot_icon` VALUES ('331', '100000', '怀表', 'icon_watch30', '30', '5', '0');
INSERT INTO `t_slot_icon` VALUES ('332', '100000', '左轮手枪', 'icon_revolver30', '30', '6', '0');
INSERT INTO `t_slot_icon` VALUES ('333', '100000', '字母A', 'icon_A30', '30', '7', '0');
INSERT INTO `t_slot_icon` VALUES ('334', '100000', '字母K', 'icon_K30', '30', '8', '0');
INSERT INTO `t_slot_icon` VALUES ('335', '100000', '字母Q', 'icon_Q30', '30', '9', '0');
INSERT INTO `t_slot_icon` VALUES ('336', '100000', '字母J', 'icon_J30', '30', '10', '0');

-- ----------------------------
-- Table structure for `t_slot_list_useless`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot_list_useless`;
CREATE TABLE `t_slot_list_useless` (
  `id` bigint(20) NOT NULL,
  `langDesc` varchar(120) DEFAULT NULL COMMENT '老虎机名称',
  `payLinesNum` int(3) DEFAULT NULL,
  `bet1` int(11) DEFAULT NULL,
  `bet2` int(11) DEFAULT NULL,
  `bet3` int(11) DEFAULT NULL,
  `bet4` int(11) DEFAULT NULL,
  `bet5` int(11) DEFAULT NULL,
  `type` int(3) DEFAULT NULL COMMENT '老虎机编号',
  `bet1Lv` int(6) DEFAULT NULL,
  `bet2Lv` int(6) DEFAULT NULL,
  `bet3Lv` int(6) DEFAULT NULL,
  `bet4Lv` int(6) DEFAULT NULL,
  `bet5Lv` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot_list_useless
-- ----------------------------
INSERT INTO `t_slot_list_useless` VALUES ('1', '狮身人面像', '40', '25', '50', '100', '200', '400', '15', '1', '3', '5', '7', '9');
INSERT INTO `t_slot_list_useless` VALUES ('2', '狮身人面像', '40', '125', '250', '500', '1000', '2000', '15', '6', '6', '6', '6', '6');
INSERT INTO `t_slot_list_useless` VALUES ('3', '狮身人面像', '40', '625', '1250', '2500', '5000', '10000', '15', '12', '12', '12', '12', '12');
INSERT INTO `t_slot_list_useless` VALUES ('4', '狮身人面像', '40', '3125', '6250', '12500', '25000', '50000', '15', '18', '18', '18', '18', '18');
INSERT INTO `t_slot_list_useless` VALUES ('5', '福尔摩斯', '25', '40', '80', '160', '320', '640', '30', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list_useless` VALUES ('6', '福尔摩斯', '25', '200', '400', '800', '1600', '3200', '30', '6', '6', '6', '6', '6');
INSERT INTO `t_slot_list_useless` VALUES ('7', '福尔摩斯', '25', '1000', '2000', '4000', '8000', '16000', '30', '12', '12', '12', '12', '12');
INSERT INTO `t_slot_list_useless` VALUES ('8', '福尔摩斯', '25', '5000', '10000', '20000', '40000', '80000', '30', '18', '18', '18', '18', '18');
INSERT INTO `t_slot_list_useless` VALUES ('9', '东方龙', '25', '40', '80', '160', '320', '640', '23', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list_useless` VALUES ('10', '东方龙', '25', '200', '400', '800', '1600', '3200', '23', '6', '6', '6', '6', '6');
INSERT INTO `t_slot_list_useless` VALUES ('11', '东方龙', '25', '1000', '2000', '4000', '8000', '16000', '23', '12', '12', '12', '12', '12');
INSERT INTO `t_slot_list_useless` VALUES ('12', '东方龙', '25', '5000', '10000', '20000', '40000', '80000', '23', '18', '18', '18', '18', '18');
INSERT INTO `t_slot_list_useless` VALUES ('13', '阿兹特克', '30', '40', '80', '160', '320', '640', '16', '5', '5', '5', '5', '5');
INSERT INTO `t_slot_list_useless` VALUES ('14', '阿兹特克', '30', '200', '400', '800', '1600', '3200', '16', '10', '10', '10', '10', '10');
INSERT INTO `t_slot_list_useless` VALUES ('15', '阿兹特克', '30', '1000', '2000', '4000', '8000', '16000', '16', '16', '16', '16', '16', '16');
INSERT INTO `t_slot_list_useless` VALUES ('16', '阿兹特克', '30', '5000', '10000', '20000', '40000', '80000', '16', '22', '22', '22', '22', '22');
INSERT INTO `t_slot_list_useless` VALUES ('17', '宙斯老虎机', '40', '25', '50', '100', '200', '400', '13', '8', '8', '8', '8', '8');
INSERT INTO `t_slot_list_useless` VALUES ('18', '宙斯老虎机', '40', '125', '250', '500', '1000', '2000', '13', '13', '13', '13', '13', '13');
INSERT INTO `t_slot_list_useless` VALUES ('19', '宙斯老虎机', '40', '625', '1250', '2500', '5000', '10000', '13', '19', '19', '19', '19', '19');
INSERT INTO `t_slot_list_useless` VALUES ('20', '宙斯老虎机', '40', '3125', '6250', '12500', '25000', '50000', '13', '25', '25', '25', '25', '25');
INSERT INTO `t_slot_list_useless` VALUES ('21', '忍者', '25', '40', '80', '160', '320', '640', '25', '11', '11', '11', '11', '11');
INSERT INTO `t_slot_list_useless` VALUES ('22', '忍者', '25', '200', '400', '800', '1600', '3200', '25', '16', '16', '16', '16', '16');
INSERT INTO `t_slot_list_useless` VALUES ('23', '忍者', '25', '1000', '2000', '4000', '8000', '16000', '25', '22', '22', '22', '22', '22');
INSERT INTO `t_slot_list_useless` VALUES ('24', '忍者', '25', '5000', '10000', '20000', '40000', '80000', '25', '28', '28', '28', '28', '28');
INSERT INTO `t_slot_list_useless` VALUES ('25', '维密老虎机', '25', '80', '160', '320', '640', '1280', '12', '14', '14', '14', '14', '14');
INSERT INTO `t_slot_list_useless` VALUES ('26', '维密老虎机', '25', '800', '1600', '3200', '6400', '12800', '12', '19', '19', '19', '19', '19');
INSERT INTO `t_slot_list_useless` VALUES ('27', '维密老虎机', '25', '8000', '16000', '32000', '64000', '128000', '12', '25', '25', '25', '25', '25');
INSERT INTO `t_slot_list_useless` VALUES ('28', '维密老虎机', '25', '80000', '160000', '320000', '640000', '1280000', '12', '31', '31', '31', '31', '31');
INSERT INTO `t_slot_list_useless` VALUES ('29', '犀牛', '25', '40', '80', '160', '320', '640', '27', '17', '17', '17', '17', '17');
INSERT INTO `t_slot_list_useless` VALUES ('30', '犀牛', '25', '200', '400', '800', '1600', '3200', '27', '22', '22', '22', '22', '22');
INSERT INTO `t_slot_list_useless` VALUES ('31', '犀牛', '25', '1000', '2000', '4000', '8000', '16000', '27', '28', '28', '28', '28', '28');
INSERT INTO `t_slot_list_useless` VALUES ('32', '犀牛', '25', '5000', '10000', '20000', '40000', '80000', '27', '34', '34', '34', '34', '34');
INSERT INTO `t_slot_list_useless` VALUES ('33', '水晶魔法宝石', '40', '25', '50', '100', '200', '400', '19', '20', '20', '20', '20', '20');
INSERT INTO `t_slot_list_useless` VALUES ('34', '水晶魔法宝石', '40', '125', '250', '500', '1000', '2000', '19', '25', '25', '25', '25', '25');
INSERT INTO `t_slot_list_useless` VALUES ('35', '水晶魔法宝石', '40', '625', '1250', '2500', '5000', '10000', '19', '31', '31', '31', '31', '31');
INSERT INTO `t_slot_list_useless` VALUES ('36', '水晶魔法宝石', '40', '3125', '6250', '12500', '25000', '50000', '19', '37', '37', '37', '37', '37');
INSERT INTO `t_slot_list_useless` VALUES ('37', '西部牛仔', '40', '50', '100', '200', '400', '800', '22', '23', '23', '23', '23', '23');
INSERT INTO `t_slot_list_useless` VALUES ('38', '西部牛仔', '40', '500', '1000', '2000', '4000', '8000', '22', '28', '28', '28', '28', '28');
INSERT INTO `t_slot_list_useless` VALUES ('39', '西部牛仔', '40', '5000', '10000', '20000', '40000', '80000', '22', '34', '34', '34', '34', '34');
INSERT INTO `t_slot_list_useless` VALUES ('40', '西部牛仔', '40', '50000', '100000', '200000', '400000', '800000', '22', '40', '40', '40', '40', '40');
INSERT INTO `t_slot_list_useless` VALUES ('41', '巴西风情', '40', '50', '100', '200', '400', '800', '24', '26', '26', '26', '26', '26');
INSERT INTO `t_slot_list_useless` VALUES ('42', '巴西风情', '40', '500', '1000', '2000', '4000', '8000', '24', '31', '31', '31', '31', '31');
INSERT INTO `t_slot_list_useless` VALUES ('43', '巴西风情', '40', '5000', '10000', '20000', '40000', '80000', '24', '37', '37', '37', '37', '37');
INSERT INTO `t_slot_list_useless` VALUES ('44', '巴西风情', '40', '50000', '100000', '200000', '400000', '800000', '24', '43', '43', '43', '43', '43');
INSERT INTO `t_slot_list_useless` VALUES ('45', '女巫魔法', '40', '50', '100', '200', '400', '800', '26', '29', '29', '29', '29', '29');
INSERT INTO `t_slot_list_useless` VALUES ('46', '女巫魔法', '40', '500', '1000', '2000', '4000', '8000', '26', '34', '34', '34', '34', '34');
INSERT INTO `t_slot_list_useless` VALUES ('47', '女巫魔法', '40', '5000', '10000', '20000', '40000', '80000', '26', '40', '40', '40', '40', '40');
INSERT INTO `t_slot_list_useless` VALUES ('48', '女巫魔法', '40', '50000', '100000', '200000', '400000', '800000', '26', '46', '46', '46', '46', '46');
INSERT INTO `t_slot_list_useless` VALUES ('49', '老虎', '40', '50', '100', '200', '400', '800', '21', '32', '32', '32', '32', '32');
INSERT INTO `t_slot_list_useless` VALUES ('50', '老虎', '40', '500', '1000', '2000', '4000', '8000', '21', '37', '37', '37', '37', '37');
INSERT INTO `t_slot_list_useless` VALUES ('51', '老虎', '40', '5000', '10000', '20000', '40000', '80000', '21', '43', '43', '43', '43', '43');
INSERT INTO `t_slot_list_useless` VALUES ('52', '老虎', '40', '50000', '100000', '200000', '400000', '800000', '21', '49', '49', '49', '49', '49');
INSERT INTO `t_slot_list_useless` VALUES ('53', '动物狼', '25', '40', '80', '160', '320', '640', '17', '35', '35', '35', '35', '35');
INSERT INTO `t_slot_list_useless` VALUES ('54', '动物狼', '25', '200', '400', '800', '1600', '3200', '17', '40', '40', '40', '40', '40');
INSERT INTO `t_slot_list_useless` VALUES ('55', '动物狼', '25', '1000', '2000', '4000', '8000', '16000', '17', '46', '46', '46', '46', '46');
INSERT INTO `t_slot_list_useless` VALUES ('56', '动物狼', '25', '5000', '10000', '20000', '40000', '80000', '17', '52', '52', '52', '52', '52');
INSERT INTO `t_slot_list_useless` VALUES ('57', '日月潭', '20', '100', '200', '400', '800', '1600', '11', '38', '38', '38', '38', '38');
INSERT INTO `t_slot_list_useless` VALUES ('58', '日月潭', '20', '1000', '2000', '4000', '8000', '16000', '11', '43', '43', '43', '43', '43');
INSERT INTO `t_slot_list_useless` VALUES ('59', '日月潭', '20', '10000', '20000', '40000', '80000', '160000', '11', '49', '49', '49', '49', '49');
INSERT INTO `t_slot_list_useless` VALUES ('60', '日月潭', '20', '100000', '200000', '400000', '800000', '1600000', '11', '55', '55', '55', '55', '55');
INSERT INTO `t_slot_list_useless` VALUES ('61', '西方龙', '40', '50', '100', '200', '400', '800', '29', '41', '41', '41', '41', '41');
INSERT INTO `t_slot_list_useless` VALUES ('62', '西方龙', '40', '500', '1000', '2000', '4000', '8000', '29', '46', '46', '46', '46', '46');
INSERT INTO `t_slot_list_useless` VALUES ('63', '西方龙', '40', '5000', '10000', '20000', '40000', '80000', '29', '52', '52', '52', '52', '52');
INSERT INTO `t_slot_list_useless` VALUES ('64', '西方龙', '40', '50000', '100000', '200000', '400000', '800000', '29', '58', '58', '58', '58', '58');
INSERT INTO `t_slot_list_useless` VALUES ('65', '海洋世界', '25', '80', '160', '320', '640', '1280', '28', '44', '44', '44', '44', '44');
INSERT INTO `t_slot_list_useless` VALUES ('66', '海洋世界', '25', '800', '1600', '3200', '6400', '12800', '28', '49', '49', '49', '49', '49');
INSERT INTO `t_slot_list_useless` VALUES ('67', '海洋世界', '25', '8000', '16000', '32000', '64000', '128000', '28', '55', '55', '55', '55', '55');
INSERT INTO `t_slot_list_useless` VALUES ('68', '海洋世界', '25', '80000', '160000', '320000', '640000', '1280000', '28', '61', '61', '61', '61', '61');
INSERT INTO `t_slot_list_useless` VALUES ('69', '泰国象', '40', '50', '100', '200', '400', '800', '20', '47', '47', '47', '47', '47');
INSERT INTO `t_slot_list_useless` VALUES ('70', '泰国象', '40', '500', '1000', '2000', '4000', '8000', '20', '52', '52', '52', '52', '52');
INSERT INTO `t_slot_list_useless` VALUES ('71', '泰国象', '40', '5000', '10000', '20000', '40000', '80000', '20', '58', '58', '58', '58', '58');
INSERT INTO `t_slot_list_useless` VALUES ('72', '泰国象', '40', '50000', '100000', '200000', '400000', '800000', '20', '64', '64', '64', '64', '64');
INSERT INTO `t_slot_list_useless` VALUES ('73', '石器时代', '25', '40', '80', '160', '320', '640', '14', '50', '50', '50', '50', '50');
INSERT INTO `t_slot_list_useless` VALUES ('74', '石器时代', '25', '200', '400', '800', '1600', '3200', '14', '55', '55', '55', '55', '55');
INSERT INTO `t_slot_list_useless` VALUES ('75', '石器时代', '25', '1000', '2000', '4000', '8000', '16000', '14', '61', '61', '61', '61', '61');
INSERT INTO `t_slot_list_useless` VALUES ('76', '石器时代', '25', '5000', '10000', '20000', '40000', '80000', '14', '67', '67', '67', '67', '67');
INSERT INTO `t_slot_list_useless` VALUES ('77', 'classic', '20', '150', '300', '600', '1200', '2400', '1', '53', '53', '53', '53', '53');
INSERT INTO `t_slot_list_useless` VALUES ('78', 'classic', '20', '1500', '3000', '6000', '12000', '24000', '1', '58', '58', '58', '58', '58');
INSERT INTO `t_slot_list_useless` VALUES ('79', 'classic', '20', '15000', '30000', '60000', '120000', '240000', '1', '64', '64', '64', '64', '64');
INSERT INTO `t_slot_list_useless` VALUES ('80', 'classic', '20', '150000', '300000', '600000', '1200000', '2400000', '1', '70', '70', '70', '70', '70');
INSERT INTO `t_slot_list_useless` VALUES ('81', '四大美人', '20', '150', '300', '600', '1200', '2400', '2', '56', '56', '56', '56', '56');
INSERT INTO `t_slot_list_useless` VALUES ('82', '四大美人', '20', '1500', '3000', '6000', '12000', '24000', '2', '61', '61', '61', '61', '61');
INSERT INTO `t_slot_list_useless` VALUES ('83', '四大美人', '20', '15000', '30000', '60000', '120000', '240000', '2', '67', '67', '67', '67', '67');
INSERT INTO `t_slot_list_useless` VALUES ('84', '四大美人', '20', '150000', '300000', '600000', '1200000', '2400000', '2', '73', '73', '73', '73', '73');
INSERT INTO `t_slot_list_useless` VALUES ('85', '水果', '40', '75', '150', '300', '600', '1200', '3', '59', '59', '59', '59', '59');
INSERT INTO `t_slot_list_useless` VALUES ('86', '水果', '40', '750', '1500', '3000', '6000', '12000', '3', '64', '64', '64', '64', '64');
INSERT INTO `t_slot_list_useless` VALUES ('87', '水果', '40', '7500', '15000', '30000', '60000', '120000', '3', '70', '70', '70', '70', '70');
INSERT INTO `t_slot_list_useless` VALUES ('88', '水果', '40', '75000', '150000', '300000', '600000', '1200000', '3', '76', '76', '76', '76', '76');
INSERT INTO `t_slot_list_useless` VALUES ('89', '沙滩', '40', '75', '150', '300', '600', '1200', '4', '62', '62', '62', '62', '62');
INSERT INTO `t_slot_list_useless` VALUES ('90', '沙滩', '40', '750', '1500', '3000', '6000', '12000', '4', '67', '67', '67', '67', '67');
INSERT INTO `t_slot_list_useless` VALUES ('91', '沙滩', '40', '7500', '15000', '30000', '60000', '120000', '4', '73', '73', '73', '73', '73');
INSERT INTO `t_slot_list_useless` VALUES ('92', '沙滩', '40', '75000', '150000', '300000', '600000', '1200000', '4', '79', '79', '79', '79', '79');
INSERT INTO `t_slot_list_useless` VALUES ('93', '吸血鬼老虎机', '25', '120', '240', '480', '960', '1920', '5', '65', '65', '65', '65', '65');
INSERT INTO `t_slot_list_useless` VALUES ('94', '吸血鬼老虎机', '25', '1200', '2400', '4800', '9600', '19200', '5', '70', '70', '70', '70', '70');
INSERT INTO `t_slot_list_useless` VALUES ('95', '吸血鬼老虎机', '25', '12000', '24000', '48000', '96000', '192000', '5', '76', '76', '76', '76', '76');
INSERT INTO `t_slot_list_useless` VALUES ('96', '吸血鬼老虎机', '25', '120000', '240000', '480000', '960000', '1920000', '5', '82', '82', '82', '82', '82');
INSERT INTO `t_slot_list_useless` VALUES ('97', '埃及艳后', '25', '120', '240', '480', '960', '1920', '6', '68', '68', '68', '68', '68');
INSERT INTO `t_slot_list_useless` VALUES ('98', '埃及艳后', '25', '1200', '2400', '4800', '9600', '19200', '6', '73', '73', '73', '73', '73');
INSERT INTO `t_slot_list_useless` VALUES ('99', '埃及艳后', '25', '12000', '24000', '48000', '96000', '192000', '6', '79', '79', '79', '79', '79');
INSERT INTO `t_slot_list_useless` VALUES ('100', '埃及艳后', '25', '120000', '240000', '480000', '960000', '1920000', '6', '85', '85', '85', '85', '85');
INSERT INTO `t_slot_list_useless` VALUES ('101', '美人鱼', '20', '150', '300', '600', '1200', '2400', '7', '71', '71', '71', '71', '71');
INSERT INTO `t_slot_list_useless` VALUES ('102', '美人鱼', '20', '1500', '3000', '6000', '12000', '24000', '7', '76', '76', '76', '76', '76');
INSERT INTO `t_slot_list_useless` VALUES ('103', '美人鱼', '20', '15000', '30000', '60000', '120000', '240000', '7', '82', '82', '82', '82', '82');
INSERT INTO `t_slot_list_useless` VALUES ('104', '美人鱼', '20', '150000', '300000', '600000', '1200000', '2400000', '7', '88', '88', '88', '88', '88');
INSERT INTO `t_slot_list_useless` VALUES ('105', '澳门女神', '25', '120', '240', '480', '960', '1920', '8', '74', '74', '74', '74', '74');
INSERT INTO `t_slot_list_useless` VALUES ('106', '澳门女神', '25', '1200', '2400', '4800', '9600', '19200', '8', '79', '79', '79', '79', '79');
INSERT INTO `t_slot_list_useless` VALUES ('107', '澳门女神', '25', '12000', '24000', '48000', '96000', '192000', '8', '85', '85', '85', '85', '85');
INSERT INTO `t_slot_list_useless` VALUES ('108', '澳门女神', '25', '120000', '240000', '480000', '960000', '1920000', '8', '91', '91', '91', '91', '91');
INSERT INTO `t_slot_list_useless` VALUES ('109', '白蛇传', '40', '75', '150', '300', '600', '1200', '9', '77', '77', '77', '77', '77');
INSERT INTO `t_slot_list_useless` VALUES ('110', '白蛇传', '40', '750', '1500', '3000', '6000', '12000', '9', '82', '82', '82', '82', '82');
INSERT INTO `t_slot_list_useless` VALUES ('111', '白蛇传', '40', '7500', '15000', '30000', '60000', '120000', '9', '88', '88', '88', '88', '88');
INSERT INTO `t_slot_list_useless` VALUES ('112', '白蛇传', '40', '75000', '150000', '300000', '600000', '1200000', '9', '94', '94', '94', '94', '94');
INSERT INTO `t_slot_list_useless` VALUES ('113', '马来网红', '40', '100', '200', '400', '800', '1600', '10', '80', '80', '80', '80', '80');
INSERT INTO `t_slot_list_useless` VALUES ('114', '马来网红', '40', '1000', '2000', '4000', '8000', '16000', '10', '85', '85', '85', '85', '85');
INSERT INTO `t_slot_list_useless` VALUES ('115', '马来网红', '40', '10000', '20000', '40000', '80000', '160000', '10', '91', '91', '91', '91', '91');
INSERT INTO `t_slot_list_useless` VALUES ('116', '马来网红', '40', '100000', '200000', '400000', '800000', '1600000', '10', '97', '97', '97', '97', '97');
INSERT INTO `t_slot_list_useless` VALUES ('117', '动物猫', '15', '100', '200', '400', '800', '1600', '18', '50', '50', '50', '50', '50');
INSERT INTO `t_slot_list_useless` VALUES ('118', '动物猫', '15', '1000', '2000', '4000', '8000', '16000', '18', '55', '55', '55', '55', '55');
INSERT INTO `t_slot_list_useless` VALUES ('119', '动物猫', '15', '10000', '20000', '40000', '80000', '160000', '18', '61', '61', '61', '61', '61');
INSERT INTO `t_slot_list_useless` VALUES ('120', '动物猫', '15', '100000', '200000', '400000', '800000', '1600000', '18', '67', '67', '67', '67', '67');

-- ----------------------------
-- Table structure for `t_slot_name`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot_name`;
CREATE TABLE `t_slot_name` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `langDesc` varchar(128) DEFAULT NULL COMMENT '名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot_name
-- ----------------------------
INSERT INTO `t_slot_name` VALUES ('1', '狮身人面像');
INSERT INTO `t_slot_name` VALUES ('2', '狮身人面像');
INSERT INTO `t_slot_name` VALUES ('3', '狮身人面像');
INSERT INTO `t_slot_name` VALUES ('4', '狮身人面像');
INSERT INTO `t_slot_name` VALUES ('5', '福尔摩斯');
INSERT INTO `t_slot_name` VALUES ('6', '福尔摩斯');
INSERT INTO `t_slot_name` VALUES ('7', '福尔摩斯');
INSERT INTO `t_slot_name` VALUES ('8', '福尔摩斯');
INSERT INTO `t_slot_name` VALUES ('9', '东方龙');
INSERT INTO `t_slot_name` VALUES ('10', '东方龙');
INSERT INTO `t_slot_name` VALUES ('11', '东方龙');
INSERT INTO `t_slot_name` VALUES ('12', '东方龙');
INSERT INTO `t_slot_name` VALUES ('13', '阿兹特克');
INSERT INTO `t_slot_name` VALUES ('14', '阿兹特克');
INSERT INTO `t_slot_name` VALUES ('15', '阿兹特克');
INSERT INTO `t_slot_name` VALUES ('16', '阿兹特克');
INSERT INTO `t_slot_name` VALUES ('17', '宙斯老虎机');
INSERT INTO `t_slot_name` VALUES ('18', '宙斯老虎机');
INSERT INTO `t_slot_name` VALUES ('19', '宙斯老虎机');
INSERT INTO `t_slot_name` VALUES ('20', '宙斯老虎机');
INSERT INTO `t_slot_name` VALUES ('21', '忍者');
INSERT INTO `t_slot_name` VALUES ('22', '忍者');
INSERT INTO `t_slot_name` VALUES ('23', '忍者');
INSERT INTO `t_slot_name` VALUES ('24', '忍者');
INSERT INTO `t_slot_name` VALUES ('25', '维密老虎机');
INSERT INTO `t_slot_name` VALUES ('26', '维密老虎机');
INSERT INTO `t_slot_name` VALUES ('27', '维密老虎机');
INSERT INTO `t_slot_name` VALUES ('28', '维密老虎机');
INSERT INTO `t_slot_name` VALUES ('29', '犀牛');
INSERT INTO `t_slot_name` VALUES ('30', '犀牛');
INSERT INTO `t_slot_name` VALUES ('31', '犀牛');
INSERT INTO `t_slot_name` VALUES ('32', '犀牛');
INSERT INTO `t_slot_name` VALUES ('33', '水晶魔法宝石');
INSERT INTO `t_slot_name` VALUES ('34', '水晶魔法宝石');
INSERT INTO `t_slot_name` VALUES ('35', '水晶魔法宝石');
INSERT INTO `t_slot_name` VALUES ('36', '水晶魔法宝石');
INSERT INTO `t_slot_name` VALUES ('37', '西部牛仔');
INSERT INTO `t_slot_name` VALUES ('38', '西部牛仔');
INSERT INTO `t_slot_name` VALUES ('39', '西部牛仔');
INSERT INTO `t_slot_name` VALUES ('40', '西部牛仔');
INSERT INTO `t_slot_name` VALUES ('41', '巴西风情');
INSERT INTO `t_slot_name` VALUES ('42', '巴西风情');
INSERT INTO `t_slot_name` VALUES ('43', '巴西风情');
INSERT INTO `t_slot_name` VALUES ('44', '巴西风情');
INSERT INTO `t_slot_name` VALUES ('45', '女巫魔法');
INSERT INTO `t_slot_name` VALUES ('46', '女巫魔法');
INSERT INTO `t_slot_name` VALUES ('47', '女巫魔法');
INSERT INTO `t_slot_name` VALUES ('48', '女巫魔法');
INSERT INTO `t_slot_name` VALUES ('49', '老虎');
INSERT INTO `t_slot_name` VALUES ('50', '老虎');
INSERT INTO `t_slot_name` VALUES ('51', '老虎');
INSERT INTO `t_slot_name` VALUES ('52', '老虎');
INSERT INTO `t_slot_name` VALUES ('53', '动物狼');
INSERT INTO `t_slot_name` VALUES ('54', '动物狼');
INSERT INTO `t_slot_name` VALUES ('55', '动物狼');
INSERT INTO `t_slot_name` VALUES ('56', '动物狼');
INSERT INTO `t_slot_name` VALUES ('57', '日月潭');
INSERT INTO `t_slot_name` VALUES ('58', '日月潭');
INSERT INTO `t_slot_name` VALUES ('59', '日月潭');
INSERT INTO `t_slot_name` VALUES ('60', '日月潭');
INSERT INTO `t_slot_name` VALUES ('61', '西方龙');
INSERT INTO `t_slot_name` VALUES ('62', '西方龙');
INSERT INTO `t_slot_name` VALUES ('63', '西方龙');
INSERT INTO `t_slot_name` VALUES ('64', '西方龙');
INSERT INTO `t_slot_name` VALUES ('65', '海洋世界');
INSERT INTO `t_slot_name` VALUES ('66', '海洋世界');
INSERT INTO `t_slot_name` VALUES ('67', '海洋世界');
INSERT INTO `t_slot_name` VALUES ('68', '海洋世界');
INSERT INTO `t_slot_name` VALUES ('69', '泰国象');
INSERT INTO `t_slot_name` VALUES ('70', '泰国象');
INSERT INTO `t_slot_name` VALUES ('71', '泰国象');
INSERT INTO `t_slot_name` VALUES ('72', '泰国象');
INSERT INTO `t_slot_name` VALUES ('73', '石器时代');
INSERT INTO `t_slot_name` VALUES ('74', '石器时代');
INSERT INTO `t_slot_name` VALUES ('75', '石器时代');
INSERT INTO `t_slot_name` VALUES ('76', '石器时代');
INSERT INTO `t_slot_name` VALUES ('77', 'classic');
INSERT INTO `t_slot_name` VALUES ('78', 'classic');
INSERT INTO `t_slot_name` VALUES ('79', 'classic');
INSERT INTO `t_slot_name` VALUES ('80', 'classic');
INSERT INTO `t_slot_name` VALUES ('81', '四大美人');
INSERT INTO `t_slot_name` VALUES ('82', '四大美人');
INSERT INTO `t_slot_name` VALUES ('83', '四大美人');
INSERT INTO `t_slot_name` VALUES ('84', '四大美人');
INSERT INTO `t_slot_name` VALUES ('85', '水果');
INSERT INTO `t_slot_name` VALUES ('86', '水果');
INSERT INTO `t_slot_name` VALUES ('87', '水果');
INSERT INTO `t_slot_name` VALUES ('88', '水果');
INSERT INTO `t_slot_name` VALUES ('89', '沙滩');
INSERT INTO `t_slot_name` VALUES ('90', '沙滩');
INSERT INTO `t_slot_name` VALUES ('91', '沙滩');
INSERT INTO `t_slot_name` VALUES ('92', '沙滩');
INSERT INTO `t_slot_name` VALUES ('93', '吸血鬼老虎机');
INSERT INTO `t_slot_name` VALUES ('94', '吸血鬼老虎机');
INSERT INTO `t_slot_name` VALUES ('95', '吸血鬼老虎机');
INSERT INTO `t_slot_name` VALUES ('96', '吸血鬼老虎机');
INSERT INTO `t_slot_name` VALUES ('97', '埃及艳后');
INSERT INTO `t_slot_name` VALUES ('98', '埃及艳后');
INSERT INTO `t_slot_name` VALUES ('99', '埃及艳后');
INSERT INTO `t_slot_name` VALUES ('100', '埃及艳后');
INSERT INTO `t_slot_name` VALUES ('101', '美人鱼');
INSERT INTO `t_slot_name` VALUES ('102', '美人鱼');
INSERT INTO `t_slot_name` VALUES ('103', '美人鱼');
INSERT INTO `t_slot_name` VALUES ('104', '美人鱼');
INSERT INTO `t_slot_name` VALUES ('105', '澳门女神');
INSERT INTO `t_slot_name` VALUES ('106', '澳门女神');
INSERT INTO `t_slot_name` VALUES ('107', '澳门女神');
INSERT INTO `t_slot_name` VALUES ('108', '澳门女神');
INSERT INTO `t_slot_name` VALUES ('109', '白蛇传');
INSERT INTO `t_slot_name` VALUES ('110', '白蛇传');
INSERT INTO `t_slot_name` VALUES ('111', '白蛇传');
INSERT INTO `t_slot_name` VALUES ('112', '白蛇传');
INSERT INTO `t_slot_name` VALUES ('113', '马来网红');
INSERT INTO `t_slot_name` VALUES ('114', '马来网红');
INSERT INTO `t_slot_name` VALUES ('115', '马来网红');
INSERT INTO `t_slot_name` VALUES ('116', '马来网红');
INSERT INTO `t_slot_name` VALUES ('117', '动物猫');
INSERT INTO `t_slot_name` VALUES ('118', '动物猫');
INSERT INTO `t_slot_name` VALUES ('119', '动物猫');
INSERT INTO `t_slot_name` VALUES ('120', '动物猫');
