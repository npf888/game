/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50173
Source Host           : localhost:3306
Source Database       : texas

Target Server Type    : MYSQL
Target Server Version : 50173
File Encoding         : 65001

Date: 2018-06-29 18:55:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `bazoo_agent`
-- ----------------------------
DROP TABLE IF EXISTS `bazoo_agent`;
CREATE TABLE `bazoo_agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `passportId` bigint(20) DEFAULT NULL,
  `nickname` varchar(64) DEFAULT NULL COMMENT '代理商昵称',
  `username` varchar(64) DEFAULT NULL COMMENT '用户名',
  `passwords` varchar(128) DEFAULT NULL COMMENT '密码',
  `telephone` varchar(12) DEFAULT NULL COMMENT '电话',
  `identity` varchar(20) DEFAULT NULL COMMENT '身份证',
  `address` varchar(64) DEFAULT NULL COMMENT '地址',
  `wx` varchar(32) DEFAULT NULL COMMENT '微信 号码',
  `qq` varchar(32) DEFAULT NULL COMMENT 'qq 号码',
  `parentId` bigint(20) DEFAULT NULL COMMENT '父ID',
  `state` tinyint(1) DEFAULT NULL COMMENT '状态',
  `sendPackage` tinyint(1) DEFAULT NULL COMMENT '是否可以发送红包 0：是，1：否',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bazoo_agent
-- ----------------------------

-- ----------------------------
-- Table structure for `m_share_user`
-- ----------------------------
DROP TABLE IF EXISTS `m_share_user`;
CREATE TABLE `m_share_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_id` varchar(256) DEFAULT NULL,
  `access_token` varchar(256) DEFAULT NULL,
  `token_expires_in` bigint(20) DEFAULT NULL COMMENT '到期时间',
  `jsapi_ticket` varchar(256) DEFAULT NULL,
  `ticket_expires_in` bigint(20) DEFAULT NULL COMMENT '到期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of m_share_user
-- ----------------------------

-- ----------------------------
-- Table structure for `t_activity`
-- ----------------------------
DROP TABLE IF EXISTS `t_activity`;
CREATE TABLE `t_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `activityType` int(11) DEFAULT '0' COMMENT '活动类型',
  `pageLink` int(11) DEFAULT '0' COMMENT '»î¶¯Á´½Ó',
  `title` varchar(50) DEFAULT NULL COMMENT '±êÌâ',
  `title_cn` varchar(50) DEFAULT NULL COMMENT '±êÌâ',
  `title_tw` varchar(50) DEFAULT NULL COMMENT '±êÌâ',
  `activityDesc` varchar(5000) DEFAULT NULL COMMENT 'ÃèÊö',
  `activityDesc_cn` varchar(5000) DEFAULT NULL COMMENT 'ÃèÊö',
  `activityDesc_tw` varchar(5000) DEFAULT NULL COMMENT 'ÃèÊö',
  `hall_pic_tw` varchar(100) DEFAULT NULL COMMENT '大厅图片,中文繁体',
  `hall_pic_cn` varchar(100) DEFAULT NULL COMMENT '大厅图片,中文简体',
  `hall_pic` varchar(100) DEFAULT NULL COMMENT '大厅游戏',
  `pic` varchar(100) DEFAULT NULL COMMENT '»î¶¯Í¼Æ¬',
  `pic_cn` varchar(100) DEFAULT NULL COMMENT '»î¶¯Í¼Æ¬',
  `pic_tw` varchar(100) DEFAULT NULL COMMENT '»î¶¯Í¼Æ¬',
  `rulePack` varchar(5000) DEFAULT NULL COMMENT '活动明细',
  `daily` int(11) DEFAULT '0' COMMENT '判断是否是隔天刷新 1是隔天刷新',
  `startTime` bigint(20) DEFAULT '0' COMMENT '¿ªÊ¼Ê±¼ä',
  `endTime` bigint(20) DEFAULT '0' COMMENT '½áÊøÊ±¼ä',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_activity
-- ----------------------------

-- ----------------------------
-- Table structure for `t_baccart_room_model`
-- ----------------------------
DROP TABLE IF EXISTS `t_baccart_room_model`;
CREATE TABLE `t_baccart_room_model` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `roomId` int(11) NOT NULL COMMENT '房间号',
  `stock` bigint(20) NOT NULL COMMENT '库存',
  `jackpot` bigint(20) NOT NULL COMMENT 'jackpot',
  `closed` int(11) NOT NULL COMMENT 'closed',
  `updateTime` bigint(20) NOT NULL COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6390527936970785798 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_baccart_room_model
-- ----------------------------
INSERT INTO `t_baccart_room_model` VALUES ('6390527936970785794', '70001', '20000000', '20000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_baccart_room_model` VALUES ('6390527936970785795', '70000', '20000000', '10000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_baccart_room_model` VALUES ('6390527936970785796', '70003', '20000000', '50000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_baccart_room_model` VALUES ('6390527936970785797', '70002', '20000000', '30000000', '0', '1523620590441', '1523620590441');

-- ----------------------------
-- Table structure for `t_bazoo_room_create`
-- ----------------------------
DROP TABLE IF EXISTS `t_bazoo_room_create`;
CREATE TABLE `t_bazoo_room_create` (
  `id` bigint(20) NOT NULL,
  `modeTypePriPubBet` varchar(128) DEFAULT NULL COMMENT '模式-私人或公共-倍场',
  `number` int(11) DEFAULT NULL COMMENT '每个房间的号码',
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_bazoo_room_create
-- ----------------------------

-- ----------------------------
-- Table structure for `t_boss`
-- ----------------------------
DROP TABLE IF EXISTS `t_boss`;
CREATE TABLE `t_boss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nameId` int(11) DEFAULT NULL COMMENT '多语言 名称的ID',
  `descrip` int(11) DEFAULT NULL,
  `bossId` bigint(20) DEFAULT NULL COMMENT 'bossId',
  `type` tinyint(1) DEFAULT NULL COMMENT '1.（airtime）秒内，所有wild连线伤害降低百分之（） 2.恢复自身最大血量的百分之（） 3.（airtime）秒内，收到伤害降低百分之（） 4.（airtime）秒内，有（）概率免疫伤害。',
  `airtime` int(11) DEFAULT NULL COMMENT '技能开始后持续时间（秒） ',
  `wildreduce` int(11) DEFAULT NULL COMMENT 'wild中奖连线伤害降低百分数。（除以100）',
  `recover1` int(11) DEFAULT NULL COMMENT '恢复最大血量百分数（除以100）',
  `damagereduce` int(11) DEFAULT NULL COMMENT '伤害减免百分数 ',
  `avoid` int(11) DEFAULT NULL COMMENT ' 免伤概率，百分数（除以100）',
  `blood` bigint(20) DEFAULT NULL COMMENT '基础血量',
  `rewardNum1` int(11) DEFAULT NULL COMMENT '击杀成功后：奖励金币总数，按照伤害占比瓜分奖励百分比',
  `rewardNum2` int(11) DEFAULT NULL COMMENT '未击杀成功：奖励金币总数，按照伤害占比瓜分奖励百分比 ',
  `changingBlood` bigint(20) DEFAULT NULL COMMENT '变化中的血',
  `increaseBlood` bigint(20) DEFAULT NULL COMMENT '增长的血（每次增长的血 的 ，全部是增长的）',
  `beKilled` tinyint(1) DEFAULT NULL COMMENT '是否 被击杀 1：被击杀- 0：没有被击杀',
  `attackRank` text COMMENT '伤害排行榜：依照当前玩家对boss造成的伤害值及百分比排行，显示前十名及自己的排名',
  `startTime` datetime DEFAULT NULL,
  `continueTime` bigint(20) DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `nextBossId` int(11) DEFAULT NULL COMMENT '下一个boss的ID ,在上一个结束时 生成',
  `lastBossId` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `bossTemplateId` int(11) DEFAULT NULL COMMENT '这个boss 开的是哪个时间段的bossTemplate 的ID',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_boss
-- ----------------------------

-- ----------------------------
-- Table structure for `t_client_resource_version`
-- ----------------------------
DROP TABLE IF EXISTS `t_client_resource_version`;
CREATE TABLE `t_client_resource_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '资源版本',
  `ver` int(11) NOT NULL COMMENT '版本号',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ver` (`ver`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_client_resource_version
-- ----------------------------

-- ----------------------------
-- Table structure for `t_client_version`
-- ----------------------------
DROP TABLE IF EXISTS `t_client_version`;
CREATE TABLE `t_client_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '资源版本',
  `version` varchar(50) NOT NULL COMMENT '版本号',
  `minVersion` varchar(50) NOT NULL COMMENT '最小版本号',
  `updateTime` bigint(20) NOT NULL COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_client_version
-- ----------------------------
INSERT INTO `t_client_version` VALUES ('1', '1.1.1', '1.1.1', '0', '0');

-- ----------------------------
-- Table structure for `t_club`
-- ----------------------------
DROP TABLE IF EXISTS `t_club`;
CREATE TABLE `t_club` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'idguid',
  `name` varchar(64) DEFAULT NULL COMMENT '名字',
  `ico` int(11) DEFAULT NULL COMMENT '图标',
  `club_limit` int(11) DEFAULT NULL COMMENT '段位要求',
  `level` int(11) NOT NULL COMMENT '等级',
  `club_type` int(11) NOT NULL COMMENT '类型 1	公开 2	需要申请  3 不可加入',
  `max_num` int(11) NOT NULL COMMENT '最大人数',
  `money` int(11) NOT NULL COMMENT '资产玩家捐的钱',
  `huoyue` int(11) NOT NULL COMMENT '活跃',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `notice` varchar(512) DEFAULT NULL COMMENT '俱乐部描述'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部表';

-- ----------------------------
-- Records of t_club
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_applys`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_applys`;
CREATE TABLE `t_club_applys` (
  `club_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '俱乐部id',
  `player_id` bigint(20) DEFAULT NULL COMMENT '申请人id',
  `apply_time` timestamp NULL DEFAULT NULL COMMENT '申请时间'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部申请';

-- ----------------------------
-- Records of t_club_applys
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_gift_record`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_gift_record`;
CREATE TABLE `t_club_gift_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clubId` varchar(100) DEFAULT NULL,
  `senderPassportId` bigint(20) DEFAULT NULL,
  `ts` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_club_gift_record
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_invate`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_invate`;
CREATE TABLE `t_club_invate` (
  `player_id` bigint(20) DEFAULT NULL COMMENT '玩家id',
  `club_id` bigint(20) DEFAULT NULL COMMENT '俱乐部id',
  `invate_time` timestamp NULL DEFAULT NULL COMMENT '邀请时间'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='邀请';

-- ----------------------------
-- Records of t_club_invate
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_invate_players`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_invate_players`;
CREATE TABLE `t_club_invate_players` (
  `id` bigint(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) DEFAULT NULL COMMENT '邀请人',
  `invate_player_id` bigint(20) DEFAULT NULL COMMENT '被邀请人id',
  `invate_time` timestamp NULL DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部邀请人列表';

-- ----------------------------
-- Records of t_club_invate_players
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_member_list`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_member_list`;
CREATE TABLE `t_club_member_list` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `club_id` bigint(20) DEFAULT NULL COMMENT '俱乐部id',
  `join_time` datetime DEFAULT NULL COMMENT '加入时间',
  `zhiwu` int(10) unsigned DEFAULT NULL COMMENT '职务',
  `gongxian` int(10) unsigned DEFAULT NULL COMMENT '贡献',
  `huoyue` int(10) unsigned DEFAULT NULL COMMENT '活跃',
  `sign_time` bigint(20) DEFAULT NULL COMMENT '签到时间',
  `donate_time` bigint(20) DEFAULT NULL COMMENT '捐献时间',
  `sex` int(11) DEFAULT NULL COMMENT '性别',
  `vote_agree` int(11) DEFAULT NULL COMMENT '同意人数',
  `agree_ids` text COMMENT '同意玩家ids，逗号分割',
  `refuse_ids` text COMMENT '拒绝玩家ids，逗号分割'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部成员表';

-- ----------------------------
-- Records of t_club_member_list
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_note`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_note`;
CREATE TABLE `t_club_note` (
  `id` bigint(20) DEFAULT NULL COMMENT 'guid',
  `club_id` bigint(20) DEFAULT NULL COMMENT '俱乐部id',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `player_id` bigint(20) DEFAULT NULL COMMENT '玩家id',
  `msg` varchar(64) DEFAULT NULL COMMENT '消息',
  `msg_type` int(11) DEFAULT NULL COMMENT '类型 0 常规 1 礼物',
  `gift_id` varchar(50) DEFAULT NULL COMMENT '礼物id',
  `zhiwu` int(11) DEFAULT NULL COMMENT '职务',
  `money` int(11) DEFAULT NULL COMMENT '金额',
  `ids` text COMMENT '领取人id列表玩家id,分割'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部留言';

-- ----------------------------
-- Records of t_club_note
-- ----------------------------

-- ----------------------------
-- Table structure for `t_club_season`
-- ----------------------------
DROP TABLE IF EXISTS `t_club_season`;
CREATE TABLE `t_club_season` (
  `id` int(11) DEFAULT NULL COMMENT '写死的1',
  `end_time` bigint(20) DEFAULT NULL COMMENT '赛季结束时间'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='俱乐部赛季表';

-- ----------------------------
-- Records of t_club_season
-- ----------------------------

-- ----------------------------
-- Table structure for `t_common_activity`
-- ----------------------------
DROP TABLE IF EXISTS `t_common_activity`;
CREATE TABLE `t_common_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `activityId` bigint(20) DEFAULT '0' COMMENT '»î¶¯id',
  `activityDataPack` varchar(5000) DEFAULT NULL COMMENT '»î¶¯Êý¾Ý',
  `rewardActivityDataPack` varchar(5000) DEFAULT NULL COMMENT '½±ÀøÊý¾Ý',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `conditions` varchar(500) DEFAULT NULL COMMENT '条件，json字符串 （可以是任意条件）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_common_activity
-- ----------------------------

-- ----------------------------
-- Table structure for `t_compensation`
-- ----------------------------
DROP TABLE IF EXISTS `t_compensation`;
CREATE TABLE `t_compensation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `content` varchar(1000) NOT NULL COMMENT '内容',
  `itemPack` varchar(2000) DEFAULT NULL COMMENT '补偿列表',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_compensation
-- ----------------------------

-- ----------------------------
-- Table structure for `t_conversioncode`
-- ----------------------------
DROP TABLE IF EXISTS `t_conversioncode`;
CREATE TABLE `t_conversioncode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conversionCode` varchar(1000) NOT NULL DEFAULT '' COMMENT '兑换码',
  `gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '赠送的筹码',
  `endTime` bigint(20) NOT NULL COMMENT '结束时间',
  `isdelete` int(11) DEFAULT '0' COMMENT '是否有效 1 表示无效的',
  `updateTime` bigint(20) NOT NULL,
  `createTime` bigint(20) NOT NULL,
  `codeType` int(1) NOT NULL COMMENT '0：通用型-每人可用一次；1：特殊型-只能给一个人用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395153497093473287 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_conversioncode
-- ----------------------------
INSERT INTO `t_conversioncode` VALUES ('6395153497093473282', '4723409918', '10000', '1526054400000', '0', '1524723409913', '1524723409913', '0');
INSERT INTO `t_conversioncode` VALUES ('6395153497093473283', '4723409923', '10000', '1526054400000', '0', '1524723409913', '1524723409913', '0');
INSERT INTO `t_conversioncode` VALUES ('6395153497093473284', '4723409928', '10000', '1526054400000', '0', '1524723409913', '1524723409913', '0');
INSERT INTO `t_conversioncode` VALUES ('6395153497093473285', '4723409933', '10000', '1526054400000', '0', '1524723409913', '1524723409913', '0');
INSERT INTO `t_conversioncode` VALUES ('6395153497093473286', '4723409938', '10000', '1526054400000', '0', '1524723409913', '1524723409913', '0');

-- ----------------------------
-- Table structure for `t_db_version`
-- ----------------------------
DROP TABLE IF EXISTS `t_db_version`;
CREATE TABLE `t_db_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updateTime` datetime NOT NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  UNIQUE KEY `version` (`version`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_db_version
-- ----------------------------

-- ----------------------------
-- Table structure for `t_delivery`
-- ----------------------------
DROP TABLE IF EXISTS `t_delivery`;
CREATE TABLE `t_delivery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) DEFAULT '' COMMENT '美元',
  `extraparam1` varchar(255) DEFAULT '' COMMENT '订单号',
  `time` varchar(255) DEFAULT '' COMMENT '请求时间',
  `sign` varchar(255) DEFAULT NULL,
  `roleid` varchar(255) DEFAULT NULL,
  `gold` varchar(255) DEFAULT NULL,
  `merchantref` varchar(255) DEFAULT NULL,
  `zoneid` varchar(255) DEFAULT NULL,
  `pay_type` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_delivery
-- ----------------------------

-- ----------------------------
-- Table structure for `t_device`
-- ----------------------------
DROP TABLE IF EXISTS `t_device`;
CREATE TABLE `t_device` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `deviceType` varchar(4096) DEFAULT NULL COMMENT '设备类型',
  `serverid` varchar(255) DEFAULT NULL COMMENT '服务器id',
  `userid` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `deviceId` varchar(255) DEFAULT NULL,
  `deviceMode` varchar(255) DEFAULT NULL,
  `osVersion` varchar(255) DEFAULT NULL,
  `channelType` int(11) DEFAULT '0',
  `clientVersion` varchar(255) DEFAULT NULL,
  `resourceVersion` int(11) DEFAULT '0',
  `updatetime` bigint(20) DEFAULT '0',
  `createtime` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_device
-- ----------------------------
INSERT INTO `t_device` VALUES ('1', '0', '100001', '1702', '1702', 'localhost', '0', '0', '0', '1.1.6', '0', '1524726544063', '1523621307159');
INSERT INTO `t_device` VALUES ('2', '', '100001', '1704', '1704', '', '', '', '1', '', '0', '1523849611217', '1523849611217');
INSERT INTO `t_device` VALUES ('3', '', '100001', '1705', '1705', '', '', '', '1', '', '0', '1523950561662', '1523849892942');
INSERT INTO `t_device` VALUES ('4', 'OPPO-A57', '100001', '1706', '1706', '868643036963435', 'OPPO A57', '6.0.1-23', '0', '1.0.2', '1', '1524727195439', '1523931762597');
INSERT INTO `t_device` VALUES ('5', 'OPPO-A57', '100001', '1707', '1707', '868643036963435', 'OPPO A57', '6.0.1-23', '0', '1.0.2', '1', '1524727943948', '1524727943948');
INSERT INTO `t_device` VALUES ('6', 'OPPO-A57', '100001', '1708', '1708', '868643036963435', 'OPPO A57', '6.0.1-23', '0', '1.0.2', '1', '1524728512803', '1524728512803');
INSERT INTO `t_device` VALUES ('7', 'OPPO-A57', '100001', '10001', '10001', '868643036963435', 'OPPO A57', '6.0.1-23', '0', '1.0.2', '1', '1524728650224', '1524728650224');
INSERT INTO `t_device` VALUES ('8', 'OPPO-A57', '100001', '10002', '10002', '868643036963435', 'OPPO A57', '6.0.1-23', '0', '1.0.2', '1', '1524730804038', '1524728688554');

-- ----------------------------
-- Table structure for `t_function`
-- ----------------------------
DROP TABLE IF EXISTS `t_function`;
CREATE TABLE `t_function` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `functionType` tinyint(3) DEFAULT NULL COMMENT '功能的类型',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `descrip` varchar(250) DEFAULT NULL COMMENT '描述',
  `pic` varchar(100) DEFAULT NULL COMMENT '功能图片',
  `startTime` datetime DEFAULT NULL COMMENT '买一赠一的功能 开始时间',
  `endTime` datetime DEFAULT NULL COMMENT '买一赠一的功能 结束时间',
  `conditions` text COMMENT '条件',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_function
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_achievement`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_achievement`;
CREATE TABLE `t_human_achievement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `charId` bigint(20) NOT NULL COMMENT '角色ID',
  `achValue` text COMMENT '（id:state(1 没有完成 2 已经完成但没有领取 3 已经领取)：time:时间）',
  `achDate` text COMMENT '大类型小类型累计值',
  `slotRotate` bigint(20) DEFAULT '0',
  `slotWin` bigint(20) DEFAULT '0',
  `slotSingleWin` bigint(20) DEFAULT '0',
  `updateTime` bigint(20) DEFAULT '0',
  `createTime` bigint(20) DEFAULT '0',
  `slotWinNum` bigint(20) DEFAULT '0' COMMENT '玩家总胜利次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_achievement
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_activity`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_activity`;
CREATE TABLE `t_human_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) DEFAULT '0' COMMENT '½ÇÉ«id',
  `activityId` bigint(20) DEFAULT '0' COMMENT '»î¶¯id',
  `activityDataPack` varchar(5000) DEFAULT NULL COMMENT '»î¶¯Êý¾Ý',
  `rewardActivityDataPack` varchar(5000) DEFAULT NULL COMMENT '½±ÀøÊý¾Ý',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `friendId` text COMMENT '好友的ID,用 ， 分割',
  `conditions` text COMMENT '条件，json字符串 （可以是任意条件）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_activity
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_attack_boss`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_attack_boss`;
CREATE TABLE `t_human_attack_boss` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `userId` bigint(20) DEFAULT NULL COMMENT '用户的ID',
  `bossId` bigint(20) DEFAULT NULL COMMENT 'boss的 ID',
  `attackBlood` bigint(20) DEFAULT NULL COMMENT '每次攻击 boss的血量',
  `attackTotalBlood` bigint(20) DEFAULT NULL COMMENT '总的攻击血量',
  `attackAllTotalBlood` bigint(20) DEFAULT NULL COMMENT '累计攻击boss 的钱',
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_attack_boss
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_baccart`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_baccart`;
CREATE TABLE `t_human_baccart` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `bankerNum` bigint(20) NOT NULL COMMENT '上庄数',
  `gameNum` bigint(20) NOT NULL COMMENT '游戏数',
  `winNum` bigint(20) NOT NULL COMMENT '赢次数',
  `beaconNum` bigint(20) NOT NULL COMMENT '明灯数',
  `lostNum` bigint(20) NOT NULL COMMENT '输次数',
  `isAuto` int(11) NOT NULL COMMENT '自动',
  `updateTime` bigint(20) NOT NULL COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_baccart
-- ----------------------------
INSERT INTO `t_human_baccart` VALUES ('6390530967493837826', '1702', '0', '0', '0', '0', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_baccart` VALUES ('6391488522273588226', '1704', '0', '0', '0', '0', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_baccart` VALUES ('6391489703884522499', '1705', '0', '0', '0', '0', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_baccart` VALUES ('6391833090110161922', '1706', '0', '0', '0', '0', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_baccart` VALUES ('6395172516739580930', '1707', '0', '0', '0', '0', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_baccart` VALUES ('6395174902690382851', '1708', '0', '0', '0', '0', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_baccart` VALUES ('6395175479071638532', '10001', '0', '0', '0', '0', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_baccart` VALUES ('6395175639839310853', '10002', '0', '0', '0', '0', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_bazoo_achieve`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_achieve`;
CREATE TABLE `t_human_bazoo_achieve` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `passportId` bigint(20) DEFAULT NULL,
  `achieve` text COMMENT '成就的 json字符串',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_achieve
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_new_guy`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_new_guy`;
CREATE TABLE `t_human_bazoo_new_guy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `type` tinyint(2) DEFAULT NULL COMMENT '1：经典，2：牛牛，3：梭哈，4：红黑',
  `process` int(11) DEFAULT NULL COMMENT '新手的进程,新手进行到哪一步了',
  `updateTime` datetime DEFAULT NULL COMMENT '更新的时间',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_new_guy
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_personal`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_personal`;
CREATE TABLE `t_human_bazoo_personal` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `passportId` bigint(20) DEFAULT NULL,
  `modeType` tinyint(1) DEFAULT NULL,
  `numberOfGame` int(11) DEFAULT NULL COMMENT '局数',
  `winTimes` int(11) DEFAULT NULL COMMENT '赢得次数',
  `singleTopGold` bigint(20) DEFAULT NULL COMMENT '单局最高',
  `rateOfWinning` int(11) DEFAULT NULL COMMENT '胜率',
  `aWinningStreak` int(11) DEFAULT NULL COMMENT '连胜',
  `passToKill` int(11) DEFAULT NULL COMMENT '通杀',
  `bigPatterns` varchar(64) DEFAULT NULL COMMENT '最大牌型',
  `pantherNumber` int(11) DEFAULT NULL COMMENT '豹子数',
  `threeKill` int(11) DEFAULT NULL COMMENT '三杀',
  `fourKill` int(11) DEFAULT NULL COMMENT '四杀',
  `fiveKill` int(11) DEFAULT NULL COMMENT '五杀',
  `dayProfit` bigint(20) DEFAULT NULL,
  `weekProfit` bigint(20) DEFAULT NULL,
  `monthProfit` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_personal
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_rank`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_rank`;
CREATE TABLE `t_human_bazoo_rank` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `passportId` bigint(20) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `headImg` varchar(256) DEFAULT NULL,
  `dayProfit` bigint(20) DEFAULT NULL COMMENT '每天的盈利',
  `weekProfit` bigint(20) DEFAULT NULL COMMENT '每周的盈利',
  `monthProfit` bigint(20) DEFAULT NULL COMMENT '每月的盈利',
  `bazooAgentDisplay` tinyint(1) DEFAULT NULL COMMENT '代理商是否显示在排行榜 0：显示，1：不显示',
  `bazooRobotDisplay` tinyint(1) DEFAULT NULL COMMENT '机器人 是否显示在排行榜 0：显示，1：不显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_rank
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_signin`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_signin`;
CREATE TABLE `t_human_bazoo_signin` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户签到次数',
  `passportId` bigint(20) DEFAULT NULL,
  `times` int(6) DEFAULT NULL,
  `signInTime` datetime DEFAULT NULL COMMENT '签到时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_signin
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_task`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_task`;
CREATE TABLE `t_human_bazoo_task` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `passportId` bigint(20) DEFAULT NULL,
  `task` text COMMENT '所有任务  json字符串',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_task
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_bazoo_wins`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_bazoo_wins`;
CREATE TABLE `t_human_bazoo_wins` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `passportId` bigint(20) DEFAULT NULL,
  `modeType` tinyint(1) DEFAULT NULL COMMENT '模式 类型',
  `winTimes` int(11) DEFAULT NULL COMMENT '连胜 次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_bazoo_wins
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_collect`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_collect`;
CREATE TABLE `t_human_collect` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `humanId` bigint(20) NOT NULL,
  `carIds` varchar(1000) DEFAULT NULL,
  `debris` varchar(1000) DEFAULT NULL,
  `slotspin` varchar(1000) DEFAULT '',
  `slotpoint` varchar(1000) DEFAULT NULL,
  `updateTime` bigint(20) NOT NULL,
  `createTime` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_collect
-- ----------------------------
INSERT INTO `t_human_collect` VALUES ('6390530967493837826', '1702', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1523621312974', '1523621312974');
INSERT INTO `t_human_collect` VALUES ('6391488522273588226', '1704', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1523849611824', '1523849611824');
INSERT INTO `t_human_collect` VALUES ('6391489703884522499', '1705', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1523849893542', '1523849893542');
INSERT INTO `t_human_collect` VALUES ('6391833090110161922', '1706', '{1:1,2:1,3:1}', '{}', '{17:1,5:1}', '{17:0,5:0}', '1523931939342', '1523931763198');
INSERT INTO `t_human_collect` VALUES ('6395172516739580930', '1707', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1524727944550', '1524727944550');
INSERT INTO `t_human_collect` VALUES ('6395174902690382851', '1708', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1524728513405', '1524728513405');
INSERT INTO `t_human_collect` VALUES ('6395175479071638532', '10001', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1524728650825', '1524728650825');
INSERT INTO `t_human_collect` VALUES ('6395175639839310853', '10002', '{1:1,2:1,3:1}', '{}', '{}', '{}', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_compensation`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_compensation`;
CREATE TABLE `t_human_compensation` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `compensationId` bigint(20) DEFAULT NULL COMMENT '补偿id',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_compensation
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_friend`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_friend`;
CREATE TABLE `t_human_friend` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Íæ¼Ò½ÇÉ«ID',
  `friendId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'ºÃÓÑid',
  `giftTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '礼物时间',
  `facebook` int(11) NOT NULL DEFAULT '0' COMMENT 'facebook',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `agree` tinyint(4) DEFAULT '0' COMMENT '用户 发出的申请好友同意之后，在每次登录的时候都会判断下是否有好友同意了 他的申请，如果有就把该状态改为1，否则是0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_friend
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_friend_gift`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_friend_gift`;
CREATE TABLE `t_human_friend_gift` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT '角色id',
  `friendId` bigint(20) NOT NULL DEFAULT '0' COMMENT '好友id',
  `getTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '领取时间',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_friend_gift
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_friend_request`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_friend_request`;
CREATE TABLE `t_human_friend_request` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Íæ¼Ò½ÇÉ«ID',
  `sendId` bigint(20) NOT NULL DEFAULT '0' COMMENT '·¢ËÍÕßid',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_friend_request
-- ----------------------------
INSERT INTO `t_human_friend_request` VALUES ('6395156160484901890', '1702', '1706', '1524724044915', '1524724044915');

-- ----------------------------
-- Table structure for `t_human_gift`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_gift`;
CREATE TABLE `t_human_gift` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `charId` bigint(20) NOT NULL COMMENT '角色ID',
  `giftid` int(11) DEFAULT NULL COMMENT '优惠弹出礼包',
  `refreshTime` bigint(20) DEFAULT NULL COMMENT '优惠弹出礼包弹出世间点',
  `updateTime` bigint(20) DEFAULT NULL,
  `createTime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_gift
-- ----------------------------
INSERT INTO `t_human_gift` VALUES ('6390530967493837826', '1702', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_gift` VALUES ('6391488522273588226', '1704', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_gift` VALUES ('6391489703884522499', '1705', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_gift` VALUES ('6391833090110161922', '1706', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_gift` VALUES ('6395172516739580930', '1707', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_gift` VALUES ('6395174902690382851', '1708', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_gift` VALUES ('6395175479071638532', '10001', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_gift` VALUES ('6395175639839310853', '10002', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_givealike`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_givealike`;
CREATE TABLE `t_human_givealike` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `userId` bigint(20) DEFAULT NULL,
  `slotType` int(11) DEFAULT NULL COMMENT '哪种类型的老虎机',
  `slotBet` int(11) DEFAULT NULL COMMENT '老虎机 的哪个场，每个老虎机都有四个场 ',
  `content` varchar(255) DEFAULT NULL COMMENT '评价的内容',
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_givealike
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_info`;
CREATE TABLE `t_human_info` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `passportId` bigint(20) DEFAULT NULL COMMENT 'passportId',
  `img` varchar(2000) DEFAULT NULL COMMENT '图像',
  `name` varchar(36) DEFAULT NULL COMMENT '名称',
  `girlFlag` int(11) DEFAULT '0' COMMENT '女性标志',
  `level` bigint(20) NOT NULL DEFAULT '1' COMMENT '等级',
  `diamond` bigint(20) NOT NULL DEFAULT '0' COMMENT '平台币',
  `gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '金币',
  `coupon` bigint(20) NOT NULL DEFAULT '0' COMMENT '点券',
  `charm` bigint(20) NOT NULL DEFAULT '0' COMMENT '魅力值',
  `curExp` bigint(20) NOT NULL DEFAULT '0' COMMENT '当前经验',
  `sceneId` int(11) NOT NULL DEFAULT '0' COMMENT '所在场景Id',
  `lastLoginIp` varchar(50) DEFAULT NULL COMMENT '上次登陆IP',
  `lastLoginTime` bigint(20) DEFAULT NULL COMMENT '上次登陆时间',
  `lastLogoutTime` bigint(20) DEFAULT NULL COMMENT '上次登出时间',
  `totalMinute` int(11) NOT NULL DEFAULT '0' COMMENT '累计在线时长(分钟)',
  `onlineStatus` int(11) NOT NULL DEFAULT '0' COMMENT '在线状态',
  `idleTime` int(11) NOT NULL DEFAULT '0' COMMENT '空闲时间',
  `createTime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `isPay` bigint(20) NOT NULL DEFAULT '0' COMMENT '首充',
  `gameview` varchar(1000) DEFAULT '' COMMENT 'gameview首充记录',
  `newguide` varchar(1000) DEFAULT '' COMMENT '新手引导',
  `addfriendIds` varchar(2000) DEFAULT '' COMMENT '添加好友ID隔天清空',
  `receivecode` text COMMENT '领取随机码',
  `receivecodeTime` varchar(32) DEFAULT NULL COMMENT '某一天兑换的次数,格式：2014-01-14:1',
  `watchNum` int(11) DEFAULT '0' COMMENT '视频观看次数',
  `countries` varchar(255) DEFAULT '' COMMENT '国籍',
  `age` int(11) DEFAULT '0' COMMENT '年龄',
  `slotRotate` bigint(20) DEFAULT '0' COMMENT '总转次数',
  `slotWin` bigint(20) DEFAULT '0' COMMENT '总赢得分',
  `slotSingleWin` bigint(20) DEFAULT '0' COMMENT '单次赢取最大',
  `slotWinNum` bigint(20) DEFAULT '0' COMMENT '玩家总胜利次数',
  `slotRoomId` varchar(255) DEFAULT '' COMMENT '老虎机房间ID',
  `slotId` int(11) DEFAULT '0' COMMENT '老虎机ID',
  `friendId` text COMMENT '好友的ID,用 ， 分割',
  `snginfo` text COMMENT '竞赛排名领奖记录',
  `requestFriendIds` text,
  `newGuyGift` tinyint(1) DEFAULT '0' COMMENT '新手大礼包:1已购买，0 未购买',
  `couponExtraChip` bigint(20) DEFAULT '0' COMMENT '优惠券额外筹码百分比 获得筹码数 = 首充翻倍、VIP翻倍后的筹码数 X （1+ 优惠券额外筹码百分比/100 )',
  `couponDurationDate` datetime DEFAULT NULL COMMENT '当前优惠券的结束日期（到这个日期就结束了，不能在使用了）',
  `regularTime` date DEFAULT NULL COMMENT '用户开始 循环处理 周 月活动的 开始时间',
  `todayView` tinyint(1) DEFAULT '0' COMMENT '1 当天已经显示，0 当天未显示',
  `clubId` varchar(50) DEFAULT NULL COMMENT '俱乐部id',
  `clubSignTs` bigint(20) DEFAULT NULL COMMENT '俱乐部签到时间',
  `clubDonateTs` bigint(20) DEFAULT NULL COMMENT '俱乐部捐献时间',
  `doubleExpEndTime` datetime DEFAULT NULL COMMENT '双倍经验加成',
  `watchTime` datetime DEFAULT NULL COMMENT '观看视频的时间',
  `clientVersion` varchar(50) DEFAULT '',
  `bazooRoom` varchar(64) DEFAULT NULL,
  `bazooGold` bigint(20) DEFAULT '0',
  `bazooAgentDisplay` tinyint(1) DEFAULT NULL COMMENT '代理商是否显示在排行榜 0：显示，1：不显示',
  `bazooRobotDisplay` tinyint(1) DEFAULT NULL COMMENT '机器人 是否显示在排行榜 0：显示，1：不显示',
  `bazooNewGuyProcess` varchar(256) DEFAULT NULL COMMENT '新手的进度({classicCompleted:0, niuniuCompleted:0, showhandCompleted:0, redblackCompleted:0}）',
  `bankGold` bigint(20) DEFAULT '0',
  `bankPassword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  UNIQUE KEY `passportId` (`passportId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_info
-- ----------------------------
INSERT INTO `t_human_info` VALUES ('6390530944781681666', '1702', 'head_3.png', '1702', '0', '50', '0', '9959260000', '0', '150', '0', '1', '192.168.1.11:62226', '1524726544464', '1524727229529', '72', '0', '0', '1523621307559', '0', '[]', '', '{}', '[]', null, '0', 'acl', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, '1.1.1', null, '0', null, null, null, null, '123456');
INSERT INTO `t_human_info` VALUES ('6391488521434727426', '1704', 'head_9', '1704', '0', '100', '0', '9999998999999', '0', '150', '0', '1', '192.168.1.41:63005', '1523849611824', '1523850523144', '15', '0', '0', '1523849611624', '0', '[]', '', '{}', '[]', null, '0', '', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, null, null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6391489703045661699', '1705', 'head_8', '好啊好', '0', '100', '0', '9999999999999', '0', '150', '0', '1', '192.168.1.41:57965', '1523950562463', '1523850523144', '10', '1', '0', '1523849893342', '0', '[]', '', '{}', '[]', null, '0', '', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, null, null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6391833089271301122', '1706', 'head_9.png', '1706', '0', '4', '0', '141450', '0', '150', '10000', '1', '192.168.1.28:34030', '1524727195840', '1524727889589', '40', '0', '0', '1523931762998', '0', '[]', '', '{}', '[\"4723409923\",\"4723409918\"]', '2018-04-26:2', '0', 'cn', '0', '18', '9250', '2700', '9', '', '0', null, '[]', '1702,', '0', '0', null, null, '0', '', '0', '0', null, null, '1.0.2', null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6395172515896525826', '1707', 'head_8.png', '1707', '0', '1', '0', '100000', '0', '150', '0', '1', '192.168.1.28:34065', '1524727944550', '1524729089524', '19', '0', '0', '1524727944349', '0', '[]', '', '{}', '[]', null, '0', 'cn', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, '1.0.2', null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6395174901847327747', '1708', 'head_3.png', '1708', '0', '1', '0', '100000', '0', '150', '0', '1', '192.168.1.28:34068', '1524728513405', '1524729209536', '11', '0', '0', '1524728513204', '0', '[]', '', '{}', '[]', null, '0', 'cn', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, '1.0.2', null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6395175478232777732', '10001', 'head_1.png', '10001', '0', '1', '0', '100000', '0', '150', '0', '1', '192.168.1.28:34083', '1524728650825', '1524729329442', '11', '0', '0', '1524728650625', '0', '[]', '', '{}', '[]', null, '0', 'cn', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, '1.0.2', null, '0', null, null, null, null, null);
INSERT INTO `t_human_info` VALUES ('6395175639000450053', '10002', 'head_2.png', '10002', '0', '1', '0', '100000', '0', '150', '0', '1', '192.168.1.28:34138', '1524730804439', '1524729329442', '10', '1', '0', '1524728688955', '0', '[]', '', '{}', '[\"4723409923\",\"4723409918\"]', '2018-04-25:2', '0', 'cn', '0', '0', '0', '0', '0', '', '0', null, '[]', null, '0', '0', null, null, '0', '', '0', '0', null, null, '1.0.2', null, '0', null, null, null, null, null);

-- ----------------------------
-- Table structure for `t_human_info_20170509`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_info_20170509`;
CREATE TABLE `t_human_info_20170509` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `passportId` bigint(20) DEFAULT NULL COMMENT 'passportId',
  `img` varchar(2000) DEFAULT NULL COMMENT '图像',
  `name` varchar(36) DEFAULT NULL COMMENT '名称',
  `girlFlag` int(11) DEFAULT '0' COMMENT '女性标志',
  `level` bigint(20) NOT NULL DEFAULT '1' COMMENT '等级',
  `diamond` bigint(20) NOT NULL DEFAULT '0' COMMENT '平台币',
  `gold` bigint(20) NOT NULL DEFAULT '0' COMMENT '金币',
  `coupon` bigint(20) NOT NULL DEFAULT '0' COMMENT '点券',
  `charm` bigint(20) NOT NULL DEFAULT '0' COMMENT '魅力值',
  `curExp` bigint(20) NOT NULL DEFAULT '0' COMMENT '当前经验',
  `sceneId` int(11) NOT NULL DEFAULT '0' COMMENT '所在场景Id',
  `lastLoginIp` varchar(50) DEFAULT NULL COMMENT '上次登陆IP',
  `lastLoginTime` bigint(20) DEFAULT NULL COMMENT '上次登陆时间',
  `lastLogoutTime` bigint(20) DEFAULT NULL COMMENT '上次登出时间',
  `totalMinute` int(11) NOT NULL DEFAULT '0' COMMENT '累计在线时长(分钟)',
  `onlineStatus` int(11) NOT NULL DEFAULT '0' COMMENT '在线状态',
  `idleTime` int(11) NOT NULL DEFAULT '0' COMMENT '空闲时间',
  `createTime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `isPay` bigint(20) NOT NULL DEFAULT '0' COMMENT '首充',
  `gameview` varchar(1000) DEFAULT '' COMMENT 'gameview首充记录',
  `newguide` varchar(1000) DEFAULT '' COMMENT '新手引导',
  `addfriendIds` varchar(2000) DEFAULT '' COMMENT '添加好友ID隔天清空',
  `receivecode` varchar(2000) DEFAULT '' COMMENT '领取随机码',
  `watchNum` int(11) DEFAULT '0' COMMENT '视频观看次数',
  `age` int(11) DEFAULT '0' COMMENT '年龄',
  `slotRotate` bigint(20) DEFAULT '0' COMMENT '总转次数',
  `slotWin` bigint(20) DEFAULT '0' COMMENT '总赢得分',
  `slotSingleWin` bigint(20) DEFAULT '0' COMMENT '单次赢取最大',
  `slotWinNum` bigint(20) DEFAULT '0' COMMENT '玩家总胜利次数',
  `countries` varchar(255) DEFAULT '' COMMENT '国籍',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  UNIQUE KEY `passportId` (`passportId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_info_20170509
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_item`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_item`;
CREATE TABLE `t_human_item` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `fromPlayerId` bigint(20) DEFAULT NULL COMMENT '道具是从哪里来的',
  `charId` bigint(20) NOT NULL COMMENT '角色id',
  `templateId` int(11) NOT NULL COMMENT '模板id',
  `overlap` int(11) DEFAULT '0' COMMENT '叠加数',
  `beginTime` bigint(20) DEFAULT '0' COMMENT '开始时间',
  `duration` bigint(20) DEFAULT '0' COMMENT '持续时间',
  `useing` tinyint(1) DEFAULT NULL COMMENT '是否正在使用中 0：否，1：是',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_item
-- ----------------------------
INSERT INTO `t_human_item` VALUES ('6390530967493837826', null, '1702', '20007', '1', '0', '0', null, '1523621312974', '1523621312974');
INSERT INTO `t_human_item` VALUES ('6390530967493837827', null, '1702', '20008', '1', '0', '0', null, '1523621312974', '1523621312974');
INSERT INTO `t_human_item` VALUES ('6390530967493837828', null, '1702', '20009', '1', '0', '0', null, '1523621312974', '1523621312974');
INSERT INTO `t_human_item` VALUES ('6391488522273588226', null, '1704', '20007', '1', '0', '0', null, '1523849611824', '1523849611824');
INSERT INTO `t_human_item` VALUES ('6391488522273588227', null, '1704', '20008', '1', '0', '0', null, '1523849611824', '1523849611824');
INSERT INTO `t_human_item` VALUES ('6391488522273588228', null, '1704', '20009', '1', '0', '0', null, '1523849611824', '1523849611824');
INSERT INTO `t_human_item` VALUES ('6391489703884522501', null, '1705', '20007', '1', '0', '0', null, '1523849893542', '1523849893542');
INSERT INTO `t_human_item` VALUES ('6391489703884522502', null, '1705', '20008', '1', '0', '0', null, '1523849893542', '1523849893542');
INSERT INTO `t_human_item` VALUES ('6391489703884522503', null, '1705', '20009', '1', '0', '0', null, '1523849893542', '1523849893542');
INSERT INTO `t_human_item` VALUES ('6391833090110161922', null, '1706', '20007', '1', '0', '0', null, '1523931763198', '1523931763198');
INSERT INTO `t_human_item` VALUES ('6391833090110161923', null, '1706', '20008', '1', '0', '0', null, '1523931763198', '1523931763198');
INSERT INTO `t_human_item` VALUES ('6391833090110161924', null, '1706', '20009', '1', '0', '0', null, '1523931763198', '1523931763198');
INSERT INTO `t_human_item` VALUES ('6395172516739580930', null, '1707', '20007', '1', '0', '0', null, '1524727944550', '1524727944550');
INSERT INTO `t_human_item` VALUES ('6395172516739580931', null, '1707', '20008', '1', '0', '0', null, '1524727944550', '1524727944550');
INSERT INTO `t_human_item` VALUES ('6395172516739580932', null, '1707', '20009', '1', '0', '0', null, '1524727944550', '1524727944550');
INSERT INTO `t_human_item` VALUES ('6395174902690382853', null, '1708', '20007', '1', '0', '0', null, '1524728513405', '1524728513405');
INSERT INTO `t_human_item` VALUES ('6395174902690382854', null, '1708', '20008', '1', '0', '0', null, '1524728513405', '1524728513405');
INSERT INTO `t_human_item` VALUES ('6395174902690382855', null, '1708', '20009', '1', '0', '0', null, '1524728513405', '1524728513405');
INSERT INTO `t_human_item` VALUES ('6395175479071638536', null, '10001', '20007', '1', '0', '0', null, '1524728650825', '1524728650825');
INSERT INTO `t_human_item` VALUES ('6395175479071638537', null, '10001', '20008', '1', '0', '0', null, '1524728650825', '1524728650825');
INSERT INTO `t_human_item` VALUES ('6395175479071638538', null, '10001', '20009', '1', '0', '0', null, '1524728650825', '1524728650825');
INSERT INTO `t_human_item` VALUES ('6395175639839310859', null, '10002', '20007', '1', '0', '0', null, '1524728689155', '1524728689155');
INSERT INTO `t_human_item` VALUES ('6395175639839310860', null, '10002', '20008', '1', '0', '0', null, '1524728689155', '1524728689155');
INSERT INTO `t_human_item` VALUES ('6395175639839310861', null, '10002', '20009', '1', '0', '0', null, '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_login_days_useless`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_login_days_useless`;
CREATE TABLE `t_human_login_days_useless` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `loginDay` int(11) DEFAULT NULL COMMENT '第几天登陆',
  `loginDays` int(11) DEFAULT NULL COMMENT '登陆了几天',
  `week` int(11) DEFAULT NULL COMMENT '第几周',
  `accountId` int(11) DEFAULT NULL COMMENT '用户ID',
  `regionId` int(11) DEFAULT NULL COMMENT '服务器区ID',
  `serverId` int(11) DEFAULT NULL,
  `level` bigint(20) DEFAULT NULL,
  `accountName` varchar(64) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `countries` varchar(255) DEFAULT NULL COMMENT '前端传过来的国家',
  `ipCountries` varchar(255) DEFAULT NULL COMMENT '通过IP查询国家',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_login_days_useless
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_lucky_match`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_lucky_match`;
CREATE TABLE `t_human_lucky_match` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `lastMatchTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '上次免费时间',
  `poolPack` varchar(100) DEFAULT NULL COMMENT '次数',
  `freeTimes` int(11) NOT NULL DEFAULT '0' COMMENT '次数',
  `times` int(11) NOT NULL DEFAULT '0' COMMENT '次数',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_lucky_match
-- ----------------------------
INSERT INTO `t_human_lucky_match` VALUES ('6390530967493837826', '1702', '0', '[2,3,4,7,9,6,1,5,0,8]', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_lucky_match` VALUES ('6391488522273588226', '1704', '0', '[4,1,7,5,8,2,9,3,6,0]', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_lucky_match` VALUES ('6391489703884522499', '1705', '0', '[0,5,6,1,7,9,8,4,3,2]', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_lucky_match` VALUES ('6391833090110161922', '1706', '0', '[2,5,1,4,3,8,0,7,6,9]', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_lucky_match` VALUES ('6395172516739580930', '1707', '0', '[5,4,8,0,6,3,9,1,2,7]', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_lucky_match` VALUES ('6395174902690382851', '1708', '0', '[1,2,0,8,3,9,4,5,7,6]', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_lucky_match` VALUES ('6395175479071638532', '10001', '0', '[2,9,8,4,5,0,7,3,1,6]', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_lucky_match` VALUES ('6395175639839310853', '10002', '0', '[1,0,4,6,2,5,3,9,8,7]', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_lucky_spin`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_lucky_spin`;
CREATE TABLE `t_human_lucky_spin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `lastSpinTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '上次免费时间',
  `freeTimes` int(11) NOT NULL DEFAULT '0' COMMENT '次数',
  `times` int(11) NOT NULL DEFAULT '0' COMMENT '次数',
  `poolPack` varchar(100) DEFAULT NULL COMMENT '次数',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_lucky_spin
-- ----------------------------
INSERT INTO `t_human_lucky_spin` VALUES ('6390530967493837826', '1702', '0', '0', '0', '[5,9,7,8,1,6,3,4,2,0]', '1523621312974', '1523621312974');
INSERT INTO `t_human_lucky_spin` VALUES ('6391488522273588226', '1704', '0', '0', '0', '[5,9,7,6,0,3,2,8,4,1]', '1523849611824', '1523849611824');
INSERT INTO `t_human_lucky_spin` VALUES ('6391489703884522499', '1705', '0', '0', '0', '[8,9,5,6,3,1,2,4,7,0]', '1523849893542', '1523849893542');
INSERT INTO `t_human_lucky_spin` VALUES ('6391833090110161922', '1706', '0', '0', '0', '[7,0,9,3,8,1,6,2,5,4]', '1523931763198', '1523931763198');
INSERT INTO `t_human_lucky_spin` VALUES ('6395172516739580930', '1707', '0', '0', '0', '[9,3,8,1,6,2,7,4,5,0]', '1524727944550', '1524727944550');
INSERT INTO `t_human_lucky_spin` VALUES ('6395174902690382851', '1708', '0', '0', '0', '[0,3,6,9,7,5,1,4,8,2]', '1524728513405', '1524728513405');
INSERT INTO `t_human_lucky_spin` VALUES ('6395175479071638532', '10001', '0', '0', '0', '[4,9,6,7,8,0,2,5,1,3]', '1524728650825', '1524728650825');
INSERT INTO `t_human_lucky_spin` VALUES ('6395175639839310853', '10002', '0', '0', '0', '[8,5,9,2,6,7,0,3,4,1]', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_misc`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_misc`;
CREATE TABLE `t_human_misc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) DEFAULT '0' COMMENT '½ÇÉ«id',
  `onlineTime` bigint(20) DEFAULT '0' COMMENT 'ÔÚÏßÊ±¼ä',
  `lastGetTime` bigint(20) DEFAULT '0' COMMENT 'ÉÏ´ÎÁìÈ¡Ê±¼ä',
  `currentOnlineRewardId` int(11) DEFAULT '0' COMMENT 'ÔÚÏß½±Àø',
  `firstRechargeTime` bigint(20) DEFAULT '0' COMMENT '首冲时间',
  `renameTimes` int(11) DEFAULT '0' COMMENT '改名次数',
  `adRewards` int(11) DEFAULT '0' COMMENT '广告奖励',
  `newUser` int(11) DEFAULT '0' COMMENT '新玩家',
  `fbInvitePack` varchar(5000) DEFAULT NULL,
  `fbInviteRewardPack` varchar(200) DEFAULT NULL,
  `fbReward` int(200) DEFAULT '0',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `fbThumb` int(11) DEFAULT '0' COMMENT '点赞 1 已经领取过奖了了',
  `refreshTime` bigint(20) DEFAULT '0' COMMENT '刷新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_misc
-- ----------------------------
INSERT INTO `t_human_misc` VALUES ('6390530967493837826', '1702', '0', '1524726357296', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524726357296', '1523621312974', '0', '1524985557296');
INSERT INTO `t_human_misc` VALUES ('6391488522273588226', '1704', '0', '1523849611824', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1523849611824', '1523849611824', '0', '1524108811824');
INSERT INTO `t_human_misc` VALUES ('6391489703884522499', '1705', '0', '1523950562463', '1', '0', '1', '0', '0', '[]', '[0,0,0]', '0', '1523950562867', '1523849893542', '0', '1524109093542');
INSERT INTO `t_human_misc` VALUES ('6391833090110161922', '1706', '0', '1524723427769', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524723427769', '1523931763198', '0', '1524982627769');
INSERT INTO `t_human_misc` VALUES ('6395172516739580930', '1707', '0', '1524727944550', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524727944550', '1524727944550', '0', '1524987144550');
INSERT INTO `t_human_misc` VALUES ('6395174902690382851', '1708', '0', '1524728513405', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524728513405', '1524728513405', '0', '1524987713405');
INSERT INTO `t_human_misc` VALUES ('6395175479071638532', '10001', '0', '1524728650825', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524728650825', '1524728650825', '0', '1524987850825');
INSERT INTO `t_human_misc` VALUES ('6395175639839310853', '10002', '0', '1524728689155', '1', '0', '0', '0', '0', '[]', '[0,0,0]', '0', '1524728689155', '1524728689155', '0', '1524987889155');

-- ----------------------------
-- Table structure for `t_human_month_card`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_month_card`;
CREATE TABLE `t_human_month_card` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Íæ¼Ò½ÇÉ«ID',
  `beginTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¿ªÊ¼Ê±¼ä',
  `getTime` bigint(20) NOT NULL DEFAULT '0' COMMENT 'ÁìÈ¡Ê±¼ä',
  `duration` bigint(20) NOT NULL DEFAULT '0' COMMENT '³ÖÐøÊ±¼ä',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_month_card
-- ----------------------------
INSERT INTO `t_human_month_card` VALUES ('6390530967493837826', '1702', '0', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_month_card` VALUES ('6391488522273588226', '1704', '0', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_month_card` VALUES ('6391489703884522499', '1705', '0', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_month_card` VALUES ('6391833090110161922', '1706', '0', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_month_card` VALUES ('6395172516739580930', '1707', '0', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_month_card` VALUES ('6395174902690382851', '1708', '0', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_month_card` VALUES ('6395175479071638532', '10001', '0', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_month_card` VALUES ('6395175639839310853', '10002', '0', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_month_week`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_month_week`;
CREATE TABLE `t_human_month_week` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `userId` bigint(20) DEFAULT NULL,
  `startTime` datetime DEFAULT NULL COMMENT '周月特惠礼包开启时间',
  `continueTime` bigint(20) DEFAULT NULL COMMENT '持续时间',
  `mwType` tinyint(4) DEFAULT NULL COMMENT '0表示周礼包，1表示月礼包',
  `isBuy` tinyint(1) DEFAULT NULL COMMENT '当周 或者 当月 是否购买（一周 或者一个月只限购一次）0:没有购买，1：购买',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_month_week
-- ----------------------------
INSERT INTO `t_human_month_week` VALUES ('6390530968215258114', '1702', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-13 20:08:33', '2018-04-26 15:05:57');
INSERT INTO `t_human_month_week` VALUES ('6390530968257201155', '1702', '2018-04-13 00:00:00', '3', '1', '0', '2018-04-13 20:08:33', '2018-04-13 20:08:32');
INSERT INTO `t_human_month_week` VALUES ('6391488522982425602', '1704', '2018-04-16 00:00:00', '1', '0', '0', '2018-04-16 11:33:31', '2018-04-16 11:33:31');
INSERT INTO `t_human_month_week` VALUES ('6391488523028562947', '1704', '2018-04-16 00:00:00', '3', '1', '0', '2018-04-16 11:33:32', '2018-04-16 11:33:31');
INSERT INTO `t_human_month_week` VALUES ('6391489704152957956', '1705', '2018-04-16 00:00:00', '1', '0', '0', '2018-04-16 11:38:13', '2018-04-16 11:38:13');
INSERT INTO `t_human_month_week` VALUES ('6391489704165540869', '1705', '2018-04-16 00:00:00', '3', '1', '0', '2018-04-16 11:38:13', '2018-04-16 11:38:13');
INSERT INTO `t_human_month_week` VALUES ('6391833091100017666', '1706', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-17 10:22:43', '2018-04-26 14:17:07');
INSERT INTO `t_human_month_week` VALUES ('6391833091297149955', '1706', '2018-04-17 00:00:00', '3', '1', '0', '2018-04-17 10:22:43', '2018-04-17 10:22:43');
INSERT INTO `t_human_month_week` VALUES ('6395172517058348034', '1707', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-26 15:32:24', '2018-04-26 15:32:24');
INSERT INTO `t_human_month_week` VALUES ('6395172517066736643', '1707', '2018-04-26 00:00:00', '3', '1', '0', '2018-04-26 15:32:24', '2018-04-26 15:32:24');
INSERT INTO `t_human_month_week` VALUES ('6395174902958818308', '1708', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-26 15:41:53', '2018-04-26 15:41:53');
INSERT INTO `t_human_month_week` VALUES ('6395174902967206917', '1708', '2018-04-26 00:00:00', '3', '1', '0', '2018-04-26 15:41:53', '2018-04-26 15:41:53');
INSERT INTO `t_human_month_week` VALUES ('6395175479272965126', '10001', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-26 15:44:10', '2018-04-26 15:44:10');
INSERT INTO `t_human_month_week` VALUES ('6395175479289742343', '10001', '2018-04-26 00:00:00', '3', '1', '0', '2018-04-26 15:44:10', '2018-04-26 15:44:10');
INSERT INTO `t_human_month_week` VALUES ('6395175640040637448', '10002', '2018-04-26 00:00:00', '1', '0', '0', '2018-04-26 15:44:49', '2018-04-26 15:44:49');
INSERT INTO `t_human_month_week` VALUES ('6395175640049026057', '10002', '2018-04-26 00:00:00', '3', '1', '0', '2018-04-26 15:44:49', '2018-04-26 15:44:49');

-- ----------------------------
-- Table structure for `t_human_newbie`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_newbie`;
CREATE TABLE `t_human_newbie` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `charId` bigint(20) DEFAULT NULL,
  `stepId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passportIdIdx` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of t_human_newbie
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_new_comer`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_new_comer`;
CREATE TABLE `t_human_new_comer` (
  `id` bigint(20) NOT NULL,
  `userId` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `startTime` datetime DEFAULT NULL COMMENT '每天第一次登录时间（这个不会变）',
  `perStartTime` datetime DEFAULT NULL COMMENT '每天的 第一次登录时间 （这个会变，根据剩余时间）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_new_comer
-- ----------------------------
INSERT INTO `t_human_new_comer` VALUES ('6390530967493837826', '1702', '2018-04-13 20:08:33', '2018-04-13 20:08:33');
INSERT INTO `t_human_new_comer` VALUES ('6391485331725255682', '1702', '2018-04-16 11:20:51', '2018-04-16 11:20:51');
INSERT INTO `t_human_new_comer` VALUES ('6391488522273588226', '1704', '2018-04-16 11:33:31', '2018-04-16 11:33:31');
INSERT INTO `t_human_new_comer` VALUES ('6391489703884522499', '1705', '2018-04-16 11:38:13', '2018-04-16 11:38:13');
INSERT INTO `t_human_new_comer` VALUES ('6391833090949022722', '1706', '2018-04-17 10:22:43', '2018-04-17 10:22:43');
INSERT INTO `t_human_new_comer` VALUES ('6391911939942548483', '1705', '2018-04-17 15:36:02', '2018-04-17 15:36:02');
INSERT INTO `t_human_new_comer` VALUES ('6395153571986965506', '1706', '2018-04-26 14:17:07', '2018-04-26 14:17:07');
INSERT INTO `t_human_new_comer` VALUES ('6395165859313779714', '1702', '2018-04-26 15:05:57', '2018-04-26 15:05:57');
INSERT INTO `t_human_new_comer` VALUES ('6395172516739580931', '1707', '2018-04-26 15:32:24', '2018-04-26 15:32:24');
INSERT INTO `t_human_new_comer` VALUES ('6395174902690382852', '1708', '2018-04-26 15:41:53', '2018-04-26 15:41:53');
INSERT INTO `t_human_new_comer` VALUES ('6395175479071638533', '10001', '2018-04-26 15:44:10', '2018-04-26 15:44:10');
INSERT INTO `t_human_new_comer` VALUES ('6395175639839310854', '10002', '2018-04-26 15:44:49', '2018-04-26 15:44:49');

-- ----------------------------
-- Table structure for `t_human_payguide`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_payguide`;
CREATE TABLE `t_human_payguide` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `userId` bigint(20) DEFAULT NULL COMMENT '用户的ID',
  `treasury` tinyint(1) DEFAULT NULL COMMENT '小金猪 是否 提醒 1是  ，0 是否',
  `exp` tinyint(1) DEFAULT NULL COMMENT '经验加速卡   是否 提醒 1是  ，0 是否',
  `preference` tinyint(1) DEFAULT NULL COMMENT '特惠礼包   是否 提醒 1是  ，0 是否',
  `club` tinyint(1) DEFAULT NULL COMMENT '俱乐部   是否 提醒 1是  ，0 是否',
  `monthcard` tinyint(1) DEFAULT NULL COMMENT '月卡   是否 提醒 1是  ，0 是否',
  `coupon` tinyint(1) DEFAULT NULL COMMENT '优惠券',
  `time` date DEFAULT NULL COMMENT '本条数据创建时间，每天都会更新，一人就一条，每天更新时间，其他数据为0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_payguide
-- ----------------------------
INSERT INTO `t_human_payguide` VALUES ('6390530968282366978', '1702', '0', '0', '0', '0', '0', '0', '2018-04-26');
INSERT INTO `t_human_payguide` VALUES ('6391488523062117378', '1704', '0', '0', '0', '0', '0', '0', '2018-04-16');
INSERT INTO `t_human_payguide` VALUES ('6391489704199095299', '1705', '0', '0', '0', '0', '0', '0', '2018-04-17');
INSERT INTO `t_human_payguide` VALUES ('6391833091355870210', '1706', '0', '0', '0', '0', '0', '0', '2018-04-26');
INSERT INTO `t_human_payguide` VALUES ('6395172517091902466', '1707', '0', '0', '0', '0', '0', '0', '2018-04-26');
INSERT INTO `t_human_payguide` VALUES ('6395174902983984131', '1708', '0', '0', '0', '0', '0', '0', '2018-04-26');
INSERT INTO `t_human_payguide` VALUES ('6395175479314908164', '10001', '0', '0', '0', '0', '0', '0', '2018-04-26');
INSERT INTO `t_human_payguide` VALUES ('6395175640074191877', '10002', '0', '0', '0', '0', '0', '0', '2018-04-26');

-- ----------------------------
-- Table structure for `t_human_recharge_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_recharge_order`;
CREATE TABLE `t_human_recharge_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) DEFAULT '0' COMMENT '½ÇÉ«id',
  `orderStatus` bigint(20) DEFAULT '0' COMMENT '×´Ì¬',
  `channelId` int(11) DEFAULT '0' COMMENT '渠道id',
  `productId` int(11) DEFAULT '0' COMMENT '²úÆ·id',
  `channel` varchar(100) DEFAULT NULL COMMENT '渠道，某个平台冲的值',
  `channelOrderId` varchar(100) DEFAULT '' COMMENT '渠道订单id',
  `cost` int(11) DEFAULT '0' COMMENT '金钱数',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `topUpType` int(11) DEFAULT '0' COMMENT '支付类型0 普通 1mycard 2mol',
  `authCode` varchar(500) DEFAULT '' COMMENT 'mycard 授权码',
  `tradeSeq` varchar(255) DEFAULT '' COMMENT 'MyCard 交易序號',
  `paymentType` varchar(255) DEFAULT '' COMMENT '付費方式',
  `myCardTradeNo` varchar(255) DEFAULT '',
  `userId` varchar(500) DEFAULT '' COMMENT '亚马逊客户账号',
  `receiptId` varchar(500) DEFAULT '' COMMENT '亚马逊收据ID',
  `currencyCode` varchar(255) DEFAULT '' COMMENT 'mol货币类型',
  `amountmol` int(11) DEFAULT '0' COMMENT '单位是分mol支付',
  `paymentIdmol` varchar(255) DEFAULT '',
  `level` bigint(20) DEFAULT '0' COMMENT '下单的时候用户 的等级',
  `gold` bigint(20) DEFAULT '0' COMMENT '下单的时候用户 的金币',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_recharge_order
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_refund`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_refund`;
CREATE TABLE `t_human_refund` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `content` varchar(1000) NOT NULL COMMENT '内容',
  `itemPack` varchar(2000) DEFAULT NULL COMMENT '补偿列表',
  `refundStatus` int(11) DEFAULT NULL COMMENT '状态',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_refund
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_slot`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_slot`;
CREATE TABLE `t_human_slot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `charId` bigint(20) NOT NULL COMMENT 'charId',
  `slotId` bigint(20) NOT NULL COMMENT '老虎机id',
  `totalBet` bigint(20) NOT NULL COMMENT '总共下注',
  `totalRefund` bigint(20) NOT NULL COMMENT '总共返还',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `totalJackpot` bigint(20) NOT NULL COMMENT '总获得彩金',
  `slotType23Jackpot` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839311346 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_slot
-- ----------------------------
INSERT INTO `t_human_slot` VALUES ('6390530967493837826', '1702', '6390527936970785794', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837827', '1702', '6390527936970785795', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837828', '1702', '6390527936970785796', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837829', '1702', '6390527936970785797', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837830', '1702', '6390527936970785798', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837831', '1702', '6390527936970785799', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837832', '1702', '6390527936970785800', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837833', '1702', '6390527936970785801', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837834', '1702', '6390527936970785802', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837835', '1702', '6390527936970785803', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837836', '1702', '6390527936970785804', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837837', '1702', '6390527936970785805', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837838', '1702', '6390527936970785806', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837839', '1702', '6390527936970785807', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837840', '1702', '6390527936970785808', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837841', '1702', '6390527936970785809', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837842', '1702', '6390527936970785810', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837843', '1702', '6390527936970785811', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837844', '1702', '6390527936970785812', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837845', '1702', '6390527936970785813', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837846', '1702', '6390527936970785814', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837847', '1702', '6390527936970785815', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837848', '1702', '6390527936970785816', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837849', '1702', '6390527936970785817', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837850', '1702', '6390527936970785818', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837851', '1702', '6390527936970785819', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837852', '1702', '6390527936970785820', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837853', '1702', '6390527936970785821', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837854', '1702', '6390527936970785822', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837855', '1702', '6390527936970785823', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837856', '1702', '6390527936970785824', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837857', '1702', '6390527936970785825', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837858', '1702', '6390527936970785826', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837859', '1702', '6390527936970785827', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837860', '1702', '6390527936970785828', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837861', '1702', '6390527936970785829', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837862', '1702', '6390527936970785830', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837863', '1702', '6390527936970785831', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837864', '1702', '6390527936970785832', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837865', '1702', '6390527936970785833', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837866', '1702', '6390527936970785834', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837867', '1702', '6390527936970785835', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837868', '1702', '6390527936970785836', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837869', '1702', '6390527936970785837', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837870', '1702', '6390527936970785838', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837871', '1702', '6390527936970785839', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837872', '1702', '6390527936970785840', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837873', '1702', '6390527936970785841', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837874', '1702', '6390527936970785842', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837875', '1702', '6390527936970785843', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837876', '1702', '6390527936970785844', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837877', '1702', '6390527936970785845', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837878', '1702', '6390527936970785846', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837879', '1702', '6390527936970785847', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837880', '1702', '6390527936970785848', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837881', '1702', '6390527936970785849', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837882', '1702', '6390527936970785850', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837883', '1702', '6390527936970785851', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837884', '1702', '6390527936970785852', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837885', '1702', '6390527936970785853', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837886', '1702', '6390527936970785854', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837887', '1702', '6390527936970785855', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837888', '1702', '6390527936970785856', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837889', '1702', '6390527936970785857', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837890', '1702', '6390527936970785858', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837891', '1702', '6390527936970785859', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837892', '1702', '6390527936970785860', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837893', '1702', '6390527936970785861', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837894', '1702', '6390527936970785862', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837895', '1702', '6390527936970785863', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837896', '1702', '6390527936970785864', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837897', '1702', '6390527936970785865', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837898', '1702', '6390527936970785866', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837899', '1702', '6390527936970785867', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837900', '1702', '6390527936970785868', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837901', '1702', '6390527936970785869', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837902', '1702', '6390527936970785870', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837903', '1702', '6390527936970785871', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837904', '1702', '6390527936970785872', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837905', '1702', '6390527936970785873', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837906', '1702', '6390527936970785874', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837907', '1702', '6390527936970785875', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837908', '1702', '6390527936970785876', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837909', '1702', '6390527936970785877', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837910', '1702', '6390527936970785878', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837911', '1702', '6390527936970785879', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837912', '1702', '6390527936970785880', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837913', '1702', '6390527936970785881', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837914', '1702', '6390527936970785882', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837915', '1702', '6390527936970785883', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837916', '1702', '6390527936970785884', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837917', '1702', '6390527936970785885', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837918', '1702', '6390527936970785886', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837919', '1702', '6390527936970785887', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837920', '1702', '6390527936970785888', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837921', '1702', '6390527936970785889', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837922', '1702', '6390527936970785890', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837923', '1702', '6390527936970785891', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837924', '1702', '6390527936970785892', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837925', '1702', '6390527936970785893', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837926', '1702', '6390527936970785894', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837927', '1702', '6390527936970785895', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837928', '1702', '6390527936970785896', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837929', '1702', '6390527936970785897', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837930', '1702', '6390527936970785898', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837931', '1702', '6390527936970785899', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837932', '1702', '6390527936970785900', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837933', '1702', '6390527936970785901', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837934', '1702', '6390527936970785902', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837935', '1702', '6390527936970785903', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837936', '1702', '6390527936970785904', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837937', '1702', '6390527936970785905', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837938', '1702', '6390527936970785906', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837939', '1702', '6390527936970785907', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837940', '1702', '6390527936970785908', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837941', '1702', '6390527936970785909', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837942', '1702', '6390527936970785910', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837943', '1702', '6390527936970785911', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837944', '1702', '6390527936970785912', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837945', '1702', '6390527936970785913', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837946', '1702', '6390527936970785914', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837947', '1702', '6390527936970785915', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837948', '1702', '6390527936970785916', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6390530967493837949', '1702', '6390527936970785917', '0', '0', '1523621312974', '1523621312974', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588226', '1704', '6390527936970785794', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588227', '1704', '6390527936970785795', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588228', '1704', '6390527936970785796', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588229', '1704', '6390527936970785797', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588230', '1704', '6390527936970785798', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588231', '1704', '6390527936970785799', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588232', '1704', '6390527936970785800', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588233', '1704', '6390527936970785801', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588234', '1704', '6390527936970785802', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588235', '1704', '6390527936970785803', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588236', '1704', '6390527936970785804', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588237', '1704', '6390527936970785805', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588238', '1704', '6390527936970785806', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588239', '1704', '6390527936970785807', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588240', '1704', '6390527936970785808', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588241', '1704', '6390527936970785809', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588242', '1704', '6390527936970785810', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588243', '1704', '6390527936970785811', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588244', '1704', '6390527936970785812', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588245', '1704', '6390527936970785813', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588246', '1704', '6390527936970785814', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588247', '1704', '6390527936970785815', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588248', '1704', '6390527936970785816', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588249', '1704', '6390527936970785817', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588250', '1704', '6390527936970785818', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588251', '1704', '6390527936970785819', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588252', '1704', '6390527936970785820', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588253', '1704', '6390527936970785821', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588254', '1704', '6390527936970785822', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588255', '1704', '6390527936970785823', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588256', '1704', '6390527936970785824', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588257', '1704', '6390527936970785825', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588258', '1704', '6390527936970785826', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588259', '1704', '6390527936970785827', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588260', '1704', '6390527936970785828', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588261', '1704', '6390527936970785829', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588262', '1704', '6390527936970785830', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588263', '1704', '6390527936970785831', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588264', '1704', '6390527936970785832', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588265', '1704', '6390527936970785833', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588266', '1704', '6390527936970785834', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588267', '1704', '6390527936970785835', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588268', '1704', '6390527936970785836', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588269', '1704', '6390527936970785837', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588270', '1704', '6390527936970785838', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588271', '1704', '6390527936970785839', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588272', '1704', '6390527936970785840', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588273', '1704', '6390527936970785841', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588274', '1704', '6390527936970785842', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588275', '1704', '6390527936970785843', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588276', '1704', '6390527936970785844', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588277', '1704', '6390527936970785845', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588278', '1704', '6390527936970785846', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588279', '1704', '6390527936970785847', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588280', '1704', '6390527936970785848', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588281', '1704', '6390527936970785849', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588282', '1704', '6390527936970785850', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588283', '1704', '6390527936970785851', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588284', '1704', '6390527936970785852', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588285', '1704', '6390527936970785853', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588286', '1704', '6390527936970785854', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588287', '1704', '6390527936970785855', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588288', '1704', '6390527936970785856', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588289', '1704', '6390527936970785857', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588290', '1704', '6390527936970785858', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588291', '1704', '6390527936970785859', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588292', '1704', '6390527936970785860', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588293', '1704', '6390527936970785861', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588294', '1704', '6390527936970785862', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588295', '1704', '6390527936970785863', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588296', '1704', '6390527936970785864', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588297', '1704', '6390527936970785865', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588298', '1704', '6390527936970785866', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588299', '1704', '6390527936970785867', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588300', '1704', '6390527936970785868', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588301', '1704', '6390527936970785869', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588302', '1704', '6390527936970785870', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588303', '1704', '6390527936970785871', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588304', '1704', '6390527936970785872', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588305', '1704', '6390527936970785873', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588306', '1704', '6390527936970785874', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588307', '1704', '6390527936970785875', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588308', '1704', '6390527936970785876', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588309', '1704', '6390527936970785877', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588310', '1704', '6390527936970785878', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588311', '1704', '6390527936970785879', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588312', '1704', '6390527936970785880', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588313', '1704', '6390527936970785881', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588314', '1704', '6390527936970785882', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588315', '1704', '6390527936970785883', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588316', '1704', '6390527936970785884', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588317', '1704', '6390527936970785885', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588318', '1704', '6390527936970785886', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588319', '1704', '6390527936970785887', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588320', '1704', '6390527936970785888', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588321', '1704', '6390527936970785889', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588322', '1704', '6390527936970785890', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588323', '1704', '6390527936970785891', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588324', '1704', '6390527936970785892', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588325', '1704', '6390527936970785893', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588326', '1704', '6390527936970785894', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588327', '1704', '6390527936970785895', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588328', '1704', '6390527936970785896', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588329', '1704', '6390527936970785897', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588330', '1704', '6390527936970785898', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588331', '1704', '6390527936970785899', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588332', '1704', '6390527936970785900', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588333', '1704', '6390527936970785901', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588334', '1704', '6390527936970785902', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588335', '1704', '6390527936970785903', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588336', '1704', '6390527936970785904', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588337', '1704', '6390527936970785905', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588338', '1704', '6390527936970785906', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588339', '1704', '6390527936970785907', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588340', '1704', '6390527936970785908', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588341', '1704', '6390527936970785909', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588342', '1704', '6390527936970785910', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588343', '1704', '6390527936970785911', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588344', '1704', '6390527936970785912', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588345', '1704', '6390527936970785913', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588346', '1704', '6390527936970785914', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588347', '1704', '6390527936970785915', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588348', '1704', '6390527936970785916', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391488522273588349', '1704', '6390527936970785917', '0', '0', '1523849611824', '1523849611824', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522622', '1705', '6390527936970785794', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522623', '1705', '6390527936970785795', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522624', '1705', '6390527936970785796', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522625', '1705', '6390527936970785797', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522626', '1705', '6390527936970785798', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522627', '1705', '6390527936970785799', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522628', '1705', '6390527936970785800', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522629', '1705', '6390527936970785801', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522630', '1705', '6390527936970785802', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522631', '1705', '6390527936970785803', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522632', '1705', '6390527936970785804', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522633', '1705', '6390527936970785805', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522634', '1705', '6390527936970785806', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522635', '1705', '6390527936970785807', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522636', '1705', '6390527936970785808', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522637', '1705', '6390527936970785809', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522638', '1705', '6390527936970785810', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522639', '1705', '6390527936970785811', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522640', '1705', '6390527936970785812', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522641', '1705', '6390527936970785813', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522642', '1705', '6390527936970785814', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522643', '1705', '6390527936970785815', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522644', '1705', '6390527936970785816', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522645', '1705', '6390527936970785817', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522646', '1705', '6390527936970785818', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522647', '1705', '6390527936970785819', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522648', '1705', '6390527936970785820', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522649', '1705', '6390527936970785821', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522650', '1705', '6390527936970785822', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522651', '1705', '6390527936970785823', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522652', '1705', '6390527936970785824', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522653', '1705', '6390527936970785825', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522654', '1705', '6390527936970785826', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522655', '1705', '6390527936970785827', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522656', '1705', '6390527936970785828', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522657', '1705', '6390527936970785829', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522658', '1705', '6390527936970785830', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522659', '1705', '6390527936970785831', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522660', '1705', '6390527936970785832', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522661', '1705', '6390527936970785833', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522662', '1705', '6390527936970785834', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522663', '1705', '6390527936970785835', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522664', '1705', '6390527936970785836', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522665', '1705', '6390527936970785837', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522666', '1705', '6390527936970785838', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522667', '1705', '6390527936970785839', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522668', '1705', '6390527936970785840', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522669', '1705', '6390527936970785841', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522670', '1705', '6390527936970785842', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522671', '1705', '6390527936970785843', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522672', '1705', '6390527936970785844', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522673', '1705', '6390527936970785845', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522674', '1705', '6390527936970785846', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522675', '1705', '6390527936970785847', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522676', '1705', '6390527936970785848', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522677', '1705', '6390527936970785849', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522678', '1705', '6390527936970785850', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522679', '1705', '6390527936970785851', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522680', '1705', '6390527936970785852', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522681', '1705', '6390527936970785853', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522682', '1705', '6390527936970785854', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522683', '1705', '6390527936970785855', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522684', '1705', '6390527936970785856', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522685', '1705', '6390527936970785857', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522686', '1705', '6390527936970785858', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522687', '1705', '6390527936970785859', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522688', '1705', '6390527936970785860', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522689', '1705', '6390527936970785861', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522690', '1705', '6390527936970785862', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522691', '1705', '6390527936970785863', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522692', '1705', '6390527936970785864', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522693', '1705', '6390527936970785865', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522694', '1705', '6390527936970785866', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522695', '1705', '6390527936970785867', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522696', '1705', '6390527936970785868', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522697', '1705', '6390527936970785869', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522698', '1705', '6390527936970785870', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522699', '1705', '6390527936970785871', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522700', '1705', '6390527936970785872', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522701', '1705', '6390527936970785873', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522702', '1705', '6390527936970785874', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522703', '1705', '6390527936970785875', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522704', '1705', '6390527936970785876', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522705', '1705', '6390527936970785877', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522706', '1705', '6390527936970785878', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522707', '1705', '6390527936970785879', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522708', '1705', '6390527936970785880', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522709', '1705', '6390527936970785881', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522710', '1705', '6390527936970785882', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522711', '1705', '6390527936970785883', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522712', '1705', '6390527936970785884', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522713', '1705', '6390527936970785885', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522714', '1705', '6390527936970785886', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522715', '1705', '6390527936970785887', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522716', '1705', '6390527936970785888', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522717', '1705', '6390527936970785889', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522718', '1705', '6390527936970785890', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522719', '1705', '6390527936970785891', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522720', '1705', '6390527936970785892', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522721', '1705', '6390527936970785893', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522722', '1705', '6390527936970785894', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522723', '1705', '6390527936970785895', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522724', '1705', '6390527936970785896', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522725', '1705', '6390527936970785897', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522726', '1705', '6390527936970785898', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522727', '1705', '6390527936970785899', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522728', '1705', '6390527936970785900', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522729', '1705', '6390527936970785901', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522730', '1705', '6390527936970785902', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522731', '1705', '6390527936970785903', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522732', '1705', '6390527936970785904', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522733', '1705', '6390527936970785905', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522734', '1705', '6390527936970785906', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522735', '1705', '6390527936970785907', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522736', '1705', '6390527936970785908', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522737', '1705', '6390527936970785909', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522738', '1705', '6390527936970785910', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522739', '1705', '6390527936970785911', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522740', '1705', '6390527936970785912', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522741', '1705', '6390527936970785913', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522742', '1705', '6390527936970785914', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522743', '1705', '6390527936970785915', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522744', '1705', '6390527936970785916', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391489703884522745', '1705', '6390527936970785917', '0', '0', '1523849893542', '1523849893542', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022722', '1706', '6390527936970785794', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022723', '1706', '6390527936970785795', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022724', '1706', '6390527936970785796', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022725', '1706', '6390527936970785797', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022726', '1706', '6390527936970785798', '10000', '3850', '1523931861666', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022727', '1706', '6390527936970785799', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022728', '1706', '6390527936970785800', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022729', '1706', '6390527936970785801', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022730', '1706', '6390527936970785802', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022731', '1706', '6390527936970785803', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022732', '1706', '6390527936970785804', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022733', '1706', '6390527936970785805', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022734', '1706', '6390527936970785806', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022735', '1706', '6390527936970785807', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022736', '1706', '6390527936970785808', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022737', '1706', '6390527936970785809', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022738', '1706', '6390527936970785810', '12000', '5400', '1523931939342', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022739', '1706', '6390527936970785811', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022740', '1706', '6390527936970785812', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022741', '1706', '6390527936970785813', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022742', '1706', '6390527936970785814', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022743', '1706', '6390527936970785815', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022744', '1706', '6390527936970785816', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022745', '1706', '6390527936970785817', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022746', '1706', '6390527936970785818', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022747', '1706', '6390527936970785819', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022748', '1706', '6390527936970785820', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022749', '1706', '6390527936970785821', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022750', '1706', '6390527936970785822', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022751', '1706', '6390527936970785823', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022752', '1706', '6390527936970785824', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022753', '1706', '6390527936970785825', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022754', '1706', '6390527936970785826', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022755', '1706', '6390527936970785827', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022756', '1706', '6390527936970785828', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022757', '1706', '6390527936970785829', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022758', '1706', '6390527936970785830', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022759', '1706', '6390527936970785831', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022760', '1706', '6390527936970785832', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022761', '1706', '6390527936970785833', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022762', '1706', '6390527936970785834', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022763', '1706', '6390527936970785835', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022764', '1706', '6390527936970785836', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022765', '1706', '6390527936970785837', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022766', '1706', '6390527936970785838', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022767', '1706', '6390527936970785839', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022768', '1706', '6390527936970785840', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022769', '1706', '6390527936970785841', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022770', '1706', '6390527936970785842', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022771', '1706', '6390527936970785843', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022772', '1706', '6390527936970785844', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022773', '1706', '6390527936970785845', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022774', '1706', '6390527936970785846', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022775', '1706', '6390527936970785847', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022776', '1706', '6390527936970785848', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022777', '1706', '6390527936970785849', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022778', '1706', '6390527936970785850', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022779', '1706', '6390527936970785851', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022780', '1706', '6390527936970785852', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022781', '1706', '6390527936970785853', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022782', '1706', '6390527936970785854', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022783', '1706', '6390527936970785855', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022784', '1706', '6390527936970785856', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022785', '1706', '6390527936970785857', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022786', '1706', '6390527936970785858', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022787', '1706', '6390527936970785859', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022788', '1706', '6390527936970785860', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022789', '1706', '6390527936970785861', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022790', '1706', '6390527936970785862', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022791', '1706', '6390527936970785863', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022792', '1706', '6390527936970785864', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022793', '1706', '6390527936970785865', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022794', '1706', '6390527936970785866', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022795', '1706', '6390527936970785867', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022796', '1706', '6390527936970785868', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022797', '1706', '6390527936970785869', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022798', '1706', '6390527936970785870', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022799', '1706', '6390527936970785871', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022800', '1706', '6390527936970785872', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022801', '1706', '6390527936970785873', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022802', '1706', '6390527936970785874', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022803', '1706', '6390527936970785875', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022804', '1706', '6390527936970785876', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022805', '1706', '6390527936970785877', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022806', '1706', '6390527936970785878', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022807', '1706', '6390527936970785879', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022808', '1706', '6390527936970785880', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022809', '1706', '6390527936970785881', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022810', '1706', '6390527936970785882', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022811', '1706', '6390527936970785883', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022812', '1706', '6390527936970785884', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022813', '1706', '6390527936970785885', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022814', '1706', '6390527936970785886', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022815', '1706', '6390527936970785887', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022816', '1706', '6390527936970785888', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022817', '1706', '6390527936970785889', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022818', '1706', '6390527936970785890', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022819', '1706', '6390527936970785891', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022820', '1706', '6390527936970785892', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022821', '1706', '6390527936970785893', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022822', '1706', '6390527936970785894', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022823', '1706', '6390527936970785895', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022824', '1706', '6390527936970785896', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022825', '1706', '6390527936970785897', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022826', '1706', '6390527936970785898', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022827', '1706', '6390527936970785899', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022828', '1706', '6390527936970785900', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022829', '1706', '6390527936970785901', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022830', '1706', '6390527936970785902', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022831', '1706', '6390527936970785903', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022832', '1706', '6390527936970785904', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022833', '1706', '6390527936970785905', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022834', '1706', '6390527936970785906', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022835', '1706', '6390527936970785907', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022836', '1706', '6390527936970785908', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022837', '1706', '6390527936970785909', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022838', '1706', '6390527936970785910', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022839', '1706', '6390527936970785911', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022840', '1706', '6390527936970785912', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022841', '1706', '6390527936970785913', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022842', '1706', '6390527936970785914', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022843', '1706', '6390527936970785915', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022844', '1706', '6390527936970785916', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6391833090949022845', '1706', '6390527936970785917', '0', '0', '1523931763398', '1523931763398', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580930', '1707', '6390527936970785794', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580931', '1707', '6390527936970785795', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580932', '1707', '6390527936970785796', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580933', '1707', '6390527936970785797', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580934', '1707', '6390527936970785798', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580935', '1707', '6390527936970785799', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580936', '1707', '6390527936970785800', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580937', '1707', '6390527936970785801', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580938', '1707', '6390527936970785802', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580939', '1707', '6390527936970785803', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580940', '1707', '6390527936970785804', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580941', '1707', '6390527936970785805', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580942', '1707', '6390527936970785806', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580943', '1707', '6390527936970785807', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580944', '1707', '6390527936970785808', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580945', '1707', '6390527936970785809', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580946', '1707', '6390527936970785810', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580947', '1707', '6390527936970785811', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580948', '1707', '6390527936970785812', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580949', '1707', '6390527936970785813', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580950', '1707', '6390527936970785814', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580951', '1707', '6390527936970785815', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580952', '1707', '6390527936970785816', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580953', '1707', '6390527936970785817', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580954', '1707', '6390527936970785818', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580955', '1707', '6390527936970785819', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580956', '1707', '6390527936970785820', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580957', '1707', '6390527936970785821', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580958', '1707', '6390527936970785822', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580959', '1707', '6390527936970785823', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580960', '1707', '6390527936970785824', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580961', '1707', '6390527936970785825', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580962', '1707', '6390527936970785826', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580963', '1707', '6390527936970785827', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580964', '1707', '6390527936970785828', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580965', '1707', '6390527936970785829', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580966', '1707', '6390527936970785830', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580967', '1707', '6390527936970785831', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580968', '1707', '6390527936970785832', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580969', '1707', '6390527936970785833', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580970', '1707', '6390527936970785834', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580971', '1707', '6390527936970785835', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580972', '1707', '6390527936970785836', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580973', '1707', '6390527936970785837', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580974', '1707', '6390527936970785838', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580975', '1707', '6390527936970785839', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580976', '1707', '6390527936970785840', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580977', '1707', '6390527936970785841', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580978', '1707', '6390527936970785842', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580979', '1707', '6390527936970785843', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580980', '1707', '6390527936970785844', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580981', '1707', '6390527936970785845', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580982', '1707', '6390527936970785846', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580983', '1707', '6390527936970785847', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580984', '1707', '6390527936970785848', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580985', '1707', '6390527936970785849', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580986', '1707', '6390527936970785850', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580987', '1707', '6390527936970785851', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580988', '1707', '6390527936970785852', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580989', '1707', '6390527936970785853', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580990', '1707', '6390527936970785854', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580991', '1707', '6390527936970785855', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580992', '1707', '6390527936970785856', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580993', '1707', '6390527936970785857', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580994', '1707', '6390527936970785858', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580995', '1707', '6390527936970785859', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580996', '1707', '6390527936970785860', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580997', '1707', '6390527936970785861', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580998', '1707', '6390527936970785862', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739580999', '1707', '6390527936970785863', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581000', '1707', '6390527936970785864', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581001', '1707', '6390527936970785865', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581002', '1707', '6390527936970785866', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581003', '1707', '6390527936970785867', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581004', '1707', '6390527936970785868', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581005', '1707', '6390527936970785869', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581006', '1707', '6390527936970785870', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581007', '1707', '6390527936970785871', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581008', '1707', '6390527936970785872', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581009', '1707', '6390527936970785873', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581010', '1707', '6390527936970785874', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581011', '1707', '6390527936970785875', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581012', '1707', '6390527936970785876', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581013', '1707', '6390527936970785877', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581014', '1707', '6390527936970785878', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581015', '1707', '6390527936970785879', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581016', '1707', '6390527936970785880', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581017', '1707', '6390527936970785881', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581018', '1707', '6390527936970785882', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581019', '1707', '6390527936970785883', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581020', '1707', '6390527936970785884', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581021', '1707', '6390527936970785885', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581022', '1707', '6390527936970785886', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581023', '1707', '6390527936970785887', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581024', '1707', '6390527936970785888', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581025', '1707', '6390527936970785889', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581026', '1707', '6390527936970785890', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581027', '1707', '6390527936970785891', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581028', '1707', '6390527936970785892', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581029', '1707', '6390527936970785893', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581030', '1707', '6390527936970785894', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581031', '1707', '6390527936970785895', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581032', '1707', '6390527936970785896', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581033', '1707', '6390527936970785897', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581034', '1707', '6390527936970785898', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581035', '1707', '6390527936970785899', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581036', '1707', '6390527936970785900', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581037', '1707', '6390527936970785901', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581038', '1707', '6390527936970785902', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581039', '1707', '6390527936970785903', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581040', '1707', '6390527936970785904', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581041', '1707', '6390527936970785905', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581042', '1707', '6390527936970785906', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581043', '1707', '6390527936970785907', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581044', '1707', '6390527936970785908', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581045', '1707', '6390527936970785909', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581046', '1707', '6390527936970785910', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581047', '1707', '6390527936970785911', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581048', '1707', '6390527936970785912', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581049', '1707', '6390527936970785913', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581050', '1707', '6390527936970785914', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581051', '1707', '6390527936970785915', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581052', '1707', '6390527936970785916', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395172516739581053', '1707', '6390527936970785917', '0', '0', '1524727944550', '1524727944550', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382974', '1708', '6390527936970785794', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382975', '1708', '6390527936970785795', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382976', '1708', '6390527936970785796', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382977', '1708', '6390527936970785797', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382978', '1708', '6390527936970785798', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382979', '1708', '6390527936970785799', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382980', '1708', '6390527936970785800', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382981', '1708', '6390527936970785801', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382982', '1708', '6390527936970785802', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382983', '1708', '6390527936970785803', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382984', '1708', '6390527936970785804', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382985', '1708', '6390527936970785805', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382986', '1708', '6390527936970785806', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382987', '1708', '6390527936970785807', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382988', '1708', '6390527936970785808', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382989', '1708', '6390527936970785809', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382990', '1708', '6390527936970785810', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382991', '1708', '6390527936970785811', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382992', '1708', '6390527936970785812', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382993', '1708', '6390527936970785813', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382994', '1708', '6390527936970785814', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382995', '1708', '6390527936970785815', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382996', '1708', '6390527936970785816', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382997', '1708', '6390527936970785817', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382998', '1708', '6390527936970785818', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690382999', '1708', '6390527936970785819', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383000', '1708', '6390527936970785820', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383001', '1708', '6390527936970785821', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383002', '1708', '6390527936970785822', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383003', '1708', '6390527936970785823', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383004', '1708', '6390527936970785824', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383005', '1708', '6390527936970785825', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383006', '1708', '6390527936970785826', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383007', '1708', '6390527936970785827', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383008', '1708', '6390527936970785828', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383009', '1708', '6390527936970785829', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383010', '1708', '6390527936970785830', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383011', '1708', '6390527936970785831', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383012', '1708', '6390527936970785832', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383013', '1708', '6390527936970785833', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383014', '1708', '6390527936970785834', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383015', '1708', '6390527936970785835', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383016', '1708', '6390527936970785836', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383017', '1708', '6390527936970785837', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383018', '1708', '6390527936970785838', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383019', '1708', '6390527936970785839', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383020', '1708', '6390527936970785840', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383021', '1708', '6390527936970785841', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383022', '1708', '6390527936970785842', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383023', '1708', '6390527936970785843', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383024', '1708', '6390527936970785844', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383025', '1708', '6390527936970785845', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383026', '1708', '6390527936970785846', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383027', '1708', '6390527936970785847', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383028', '1708', '6390527936970785848', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383029', '1708', '6390527936970785849', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383030', '1708', '6390527936970785850', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383031', '1708', '6390527936970785851', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383032', '1708', '6390527936970785852', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383033', '1708', '6390527936970785853', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383034', '1708', '6390527936970785854', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383035', '1708', '6390527936970785855', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383036', '1708', '6390527936970785856', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383037', '1708', '6390527936970785857', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383038', '1708', '6390527936970785858', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383039', '1708', '6390527936970785859', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383040', '1708', '6390527936970785860', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383041', '1708', '6390527936970785861', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383042', '1708', '6390527936970785862', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383043', '1708', '6390527936970785863', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383044', '1708', '6390527936970785864', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383045', '1708', '6390527936970785865', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383046', '1708', '6390527936970785866', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383047', '1708', '6390527936970785867', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383048', '1708', '6390527936970785868', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383049', '1708', '6390527936970785869', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383050', '1708', '6390527936970785870', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383051', '1708', '6390527936970785871', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383052', '1708', '6390527936970785872', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383053', '1708', '6390527936970785873', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383054', '1708', '6390527936970785874', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383055', '1708', '6390527936970785875', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383056', '1708', '6390527936970785876', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383057', '1708', '6390527936970785877', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383058', '1708', '6390527936970785878', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383059', '1708', '6390527936970785879', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383060', '1708', '6390527936970785880', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383061', '1708', '6390527936970785881', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383062', '1708', '6390527936970785882', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383063', '1708', '6390527936970785883', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383064', '1708', '6390527936970785884', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383065', '1708', '6390527936970785885', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383066', '1708', '6390527936970785886', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383067', '1708', '6390527936970785887', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383068', '1708', '6390527936970785888', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383069', '1708', '6390527936970785889', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383070', '1708', '6390527936970785890', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383071', '1708', '6390527936970785891', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383072', '1708', '6390527936970785892', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383073', '1708', '6390527936970785893', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383074', '1708', '6390527936970785894', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383075', '1708', '6390527936970785895', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383076', '1708', '6390527936970785896', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383077', '1708', '6390527936970785897', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383078', '1708', '6390527936970785898', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383079', '1708', '6390527936970785899', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383080', '1708', '6390527936970785900', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383081', '1708', '6390527936970785901', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383082', '1708', '6390527936970785902', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383083', '1708', '6390527936970785903', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383084', '1708', '6390527936970785904', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383085', '1708', '6390527936970785905', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383086', '1708', '6390527936970785906', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383087', '1708', '6390527936970785907', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383088', '1708', '6390527936970785908', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383089', '1708', '6390527936970785909', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383090', '1708', '6390527936970785910', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383091', '1708', '6390527936970785911', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383092', '1708', '6390527936970785912', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383093', '1708', '6390527936970785913', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383094', '1708', '6390527936970785914', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383095', '1708', '6390527936970785915', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383096', '1708', '6390527936970785916', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395174902690383097', '1708', '6390527936970785917', '0', '0', '1524728513405', '1524728513405', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638778', '10001', '6390527936970785794', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638779', '10001', '6390527936970785795', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638780', '10001', '6390527936970785796', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638781', '10001', '6390527936970785797', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638782', '10001', '6390527936970785798', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638783', '10001', '6390527936970785799', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638784', '10001', '6390527936970785800', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638785', '10001', '6390527936970785801', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638786', '10001', '6390527936970785802', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638787', '10001', '6390527936970785803', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638788', '10001', '6390527936970785804', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638789', '10001', '6390527936970785805', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638790', '10001', '6390527936970785806', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638791', '10001', '6390527936970785807', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638792', '10001', '6390527936970785808', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638793', '10001', '6390527936970785809', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638794', '10001', '6390527936970785810', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638795', '10001', '6390527936970785811', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638796', '10001', '6390527936970785812', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638797', '10001', '6390527936970785813', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638798', '10001', '6390527936970785814', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638799', '10001', '6390527936970785815', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638800', '10001', '6390527936970785816', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638801', '10001', '6390527936970785817', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638802', '10001', '6390527936970785818', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638803', '10001', '6390527936970785819', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638804', '10001', '6390527936970785820', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638805', '10001', '6390527936970785821', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638806', '10001', '6390527936970785822', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638807', '10001', '6390527936970785823', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638808', '10001', '6390527936970785824', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638809', '10001', '6390527936970785825', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638810', '10001', '6390527936970785826', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638811', '10001', '6390527936970785827', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638812', '10001', '6390527936970785828', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638813', '10001', '6390527936970785829', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638814', '10001', '6390527936970785830', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638815', '10001', '6390527936970785831', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638816', '10001', '6390527936970785832', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638817', '10001', '6390527936970785833', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638818', '10001', '6390527936970785834', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638819', '10001', '6390527936970785835', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638820', '10001', '6390527936970785836', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638821', '10001', '6390527936970785837', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638822', '10001', '6390527936970785838', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638823', '10001', '6390527936970785839', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638824', '10001', '6390527936970785840', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638825', '10001', '6390527936970785841', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638826', '10001', '6390527936970785842', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638827', '10001', '6390527936970785843', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638828', '10001', '6390527936970785844', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638829', '10001', '6390527936970785845', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638830', '10001', '6390527936970785846', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638831', '10001', '6390527936970785847', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638832', '10001', '6390527936970785848', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638833', '10001', '6390527936970785849', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638834', '10001', '6390527936970785850', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638835', '10001', '6390527936970785851', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638836', '10001', '6390527936970785852', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638837', '10001', '6390527936970785853', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638838', '10001', '6390527936970785854', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638839', '10001', '6390527936970785855', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638840', '10001', '6390527936970785856', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638841', '10001', '6390527936970785857', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638842', '10001', '6390527936970785858', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638843', '10001', '6390527936970785859', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638844', '10001', '6390527936970785860', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638845', '10001', '6390527936970785861', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638846', '10001', '6390527936970785862', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638847', '10001', '6390527936970785863', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638848', '10001', '6390527936970785864', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638849', '10001', '6390527936970785865', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638850', '10001', '6390527936970785866', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638851', '10001', '6390527936970785867', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638852', '10001', '6390527936970785868', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638853', '10001', '6390527936970785869', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638854', '10001', '6390527936970785870', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638855', '10001', '6390527936970785871', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638856', '10001', '6390527936970785872', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638857', '10001', '6390527936970785873', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638858', '10001', '6390527936970785874', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638859', '10001', '6390527936970785875', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638860', '10001', '6390527936970785876', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638861', '10001', '6390527936970785877', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638862', '10001', '6390527936970785878', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638863', '10001', '6390527936970785879', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638864', '10001', '6390527936970785880', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638865', '10001', '6390527936970785881', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638866', '10001', '6390527936970785882', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638867', '10001', '6390527936970785883', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638868', '10001', '6390527936970785884', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638869', '10001', '6390527936970785885', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638870', '10001', '6390527936970785886', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638871', '10001', '6390527936970785887', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638872', '10001', '6390527936970785888', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638873', '10001', '6390527936970785889', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638874', '10001', '6390527936970785890', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638875', '10001', '6390527936970785891', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638876', '10001', '6390527936970785892', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638877', '10001', '6390527936970785893', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638878', '10001', '6390527936970785894', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638879', '10001', '6390527936970785895', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638880', '10001', '6390527936970785896', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638881', '10001', '6390527936970785897', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638882', '10001', '6390527936970785898', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638883', '10001', '6390527936970785899', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638884', '10001', '6390527936970785900', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638885', '10001', '6390527936970785901', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638886', '10001', '6390527936970785902', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638887', '10001', '6390527936970785903', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638888', '10001', '6390527936970785904', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638889', '10001', '6390527936970785905', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638890', '10001', '6390527936970785906', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638891', '10001', '6390527936970785907', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638892', '10001', '6390527936970785908', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638893', '10001', '6390527936970785909', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638894', '10001', '6390527936970785910', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638895', '10001', '6390527936970785911', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638896', '10001', '6390527936970785912', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638897', '10001', '6390527936970785913', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638898', '10001', '6390527936970785914', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638899', '10001', '6390527936970785915', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638900', '10001', '6390527936970785916', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175479071638901', '10001', '6390527936970785917', '0', '0', '1524728650825', '1524728650825', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311222', '10002', '6390527936970785794', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311223', '10002', '6390527936970785795', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311224', '10002', '6390527936970785796', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311225', '10002', '6390527936970785797', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311226', '10002', '6390527936970785798', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311227', '10002', '6390527936970785799', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311228', '10002', '6390527936970785800', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311229', '10002', '6390527936970785801', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311230', '10002', '6390527936970785802', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311231', '10002', '6390527936970785803', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311232', '10002', '6390527936970785804', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311233', '10002', '6390527936970785805', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311234', '10002', '6390527936970785806', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311235', '10002', '6390527936970785807', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311236', '10002', '6390527936970785808', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311237', '10002', '6390527936970785809', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311238', '10002', '6390527936970785810', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311239', '10002', '6390527936970785811', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311240', '10002', '6390527936970785812', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311241', '10002', '6390527936970785813', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311242', '10002', '6390527936970785814', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311243', '10002', '6390527936970785815', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311244', '10002', '6390527936970785816', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311245', '10002', '6390527936970785817', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311246', '10002', '6390527936970785818', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311247', '10002', '6390527936970785819', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311248', '10002', '6390527936970785820', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311249', '10002', '6390527936970785821', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311250', '10002', '6390527936970785822', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311251', '10002', '6390527936970785823', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311252', '10002', '6390527936970785824', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311253', '10002', '6390527936970785825', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311254', '10002', '6390527936970785826', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311255', '10002', '6390527936970785827', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311256', '10002', '6390527936970785828', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311257', '10002', '6390527936970785829', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311258', '10002', '6390527936970785830', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311259', '10002', '6390527936970785831', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311260', '10002', '6390527936970785832', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311261', '10002', '6390527936970785833', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311262', '10002', '6390527936970785834', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311263', '10002', '6390527936970785835', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311264', '10002', '6390527936970785836', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311265', '10002', '6390527936970785837', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311266', '10002', '6390527936970785838', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311267', '10002', '6390527936970785839', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311268', '10002', '6390527936970785840', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311269', '10002', '6390527936970785841', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311270', '10002', '6390527936970785842', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311271', '10002', '6390527936970785843', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311272', '10002', '6390527936970785844', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311273', '10002', '6390527936970785845', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311274', '10002', '6390527936970785846', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311275', '10002', '6390527936970785847', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311276', '10002', '6390527936970785848', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311277', '10002', '6390527936970785849', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311278', '10002', '6390527936970785850', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311279', '10002', '6390527936970785851', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311280', '10002', '6390527936970785852', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311281', '10002', '6390527936970785853', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311282', '10002', '6390527936970785854', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311283', '10002', '6390527936970785855', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311284', '10002', '6390527936970785856', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311285', '10002', '6390527936970785857', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311286', '10002', '6390527936970785858', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311287', '10002', '6390527936970785859', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311288', '10002', '6390527936970785860', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311289', '10002', '6390527936970785861', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311290', '10002', '6390527936970785862', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311291', '10002', '6390527936970785863', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311292', '10002', '6390527936970785864', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311293', '10002', '6390527936970785865', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311294', '10002', '6390527936970785866', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311295', '10002', '6390527936970785867', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311296', '10002', '6390527936970785868', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311297', '10002', '6390527936970785869', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311298', '10002', '6390527936970785870', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311299', '10002', '6390527936970785871', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311300', '10002', '6390527936970785872', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311301', '10002', '6390527936970785873', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311302', '10002', '6390527936970785874', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311303', '10002', '6390527936970785875', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311304', '10002', '6390527936970785876', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311305', '10002', '6390527936970785877', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311306', '10002', '6390527936970785878', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311307', '10002', '6390527936970785879', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311308', '10002', '6390527936970785880', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311309', '10002', '6390527936970785881', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311310', '10002', '6390527936970785882', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311311', '10002', '6390527936970785883', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311312', '10002', '6390527936970785884', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311313', '10002', '6390527936970785885', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311314', '10002', '6390527936970785886', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311315', '10002', '6390527936970785887', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311316', '10002', '6390527936970785888', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311317', '10002', '6390527936970785889', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311318', '10002', '6390527936970785890', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311319', '10002', '6390527936970785891', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311320', '10002', '6390527936970785892', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311321', '10002', '6390527936970785893', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311322', '10002', '6390527936970785894', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311323', '10002', '6390527936970785895', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311324', '10002', '6390527936970785896', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311325', '10002', '6390527936970785897', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311326', '10002', '6390527936970785898', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311327', '10002', '6390527936970785899', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311328', '10002', '6390527936970785900', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311329', '10002', '6390527936970785901', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311330', '10002', '6390527936970785902', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311331', '10002', '6390527936970785903', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311332', '10002', '6390527936970785904', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311333', '10002', '6390527936970785905', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311334', '10002', '6390527936970785906', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311335', '10002', '6390527936970785907', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311336', '10002', '6390527936970785908', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311337', '10002', '6390527936970785909', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311338', '10002', '6390527936970785910', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311339', '10002', '6390527936970785911', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311340', '10002', '6390527936970785912', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311341', '10002', '6390527936970785913', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311342', '10002', '6390527936970785914', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311343', '10002', '6390527936970785915', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311344', '10002', '6390527936970785916', '0', '0', '1524728689155', '1524728689155', '0', null);
INSERT INTO `t_human_slot` VALUES ('6395175639839311345', '10002', '6390527936970785917', '0', '0', '1524728689155', '1524728689155', '0', null);

-- ----------------------------
-- Table structure for `t_human_task`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_task`;
CREATE TABLE `t_human_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) DEFAULT '0' COMMENT '½ÇÉ«id',
  `dailyTaskPack` varchar(5000) DEFAULT NULL COMMENT 'ÈÕ³£ÈÎÎñ',
  `taskPack` varchar(5000) DEFAULT NULL COMMENT 'ÈÎÎñ',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `taskProgress` varchar(255) DEFAULT '' COMMENT '任务进度',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_task
-- ----------------------------
INSERT INTO `t_human_task` VALUES ('6390530967493837826', '1702', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30039},{\"finished\":0,\"getNums\":0,\"taskId\":30030},{\"finished\":0,\"getNums\":0,\"taskId\":30033},{\"finished\":0,\"getNums\":0,\"taskId\":30040},{\"finished\":0,\"getNums\":0,\"taskId\":30045},{\"finished\":0,\"getNums\":0,\"taskId\":30064},{\"finished\":0,\"getNums\":0,\"taskId\":30282},{\"finished\":0,\"getNums\":0,\"taskId\":30132}]', '[]', '1524726357296', '1523621312974', '');
INSERT INTO `t_human_task` VALUES ('6391488522273588226', '1704', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30039},{\"finished\":0,\"getNums\":0,\"taskId\":30030},{\"finished\":0,\"getNums\":0,\"taskId\":30033},{\"finished\":0,\"getNums\":0,\"taskId\":30041},{\"finished\":0,\"getNums\":0,\"taskId\":30044},{\"finished\":0,\"getNums\":0,\"taskId\":30099},{\"finished\":0,\"getNums\":0,\"taskId\":30167},{\"finished\":0,\"getNums\":0,\"taskId\":30133}]', '[]', '1523849611824', '1523849611824', '');
INSERT INTO `t_human_task` VALUES ('6391489703884522499', '1705', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30038},{\"finished\":0,\"getNums\":0,\"taskId\":30031},{\"finished\":0,\"getNums\":0,\"taskId\":30034},{\"finished\":0,\"getNums\":0,\"taskId\":30041},{\"finished\":0,\"getNums\":0,\"taskId\":30044},{\"finished\":0,\"getNums\":0,\"taskId\":30197},{\"finished\":0,\"getNums\":0,\"taskId\":30129},{\"finished\":0,\"getNums\":0,\"taskId\":30234}]', '[]', '1523950562463', '1523849893542', '');
INSERT INTO `t_human_task` VALUES ('6391833090110161922', '1706', '[{\"finished\":0,\"getNums\":0,\"taskId\":30036},{\"finished\":0,\"getNums\":0,\"taskId\":30039},{\"finished\":0,\"getNums\":0,\"taskId\":30031},{\"finished\":0,\"getNums\":0,\"taskId\":30034},{\"finished\":0,\"getNums\":0,\"taskId\":30042},{\"finished\":0,\"getNums\":0,\"taskId\":30045},{\"finished\":0,\"getNums\":0,\"taskId\":30208},{\"finished\":0,\"getNums\":0,\"taskId\":30123},{\"finished\":0,\"getNums\":0,\"taskId\":30103}]', '[]', '1524723427769', '1523931763198', '');
INSERT INTO `t_human_task` VALUES ('6395172516739580930', '1707', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30038},{\"finished\":0,\"getNums\":0,\"taskId\":30031},{\"finished\":0,\"getNums\":0,\"taskId\":30032},{\"finished\":0,\"getNums\":0,\"taskId\":30041},{\"finished\":0,\"getNums\":0,\"taskId\":30043},{\"finished\":0,\"getNums\":0,\"taskId\":30145},{\"finished\":0,\"getNums\":0,\"taskId\":30067},{\"finished\":0,\"getNums\":0,\"taskId\":30132}]', '[]', '1524727944550', '1524727944550', '');
INSERT INTO `t_human_task` VALUES ('6395174902690382851', '1708', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30038},{\"finished\":0,\"getNums\":0,\"taskId\":30030},{\"finished\":0,\"getNums\":0,\"taskId\":30032},{\"finished\":0,\"getNums\":0,\"taskId\":30042},{\"finished\":0,\"getNums\":0,\"taskId\":30045},{\"finished\":0,\"getNums\":0,\"taskId\":30164},{\"finished\":0,\"getNums\":0,\"taskId\":30072},{\"finished\":0,\"getNums\":0,\"taskId\":30131}]', '[]', '1524728513405', '1524728513405', '');
INSERT INTO `t_human_task` VALUES ('6395175479071638532', '10001', '[{\"finished\":0,\"getNums\":0,\"taskId\":30036},{\"finished\":0,\"getNums\":0,\"taskId\":30038},{\"finished\":0,\"getNums\":0,\"taskId\":30031},{\"finished\":0,\"getNums\":0,\"taskId\":30033},{\"finished\":0,\"getNums\":0,\"taskId\":30042},{\"finished\":0,\"getNums\":0,\"taskId\":30044},{\"finished\":0,\"getNums\":0,\"taskId\":30238},{\"finished\":0,\"getNums\":0,\"taskId\":30065},{\"finished\":0,\"getNums\":0,\"taskId\":30284}]', '[]', '1524728650825', '1524728650825', '');
INSERT INTO `t_human_task` VALUES ('6395175639839310853', '10002', '[{\"finished\":0,\"getNums\":0,\"taskId\":30037},{\"finished\":0,\"getNums\":0,\"taskId\":30039},{\"finished\":0,\"getNums\":0,\"taskId\":30031},{\"finished\":0,\"getNums\":0,\"taskId\":30034},{\"finished\":0,\"getNums\":0,\"taskId\":30040},{\"finished\":0,\"getNums\":0,\"taskId\":30045},{\"finished\":0,\"getNums\":0,\"taskId\":30179},{\"finished\":0,\"getNums\":0,\"taskId\":30074},{\"finished\":0,\"getNums\":0,\"taskId\":30235}]', '[]', '1524728689155', '1524728689155', '');

-- ----------------------------
-- Table structure for `t_human_texas`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_texas`;
CREATE TABLE `t_human_texas` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家角色ID',
  `isAuto` int(11) NOT NULL DEFAULT '0' COMMENT '是否自动补充',
  `people` int(11) NOT NULL DEFAULT '0' COMMENT '人数',
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '玩的局数',
  `winCount` int(20) NOT NULL DEFAULT '0' COMMENT '胜利局数',
  `biggestHandCard` varchar(50) DEFAULT NULL COMMENT '最大牌型',
  `weekWinCoins` int(11) NOT NULL DEFAULT '0' COMMENT '周盈利',
  `dayBiggestWinCoins` int(11) NOT NULL DEFAULT '0' COMMENT '单日最高盈利',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_texas
-- ----------------------------
INSERT INTO `t_human_texas` VALUES ('6390530967493837826', '1702', '1', '6', '0', '0', '[]', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_texas` VALUES ('6391488522273588226', '1704', '1', '6', '0', '0', '[]', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_texas` VALUES ('6391489703884522499', '1705', '1', '6', '0', '0', '[]', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_texas` VALUES ('6391833090110161922', '1706', '1', '6', '0', '0', '[]', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_texas` VALUES ('6395172516739580930', '1707', '1', '6', '0', '0', '[]', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_texas` VALUES ('6395174902690382851', '1708', '1', '6', '0', '0', '[]', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_texas` VALUES ('6395175479071638532', '10001', '1', '6', '0', '0', '[]', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_texas` VALUES ('6395175639839310853', '10002', '1', '6', '0', '0', '[]', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_texas_sng`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_texas_sng`;
CREATE TABLE `t_human_texas_sng` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT '角色id',
  `joinTimes` int(11) NOT NULL DEFAULT '0' COMMENT '参加次数',
  `goldNum` int(11) DEFAULT NULL COMMENT '金杯数',
  `silverNum` int(11) NOT NULL DEFAULT '0' COMMENT '银杯数',
  `copperNum` int(11) NOT NULL DEFAULT '0' COMMENT '铜杯数',
  `weekScore` int(20) NOT NULL DEFAULT '0' COMMENT '周分数',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_texas_sng
-- ----------------------------
INSERT INTO `t_human_texas_sng` VALUES ('6390530967493837826', '1702', '0', '0', '0', '0', '0', '1524726357296', '1523621312974');
INSERT INTO `t_human_texas_sng` VALUES ('6391488522273588226', '1704', '0', '0', '0', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_texas_sng` VALUES ('6391489703884522499', '1705', '0', '0', '0', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_texas_sng` VALUES ('6391833090110161922', '1706', '0', '0', '0', '0', '0', '1524723427769', '1523931763198');
INSERT INTO `t_human_texas_sng` VALUES ('6395172516739580930', '1707', '0', '0', '0', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_texas_sng` VALUES ('6395174902690382851', '1708', '0', '0', '0', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_texas_sng` VALUES ('6395175479071638532', '10001', '0', '0', '0', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_texas_sng` VALUES ('6395175639839310853', '10002', '0', '0', '0', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_treasury`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_treasury`;
CREATE TABLE `t_human_treasury` (
  `id` bigint(20) NOT NULL,
  `chartId` bigint(20) NOT NULL,
  `type` int(1) DEFAULT NULL COMMENT '共6种类型：0，1，2，3，4，5 -每种的初始金币不同',
  `gold` bigint(20) DEFAULT NULL COMMENT '此时此刻的金币',
  `factorTreasury` int(11) DEFAULT NULL COMMENT '金币存储系数（万分比）',
  `vipPointTreasury` int(11) DEFAULT NULL COMMENT 'VIP点数奖励',
  `maxTreasury` bigint(20) DEFAULT NULL COMMENT '存储上限',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_treasury
-- ----------------------------

-- ----------------------------
-- Table structure for `t_human_vip`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_vip`;
CREATE TABLE `t_human_vip` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) DEFAULT '0' COMMENT '½ÇÉ«id',
  `level` int(11) DEFAULT '0' COMMENT 'ÔÚÏßÊ±¼ä',
  `getTime` bigint(20) DEFAULT '0' COMMENT 'ÉÏ´ÎÁìÈ¡Ê±¼ä',
  `buyTime` bigint(20) DEFAULT '0' COMMENT 'ÔÚÏß½±Àø',
  `days` int(11) DEFAULT '0' COMMENT 'ÌìÊý',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310857 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_vip
-- ----------------------------
INSERT INTO `t_human_vip` VALUES ('6390530967493837826', '1702', '0', '0', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_vip` VALUES ('6391488522273588226', '1704', '0', '0', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_vip` VALUES ('6391489703884522500', '1705', '0', '0', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_vip` VALUES ('6391833090110161922', '1706', '0', '0', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_vip` VALUES ('6395172516739580930', '1707', '0', '0', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_vip` VALUES ('6395174902690382852', '1708', '0', '0', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_vip` VALUES ('6395175479071638534', '10001', '0', '0', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_vip` VALUES ('6395175639839310856', '10002', '0', '0', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_vip_new`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_vip_new`;
CREATE TABLE `t_human_vip_new` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `humanId` bigint(20) NOT NULL COMMENT '角色ID',
  `vipLevel` int(11) DEFAULT NULL COMMENT 'vip等级',
  `curPoint` int(11) DEFAULT NULL COMMENT '当前vip点',
  `updateTime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `createTime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310858 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_vip_new
-- ----------------------------
INSERT INTO `t_human_vip_new` VALUES ('6390530967493837827', '1702', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_vip_new` VALUES ('6391488522273588227', '1704', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_vip_new` VALUES ('6391489703884522501', '1705', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_vip_new` VALUES ('6391833090110161923', '1706', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_vip_new` VALUES ('6395172516739580931', '1707', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_vip_new` VALUES ('6395174902690382853', '1708', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_vip_new` VALUES ('6395175479071638535', '10001', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_vip_new` VALUES ('6395175639839310857', '10002', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_week_card`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_week_card`;
CREATE TABLE `t_human_week_card` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Íæ¼Ò½ÇÉ«ID',
  `beginTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¿ªÊ¼Ê±¼ä',
  `getTime` bigint(20) NOT NULL DEFAULT '0' COMMENT 'ÁìÈ¡Ê±¼ä',
  `duration` bigint(20) NOT NULL DEFAULT '0' COMMENT '³ÖÐøÊ±¼ä',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_week_card
-- ----------------------------
INSERT INTO `t_human_week_card` VALUES ('6390530967493837826', '1702', '0', '0', '0', '1523621312974', '1523621312974');
INSERT INTO `t_human_week_card` VALUES ('6391488522273588226', '1704', '0', '0', '0', '1523849611824', '1523849611824');
INSERT INTO `t_human_week_card` VALUES ('6391489703884522499', '1705', '0', '0', '0', '1523849893542', '1523849893542');
INSERT INTO `t_human_week_card` VALUES ('6391833090110161922', '1706', '0', '0', '0', '1523931763198', '1523931763198');
INSERT INTO `t_human_week_card` VALUES ('6395172516739580930', '1707', '0', '0', '0', '1524727944550', '1524727944550');
INSERT INTO `t_human_week_card` VALUES ('6395174902690382851', '1708', '0', '0', '0', '1524728513405', '1524728513405');
INSERT INTO `t_human_week_card` VALUES ('6395175479071638532', '10001', '0', '0', '0', '1524728650825', '1524728650825');
INSERT INTO `t_human_week_card` VALUES ('6395175639839310853', '10002', '0', '0', '0', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_human_week_sign_in`
-- ----------------------------
DROP TABLE IF EXISTS `t_human_week_sign_in`;
CREATE TABLE `t_human_week_sign_in` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL COMMENT '½ÇÉ«id',
  `signInPack` varchar(50) DEFAULT NULL COMMENT 'Ç©µ½ÐÅÏ¢',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6395175639839310854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_human_week_sign_in
-- ----------------------------
INSERT INTO `t_human_week_sign_in` VALUES ('6390530967493837826', '1702', '[]', '1523621312974', '1523621312974');
INSERT INTO `t_human_week_sign_in` VALUES ('6391488522273588226', '1704', '[]', '1523849611824', '1523849611824');
INSERT INTO `t_human_week_sign_in` VALUES ('6391489703884522499', '1705', '[]', '1523849893542', '1523849893542');
INSERT INTO `t_human_week_sign_in` VALUES ('6391833090110161922', '1706', '[]', '1523931763198', '1523931763198');
INSERT INTO `t_human_week_sign_in` VALUES ('6395172516739580930', '1707', '[]', '1524727944550', '1524727944550');
INSERT INTO `t_human_week_sign_in` VALUES ('6395174902690382851', '1708', '[]', '1524728513405', '1524728513405');
INSERT INTO `t_human_week_sign_in` VALUES ('6395175479071638532', '10001', '[]', '1524728650825', '1524728650825');
INSERT INTO `t_human_week_sign_in` VALUES ('6395175639839310853', '10002', '[]', '1524728689155', '1524728689155');

-- ----------------------------
-- Table structure for `t_index_notice`
-- ----------------------------
DROP TABLE IF EXISTS `t_index_notice`;
CREATE TABLE `t_index_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `cn` varchar(5000) NOT NULL COMMENT 'cn',
  `en` varchar(5000) NOT NULL COMMENT 'en',
  `tw` varchar(5000) NOT NULL COMMENT 'tw',
  `open` int(11) NOT NULL COMMENT '开启',
  `updateTime` bigint(20) NOT NULL COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_index_notice
-- ----------------------------
INSERT INTO `t_index_notice` VALUES ('1', '1', '1', '1', '0', '1', '1');

-- ----------------------------
-- Table structure for `t_mail_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_mail_info`;
CREATE TABLE `t_mail_info` (
  `id` bigint(20) NOT NULL COMMENT 'Ö÷¼ü',
  `charId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Íæ¼Ò½ÇÉ«ID',
  `sendId` bigint(20) NOT NULL DEFAULT '0' COMMENT 'ºÃÓÑid',
  `sendName` varchar(50) NOT NULL COMMENT '·¢ËÍÕßÐÕÃû',
  `recId` bigint(20) NOT NULL DEFAULT '0' COMMENT '½ÓÊÕÕßid',
  `recName` varchar(50) NOT NULL COMMENT '½ÓÊÕÕßÐÕÃû',
  `title` varchar(50) NOT NULL COMMENT '±êÌâ',
  `content` varchar(1000) NOT NULL COMMENT 'ÄÚÈÝ',
  `mailType` int(11) NOT NULL DEFAULT '0' COMMENT 'ÓÊ¼þÀàÐÍ',
  `mailStatus` int(11) NOT NULL DEFAULT '0' COMMENT 'ÓÊ¼þ×´Ì¬',
  `hasAttachment` int(11) NOT NULL DEFAULT '0' COMMENT '¸½¼þ',
  `attachmentPack` varchar(2000) DEFAULT NULL COMMENT '¸½¼þÄÚÈÝ',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `deleted` tinyint(1) DEFAULT NULL COMMENT '删除标志位 0 未删除，1 已删除',
  `head` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `charId` (`charId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_mail_info
-- ----------------------------
INSERT INTO `t_mail_info` VALUES ('6391488524802753538', '1702', '1704', '1704', '1702', '', '', 'haohaoho', '4', '2', '1', '[{\"giftNewId\":8,\"rewardCount\":980000,\"rewardId\":3,\"vippoint\":0}]', '1523849841495', '1523849612427', '1', 'head_9');
INSERT INTO `t_mail_info` VALUES ('6391489705566438403', '1702', '1705', '1705', '1702', '', '', 'haohaoho', '4', '2', '1', '[{\"giftNewId\":8,\"rewardCount\":980000,\"rewardId\":3,\"vippoint\":0}]', '1523849914199', '1523849893943', '1', 'head_8');
INSERT INTO `t_mail_info` VALUES ('6391489923510862852', '1705', '1702', '1702', '1705', '', '', '', '4', '0', '1', '[{\"giftNewId\":1,\"rewardCount\":8820000,\"rewardId\":3,\"vippoint\":0}]', '1523849979996', '1523849945905', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391535153526244354', '1705', '1702', '1702', '1705', '', '', '', '4', '0', '1', '[{\"giftNewId\":1,\"rewardCount\":8820000,\"rewardId\":3,\"vippoint\":0}]', '1523861177791', '1523860729581', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391537766699271170', '1705', '1702', '1702', '1705', '', '', '', '4', '0', '1', '[{\"giftNewId\":8,\"rewardCount\":1960000,\"rewardId\":3,\"vippoint\":0}]', '1523861955650', '1523861352610', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391538221802226691', '1704', '1702', '1702', '1704', '', '', '', '4', '0', '1', '[{\"giftNewId\":8,\"rewardCount\":1960000,\"rewardId\":3,\"vippoint\":0}]', '1523861954245', '1523861461115', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391538526371611652', '1704', '1702', '1702', '1704', '', '', '', '4', '0', '1', '[{\"giftNewId\":8,\"rewardCount\":1960000,\"rewardId\":3,\"vippoint\":0}]', '1523861894171', '1523861533730', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391540933537203202', '1705', '1702', '1702', '1705', '', '', '', '4', '0', '1', '[{\"giftNewId\":1,\"rewardCount\":8820000,\"rewardId\":3,\"vippoint\":0}]', '1523862136723', '1523862107643', '1', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6391543089640145923', '1705', '1702', '1702', '1705', '', '', '', '4', '0', '1', '[{\"giftNewId\":1,\"rewardCount\":8820000,\"rewardId\":3,\"vippoint\":0}]', '0', '1523862621698', '0', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6395166334738138114', '1706', '1702', '1702', '1706', '1706', '', '', '4', '0', '1', '[{\"giftNewId\":1,\"rewardCount\":147000,\"rewardId\":3,\"vippoint\":0}]', '0', '1524726470646', '0', 'head_3.png');
INSERT INTO `t_mail_info` VALUES ('6395166783126012931', '1706', '1702', '1702', '1706', '1706', '', '', '4', '0', '1', '[{\"giftNewId\":2,\"rewardCount\":196000,\"rewardId\":3,\"vippoint\":0}]', '0', '1524726577550', '0', 'head_3.png');

-- ----------------------------
-- Table structure for `t_notice`
-- ----------------------------
DROP TABLE IF EXISTS `t_notice`;
CREATE TABLE `t_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Ö÷¼ü',
  `startTime` bigint(20) DEFAULT '0' COMMENT '¿ªÊ¼Ê±¼ä',
  `endTime` bigint(20) DEFAULT '0' COMMENT '½áÊøÊ±¼ä',
  `dailyStartTime` int(11) DEFAULT '0' COMMENT 'Ã¿Ìì¿ªÊ¼Ê±¼ä',
  `dailyEndTime` int(11) DEFAULT '0' COMMENT 'Ã¿Ìì½áÊøÊ±¼ä',
  `intervalTime` int(11) DEFAULT '0' COMMENT '¼ä¸ôÊ±¼ä',
  `content` varchar(255) DEFAULT NULL COMMENT 'ÄÚÈÝ',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '¸üÐÂÊ±¼ä',
  `createTime` bigint(20) DEFAULT '0' COMMENT '´´½¨Ê±¼ä',
  `isDelete` tinyint(1) DEFAULT '0' COMMENT '是否删除，0：未删除     1：已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_notice
-- ----------------------------

-- ----------------------------
-- Table structure for `t_online_time_number`
-- ----------------------------
DROP TABLE IF EXISTS `t_online_time_number`;
CREATE TABLE `t_online_time_number` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用于记录图形化数据，每个时间点的在线人数',
  `area` varchar(128) DEFAULT NULL COMMENT '地区（那个国家或者 哪个区域）',
  `time` datetime NOT NULL COMMENT '插入时间',
  `number` int(11) NOT NULL COMMENT '插入时间点的在线人数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_online_time_number
-- ----------------------------

-- ----------------------------
-- Table structure for `t_rank`
-- ----------------------------
DROP TABLE IF EXISTS `t_rank`;
CREATE TABLE `t_rank` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `charId` bigint(20) NOT NULL COMMENT '角色ID',
  `daySingleJackpot` bigint(20) DEFAULT NULL COMMENT '今日单居最大赢取彩金',
  `dayTotalJackpot` bigint(20) DEFAULT NULL COMMENT '今日总的累计彩金',
  `singleJackpot` bigint(20) DEFAULT NULL COMMENT '注册到现在最大的彩金',
  `totalJackpot` bigint(20) DEFAULT NULL COMMENT '注册到现在累计彩金',
  `viplevel` int(11) DEFAULT NULL COMMENT 'vip等级',
  `updateTime` bigint(20) NOT NULL,
  `createTime` bigint(20) DEFAULT NULL,
  `scoreList` varchar(255) DEFAULT '' COMMENT '已经领取ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_rank
-- ----------------------------

-- ----------------------------
-- Table structure for `t_recharge`
-- ----------------------------
DROP TABLE IF EXISTS `t_recharge`;
CREATE TABLE `t_recharge` (
  `id` int(11) NOT NULL DEFAULT '0',
  `channelId` int(11) DEFAULT NULL COMMENT '渠道ID',
  `pid` int(11) DEFAULT NULL,
  `nameId` int(11) DEFAULT NULL,
  `descrip` int(11) DEFAULT NULL,
  `langDesc` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `itemNum` int(11) DEFAULT NULL,
  `giftNum` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL COMMENT '产品ID',
  `used` tinyint(1) DEFAULT NULL COMMENT '是否使用，1：是，0：否',
  `mark` int(11) DEFAULT NULL COMMENT '显示标签：0：没有，1：best value，2：most popular',
  `itemId` int(11) DEFAULT NULL COMMENT '对应物品表的ID',
  `smallCategory` int(11) DEFAULT NULL COMMENT '小类：1、筹码2、周卡3、月卡4、门票5、改名卡 6、付费转盘,7、翻倍转盘8、奖券9、俱乐部礼包10、金库（小金猪）11、新手礼包',
  `vipPoint` int(11) DEFAULT NULL COMMENT '购买获得的vip点数',
  `category` int(5) DEFAULT NULL COMMENT '类别：1、筹码；2:物品3、礼包 4、功能性付费',
  `payType` int(11) DEFAULT NULL COMMENT '支付方式：0：其他 1：mycard，2：Mol',
  `itemType` int(11) DEFAULT NULL COMMENT '0.无分页 1.金币 2.道具 3.奖券',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_recharge
-- ----------------------------

-- ----------------------------
-- Table structure for `t_robot_complement`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_complement`;
CREATE TABLE `t_robot_complement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '资源版本',
  `robotId` bigint(20) NOT NULL COMMENT '版本号',
  `complement` bigint(20) NOT NULL COMMENT '补签数',
  `updateTime` bigint(20) NOT NULL COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_complement
-- ----------------------------

-- ----------------------------
-- Table structure for `t_robot_statis_data`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_statis_data`;
CREATE TABLE `t_robot_statis_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slotName` varchar(64) DEFAULT NULL COMMENT '老虎机名称',
  `slotId` bigint(20) DEFAULT NULL,
  `slotType` bigint(20) DEFAULT NULL COMMENT '老虎机类型',
  `chartId` bigint(20) DEFAULT NULL,
  `rewardCount` bigint(20) DEFAULT NULL COMMENT '赢取次数：在转动中赢得筹码的次数',
  `rewardUsed` bigint(20) DEFAULT NULL COMMENT '消耗筹码数：所有转动结束后所消耗的筹码',
  `payCount` bigint(20) DEFAULT NULL COMMENT '支付线筹码数：支付线中奖获得的筹码数量',
  `scatterNum` bigint(20) DEFAULT NULL COMMENT 'Scatter筹码数：中scatter游戏获得的筹码数量；',
  `bonusNum` bigint(20) DEFAULT NULL COMMENT 'Bonus筹码数：中bonus游戏获得的筹码数量；',
  `scatterTriggerCount` bigint(20) DEFAULT NULL COMMENT '付费 --- scatter的次数：scatter游戏触发的次数；',
  `scatterTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT '免费  -- scatter的次数：scatter游戏触发的次数；',
  `bonusTriggerCount` bigint(20) DEFAULT NULL COMMENT 'bonus的次数：bonus游戏触发的次数',
  `bonusTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT 'bonus免费触发的次数',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_statis_data
-- ----------------------------

-- ----------------------------
-- Table structure for `t_robot_statis_data_20170630`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_statis_data_20170630`;
CREATE TABLE `t_robot_statis_data_20170630` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slotName` varchar(64) DEFAULT NULL COMMENT '老虎机名称',
  `slotId` bigint(20) DEFAULT NULL,
  `slotType` bigint(20) DEFAULT NULL COMMENT '老虎机类型',
  `chartId` bigint(20) DEFAULT NULL,
  `rewardCount` bigint(20) DEFAULT NULL COMMENT '赢取次数：在转动中赢得筹码的次数',
  `rewardUsed` bigint(20) DEFAULT NULL COMMENT '消耗筹码数：所有转动结束后所消耗的筹码',
  `payCount` bigint(20) DEFAULT NULL COMMENT '支付线筹码数：支付线中奖获得的筹码数量',
  `scatterNum` bigint(20) DEFAULT NULL COMMENT 'Scatter筹码数：中scatter游戏获得的筹码数量；',
  `bonusNum` bigint(20) DEFAULT NULL COMMENT 'Bonus筹码数：中bonus游戏获得的筹码数量；',
  `scatterTriggerCount` bigint(20) DEFAULT NULL COMMENT '付费 --- scatter的次数：scatter游戏触发的次数；',
  `scatterTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT '免费  -- scatter的次数：scatter游戏触发的次数；',
  `bonusTriggerCount` bigint(20) DEFAULT NULL COMMENT 'bonus的次数：bonus游戏触发的次数',
  `bonusTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT 'bonus免费触发的次数',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_statis_data_20170630
-- ----------------------------

-- ----------------------------
-- Table structure for `t_robot_statis_data_20170707`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_statis_data_20170707`;
CREATE TABLE `t_robot_statis_data_20170707` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slotName` varchar(64) DEFAULT NULL COMMENT '老虎机名称',
  `slotId` bigint(20) DEFAULT NULL,
  `slotType` bigint(20) DEFAULT NULL COMMENT '老虎机类型',
  `chartId` bigint(20) DEFAULT NULL,
  `rewardCount` bigint(20) DEFAULT NULL COMMENT '赢取次数：在转动中赢得筹码的次数',
  `rewardUsed` bigint(20) DEFAULT NULL COMMENT '消耗筹码数：所有转动结束后所消耗的筹码',
  `payCount` bigint(20) DEFAULT NULL COMMENT '支付线筹码数：支付线中奖获得的筹码数量',
  `scatterNum` bigint(20) DEFAULT NULL COMMENT 'Scatter筹码数：中scatter游戏获得的筹码数量；',
  `bonusNum` bigint(20) DEFAULT NULL COMMENT 'Bonus筹码数：中bonus游戏获得的筹码数量；',
  `scatterTriggerCount` bigint(20) DEFAULT NULL COMMENT '付费 --- scatter的次数：scatter游戏触发的次数；',
  `scatterTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT '免费  -- scatter的次数：scatter游戏触发的次数；',
  `bonusTriggerCount` bigint(20) DEFAULT NULL COMMENT 'bonus的次数：bonus游戏触发的次数',
  `bonusTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT 'bonus免费触发的次数',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_statis_data_20170707
-- ----------------------------

-- ----------------------------
-- Table structure for `t_robot_statis_data_copy`
-- ----------------------------
DROP TABLE IF EXISTS `t_robot_statis_data_copy`;
CREATE TABLE `t_robot_statis_data_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slotId` bigint(20) DEFAULT NULL,
  `chartId` bigint(20) DEFAULT NULL,
  `rewardCount` bigint(20) DEFAULT NULL COMMENT '赢取次数：在转动中赢得筹码的次数',
  `rewardUsed` bigint(20) DEFAULT NULL COMMENT '消耗筹码数：所有转动结束后所消耗的筹码',
  `payCount` bigint(20) DEFAULT NULL COMMENT '支付线筹码数：支付线中奖获得的筹码数量',
  `scatterNum` bigint(20) DEFAULT NULL COMMENT 'Scatter筹码数：中scatter游戏获得的筹码数量；',
  `bonusNum` bigint(20) DEFAULT NULL COMMENT 'Bonus筹码数：中bonus游戏获得的筹码数量；',
  `scatterTriggerCount` bigint(20) DEFAULT NULL COMMENT '付费 --- scatter的次数：scatter游戏触发的次数；',
  `scatterTriggerFreeCount` bigint(20) DEFAULT NULL COMMENT '免费  -- scatter的次数：scatter游戏触发的次数；',
  `bonusTriggerCount` bigint(20) DEFAULT NULL COMMENT 'bonus的次数：bonus游戏触发的次数',
  `createTime` datetime DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_robot_statis_data_copy
-- ----------------------------

-- ----------------------------
-- Table structure for `t_slot`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot`;
CREATE TABLE `t_slot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `slotType` int(11) NOT NULL DEFAULT '0' COMMENT '老虎机类型',
  `jackpot` bigint(20) NOT NULL DEFAULT '0' COMMENT '彩金',
  `stock` bigint(20) NOT NULL DEFAULT '0' COMMENT '库存',
  `spinTimes` bigint(20) NOT NULL DEFAULT '0' COMMENT '次数',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `cumuJackpot` bigint(20) NOT NULL DEFAULT '0' COMMENT '累计彩金池',
  `slotType23Jackpot` text,
  `jackpot1` bigint(20) DEFAULT '0',
  `jackpot2` bigint(20) DEFAULT '0',
  `jackpot3` bigint(20) DEFAULT '0',
  `jackpot4` bigint(20) DEFAULT '0',
  `jackpot5` bigint(20) DEFAULT '0',
  `cumuJackpot1` bigint(20) DEFAULT '0',
  `cumuJackpot2` bigint(20) DEFAULT '0',
  `cumuJackpot3` bigint(20) DEFAULT '0',
  `cumuJackpot4` bigint(20) DEFAULT '0',
  `cumuJackpot5` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6390527936970785918 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot
-- ----------------------------
INSERT INTO `t_slot` VALUES ('6390527936970785794', '1', '1000000', '0', '0', '1524726323592', '1523620590441', '0', null, '2000000', '4000000', '8000000', '16000000', '32000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785795', '2', '2000000', '0', '0', '1524726323592', '1523620590441', '0', null, '4000000', '8000000', '16000000', '32000000', '64000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785796', '3', '4000000', '0', '0', '1524726323592', '1523620590441', '0', null, '8000000', '16000000', '32000000', '64000000', '128000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785797', '4', '8000000', '0', '0', '1524726323592', '1523620590441', '0', null, '16000000', '32000000', '64000000', '128000000', '256000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785798', '5', '10000070', '6150', '10', '1524726323592', '1523620590441', '30', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785799', '6', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785800', '7', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785801', '8', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785802', '9', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785803', '10', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785804', '11', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785805', '12', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785806', '13', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785807', '14', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785808', '15', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785809', '16', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785810', '17', '10000080', '6600', '8', '1524726323592', '1523620590441', '32', '60=6010,12010,30010,300016,600024;120=12000,24000,60000,600000,1200000;240=24000,48000,120000,1200000,2400000;360=36000,72000,180000,1800000,3600000;480=48000,96000,240000,2400000,4800000', '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785811', '18', '20000000', '0', '0', '1524726323592', '1523620590441', '0', '600=60000,120000,300000,3000000,6000000;1200=120000,240000,600000,6000000,12000000;2400=240000,480000,1200000,12000000,24000000;3600=360000,720000,1800000,18000000,36000000;4800=480000,960000,2400000,24000000,48000000', '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785812', '19', '30000000', '0', '0', '1524726323592', '1523620590441', '0', '6000=600000,1200000,3000000,30000000,60000000;12000=1200000,2400000,6000000,60000000,120000000;24000=2400000,4800000,12000000,120000000,240000000;36000=3600000,7200000,18000000,180000000,360000000;48000=4800000,9600000,24000000,240000000,480000000', '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785813', '20', '50000000', '0', '0', '1524726323592', '1523620590441', '0', '60000=6000000,12000000,30000000,300000000,600000000;120000=12000000,24000000,60000000,600000000,1200000000;240000=24000000,48000000,120000000,1200000000,2400000000;360000=36000000,72000000,180000000,1800000000,3600000000;480000=48000000,96000000,240000000,2400000000,4800000000', '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785814', '21', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785815', '22', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785816', '23', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785817', '24', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785818', '25', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785819', '26', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785820', '27', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785821', '28', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785822', '29', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785823', '30', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785824', '31', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785825', '32', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785826', '33', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785827', '34', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785828', '35', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785829', '36', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785830', '37', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785831', '38', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785832', '39', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785833', '40', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785834', '41', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785835', '42', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785836', '43', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785837', '44', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785838', '45', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785839', '46', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785840', '47', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785841', '48', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785842', '49', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785843', '50', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785844', '51', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785845', '52', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785846', '53', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785847', '54', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785848', '55', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785849', '56', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785850', '57', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785851', '58', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785852', '59', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785853', '60', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785854', '61', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785855', '62', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785856', '63', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785857', '64', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785858', '65', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785859', '66', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785860', '67', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785861', '68', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785862', '69', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785863', '70', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785864', '71', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785865', '72', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785866', '73', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785867', '74', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785868', '75', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785869', '76', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785870', '77', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785871', '78', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785872', '79', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785873', '80', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785874', '81', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785875', '82', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785876', '83', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785877', '84', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785878', '85', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785879', '86', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785880', '87', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785881', '88', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785882', '89', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785883', '90', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785884', '91', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785885', '92', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785886', '93', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785887', '94', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785888', '95', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785889', '96', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785890', '97', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785891', '98', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785892', '99', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785893', '100', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785894', '101', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785895', '102', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785896', '103', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785897', '104', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785898', '105', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785899', '106', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785900', '107', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785901', '108', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785902', '109', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785903', '110', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785904', '111', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785905', '112', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785906', '113', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785907', '114', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785908', '115', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785909', '116', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785910', '117', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785911', '118', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785912', '119', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785913', '120', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785914', '121', '10000000', '0', '0', '1524726323592', '1523620590441', '0', null, '10000000', '10000000', '10000000', '10000000', '10000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785915', '122', '20000000', '0', '0', '1524726323592', '1523620590441', '0', null, '20000000', '20000000', '20000000', '20000000', '20000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785916', '123', '30000000', '0', '0', '1524726323592', '1523620590441', '0', null, '30000000', '30000000', '30000000', '30000000', '30000000', '0', '0', '0', '0', '0');
INSERT INTO `t_slot` VALUES ('6390527936970785917', '124', '50000000', '0', '0', '1524726323592', '1523620590441', '0', null, '50000000', '50000000', '50000000', '50000000', '50000000', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `t_slot_20170606`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot_20170606`;
CREATE TABLE `t_slot_20170606` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `slotType` int(11) NOT NULL DEFAULT '0' COMMENT '老虎机类型',
  `jackpot` bigint(20) NOT NULL DEFAULT '0' COMMENT '彩金',
  `stock` bigint(20) NOT NULL DEFAULT '0' COMMENT '库存',
  `spinTimes` bigint(20) NOT NULL DEFAULT '0' COMMENT '次数',
  `updateTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `cumuJackpot` bigint(20) NOT NULL DEFAULT '0' COMMENT '累计彩金池',
  `slotType23Jackpot` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot_20170606
-- ----------------------------

-- ----------------------------
-- Table structure for `t_slot_list`
-- ----------------------------
DROP TABLE IF EXISTS `t_slot_list`;
CREATE TABLE `t_slot_list` (
  `id` bigint(20) NOT NULL,
  `langDesc` varchar(120) DEFAULT NULL COMMENT '老虎机名称',
  `payLinesNum` int(3) DEFAULT NULL,
  `bet1` int(11) DEFAULT NULL,
  `bet2` int(11) DEFAULT NULL,
  `bet3` int(11) DEFAULT NULL,
  `bet4` int(11) DEFAULT NULL,
  `bet5` int(11) DEFAULT NULL,
  `type` int(3) DEFAULT NULL COMMENT '老虎机编号',
  `bet1Lv` int(6) DEFAULT NULL,
  `bet2Lv` int(6) DEFAULT NULL,
  `bet3Lv` int(6) DEFAULT NULL,
  `bet4Lv` int(6) DEFAULT NULL,
  `bet5Lv` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_slot_list
-- ----------------------------
INSERT INTO `t_slot_list` VALUES ('1', 'Classic', '20', '50', '100', '200', '300', '400', '1', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('2', 'Classic', '20', '500', '1000', '2000', '3000', '4000', '1', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('3', 'Classic', '20', '5000', '10000', '20000', '30000', '40000', '1', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('4', 'Classic', '20', '50000', '100000', '200000', '300000', '400000', '1', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('5', '宙斯', '40', '25', '50', '100', '150', '200', '13', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('6', '宙斯', '40', '250', '500', '1000', '1500', '2000', '13', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('7', '宙斯', '40', '2500', '5000', '10000', '15000', '20000', '13', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('8', '宙斯', '40', '25000', '50000', '100000', '150000', '200000', '13', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('9', '犀牛', '25', '60', '120', '240', '360', '480', '27', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('10', '犀牛', '25', '600', '1200', '2400', '3600', '4800', '27', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('11', '犀牛', '25', '6000', '12000', '24000', '36000', '48000', '27', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('12', '犀牛', '25', '60000', '120000', '240000', '360000', '480000', '27', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('13', '狮身人面像', '40', '40', '80', '160', '240', '320', '15', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('14', '狮身人面像', '40', '400', '800', '1600', '2400', '3200', '15', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('15', '狮身人面像', '40', '4000', '8000', '16000', '24000', '32000', '15', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('16', '狮身人面像', '40', '40000', '80000', '160000', '240000', '320000', '15', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('17', '东方龙', '25', '60', '120', '240', '360', '480', '23', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('18', '东方龙', '25', '600', '1200', '2400', '3600', '4800', '23', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('19', '东方龙', '25', '6000', '12000', '24000', '36000', '48000', '23', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('20', '东方龙', '25', '60000', '120000', '240000', '360000', '480000', '23', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('21', '福尔摩斯', '25', '60', '120', '240', '360', '480', '30', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('22', '福尔摩斯', '25', '600', '1200', '2400', '3600', '4800', '30', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('23', '福尔摩斯', '25', '6000', '12000', '24000', '36000', '48000', '30', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('24', '福尔摩斯', '25', '60000', '120000', '240000', '360000', '480000', '30', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('25', '斯巴达', '25', '60', '120', '240', '360', '480', '32', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('26', '斯巴达', '25', '600', '1200', '2400', '3600', '4800', '32', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('27', '斯巴达', '25', '6000', '12000', '24000', '36000', '48000', '32', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('28', '斯巴达', '25', '60000', '120000', '240000', '360000', '480000', '32', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('29', '女巫魔法', '40', '40', '80', '160', '240', '320', '26', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('30', '女巫魔法', '40', '400', '800', '1600', '2400', '3200', '26', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('31', '女巫魔法', '40', '4000', '8000', '16000', '24000', '32000', '26', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('32', '女巫魔法', '40', '40000', '80000', '160000', '240000', '320000', '26', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('33', '西方龙', '40', '40', '80', '160', '240', '320', '29', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('34', '西方龙', '40', '400', '800', '1600', '2400', '3200', '29', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('35', '西方龙', '40', '4000', '8000', '16000', '24000', '32000', '29', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('36', '西方龙', '40', '40000', '80000', '160000', '240000', '320000', '29', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('37', '阿兹特克', '30', '60', '120', '240', '360', '480', '16', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('38', '阿兹特克', '30', '600', '1200', '2400', '3600', '4800', '16', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('39', '阿兹特克', '30', '6000', '12000', '24000', '36000', '48000', '16', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('40', '阿兹特克', '30', '60000', '120000', '240000', '360000', '480000', '16', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('41', '动物虎', '40', '50', '100', '200', '300', '400', '21', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('42', '动物虎', '40', '500', '1000', '2000', '3000', '4000', '21', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('43', '动物虎', '40', '5000', '10000', '20000', '30000', '40000', '21', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('44', '动物虎', '40', '50000', '100000', '200000', '300000', '400000', '21', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('45', '水果', '40', '50', '100', '200', '300', '400', '3', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('46', '水果', '40', '500', '1000', '2000', '3000', '4000', '3', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('47', '水果', '40', '5000', '10000', '20000', '30000', '40000', '3', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('48', '水果', '40', '50000', '100000', '200000', '300000', '400000', '3', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('49', '忍者', '25', '80', '160', '320', '480', '640', '25', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('50', '忍者', '25', '800', '1600', '3200', '4800', '6400', '25', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('51', '忍者', '25', '8000', '16000', '32000', '48000', '64000', '25', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('52', '忍者', '25', '80000', '160000', '320000', '480000', '640000', '25', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('53', '海盗', '40', '50', '100', '200', '300', '400', '31', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('54', '海盗', '40', '500', '1000', '2000', '3000', '4000', '31', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('55', '海盗', '40', '5000', '10000', '20000', '30000', '40000', '31', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('56', '海盗', '40', '50000', '100000', '200000', '300000', '400000', '31', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('57', '维密', '25', '80', '160', '320', '480', '640', '12', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('58', '维密', '25', '800', '1600', '3200', '4800', '6400', '12', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('59', '维密', '25', '8000', '16000', '32000', '48000', '64000', '12', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('60', '维密', '25', '80000', '160000', '320000', '480000', '640000', '12', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('61', '西部牛仔', '40', '50', '100', '200', '300', '400', '22', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('62', '西部牛仔', '40', '500', '1000', '2000', '3000', '4000', '22', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('63', '西部牛仔', '40', '5000', '10000', '20000', '30000', '40000', '22', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('64', '西部牛仔', '40', '50000', '100000', '200000', '300000', '400000', '22', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('65', '日月潭', '20', '110', '220', '440', '660', '880', '11', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('66', '日月潭', '20', '1100', '2200', '4400', '6600', '8800', '11', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('67', '日月潭', '20', '11000', '22000', '44000', '66000', '88000', '11', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('68', '日月潭', '20', '110000', '220000', '440000', '660000', '880000', '11', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('69', '动物狼', '25', '80', '160', '320', '480', '640', '17', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('70', '动物狼', '25', '800', '1600', '3200', '4800', '6400', '17', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('71', '动物狼', '25', '8000', '16000', '32000', '48000', '64000', '17', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('72', '动物狼', '25', '80000', '160000', '320000', '480000', '640000', '17', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('73', '水晶魔法宝石', '40', '50', '100', '200', '300', '400', '19', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('74', '水晶魔法宝石', '40', '500', '1000', '2000', '3000', '4000', '19', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('75', '水晶魔法宝石', '40', '5000', '10000', '20000', '30000', '40000', '19', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('76', '水晶魔法宝石', '40', '50000', '100000', '200000', '300000', '400000', '19', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('77', '沙滩', '40', '50', '100', '200', '300', '400', '4', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('78', '沙滩', '40', '500', '1000', '2000', '3000', '4000', '4', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('79', '沙滩', '40', '5000', '10000', '20000', '30000', '40000', '4', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('80', '沙滩', '40', '50000', '100000', '200000', '300000', '400000', '4', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('81', '澳门女神', '25', '80', '160', '320', '480', '640', '8', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('82', '澳门女神', '25', '800', '1600', '3200', '4800', '6400', '8', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('83', '澳门女神', '25', '8000', '16000', '32000', '48000', '64000', '8', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('84', '澳门女神', '25', '80000', '160000', '320000', '480000', '640000', '8', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('85', '泰国象', '40', '50', '100', '200', '300', '400', '20', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('86', '泰国象', '40', '500', '1000', '2000', '3000', '4000', '20', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('87', '泰国象', '40', '5000', '10000', '20000', '30000', '40000', '20', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('88', '泰国象', '40', '50000', '100000', '200000', '300000', '400000', '20', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('89', '吸血鬼', '25', '80', '160', '320', '480', '640', '5', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('90', '吸血鬼', '25', '800', '1600', '3200', '4800', '6400', '5', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('91', '吸血鬼', '25', '8000', '16000', '32000', '48000', '64000', '5', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('92', '吸血鬼', '25', '80000', '160000', '320000', '480000', '640000', '5', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('93', '马来网红', '40', '50', '100', '200', '300', '400', '10', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('94', '马来网红', '40', '500', '1000', '2000', '3000', '4000', '10', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('95', '马来网红', '40', '5000', '10000', '20000', '30000', '40000', '10', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('96', '马来网红', '40', '50000', '100000', '200000', '300000', '400000', '10', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('97', '埃及艳后', '25', '80', '160', '320', '480', '640', '6', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('98', '埃及艳后', '25', '800', '1600', '3200', '4800', '6400', '6', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('99', '埃及艳后', '25', '8000', '16000', '32000', '48000', '64000', '6', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('100', '埃及艳后', '25', '80000', '160000', '320000', '480000', '640000', '6', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('101', '巴西风情', '40', '50', '100', '200', '300', '400', '24', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('102', '巴西风情', '40', '500', '1000', '2000', '3000', '4000', '24', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('103', '巴西风情', '40', '5000', '10000', '20000', '30000', '40000', '24', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('104', '巴西风情', '40', '50000', '100000', '200000', '300000', '400000', '24', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('105', '美人鱼', '20', '100', '200', '400', '600', '800', '7', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('106', '美人鱼', '20', '1000', '2000', '4000', '6000', '8000', '7', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('107', '美人鱼', '20', '10000', '20000', '40000', '60000', '80000', '7', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('108', '美人鱼', '20', '100000', '200000', '400000', '600000', '800000', '7', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('109', '石器时代', '25', '80', '160', '320', '480', '640', '14', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('110', '石器时代', '25', '800', '1600', '3200', '4800', '6400', '14', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('111', '石器时代', '25', '8000', '16000', '32000', '48000', '64000', '14', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('112', '石器时代', '25', '80000', '160000', '320000', '480000', '640000', '14', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('113', '海洋世界', '25', '80', '160', '320', '480', '640', '28', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('114', '海洋世界', '25', '800', '1600', '3200', '4800', '6400', '28', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('115', '海洋世界', '25', '8000', '16000', '32000', '48000', '64000', '28', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('116', '海洋世界', '25', '80000', '160000', '320000', '480000', '640000', '28', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('117', '小红帽', '40', '40', '80', '160', '320', '640', '33', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('118', '小红帽', '40', '200', '400', '800', '1600', '3200', '33', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('119', '小红帽', '40', '1000', '2000', '4000', '8000', '16000', '33', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('120', '小红帽', '40', '5000', '10000', '20000', '40000', '80000', '33', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('121', '万圣节', '40', '400', '800', '1600', '2400', '3200', '38', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('122', '万圣节', '40', '4000', '8000', '16000', '24000', '32000', '38', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('123', '万圣节', '40', '40000', '80000', '160000', '240000', '320000', '38', '1', '1', '1', '1', '1');
INSERT INTO `t_slot_list` VALUES ('124', '万圣节', '40', '400000', '800000', '1600000', '2400000', '3200000', '38', '1', '1', '1', '1', '1');

-- ----------------------------
-- Table structure for `t_textas`
-- ----------------------------
DROP TABLE IF EXISTS `t_textas`;
CREATE TABLE `t_textas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `texasId` int(11) DEFAULT '0' COMMENT '德州房间ID',
  `jackpot` bigint(20) DEFAULT '0' COMMENT '彩金池',
  `cumuJackpot` bigint(20) DEFAULT '0' COMMENT '累计彩金池',
  `updateTime` bigint(20) DEFAULT '0' COMMENT '更新时间',
  `createTime` bigint(20) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6390527936970785798 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_textas
-- ----------------------------
INSERT INTO `t_textas` VALUES ('6390527936970785794', '10000', '10000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_textas` VALUES ('6390527936970785795', '10001', '20000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_textas` VALUES ('6390527936970785796', '10002', '30000000', '0', '1523620590441', '1523620590441');
INSERT INTO `t_textas` VALUES ('6390527936970785797', '10003', '50000000', '0', '1523620590441', '1523620590441');

-- ----------------------------
-- Table structure for `t_user_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_info`;
CREATE TABLE `t_user_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '登陆标识',
  `name` varchar(100) NOT NULL COMMENT '用户名',
  `username` varchar(100) DEFAULT NULL COMMENT '用户名',
  `password` varchar(100) DEFAULT NULL COMMENT 'h5专用的密码',
  `channel` varchar(100) DEFAULT NULL COMMENT '渠道(相同的渠道用户名不能重复，不同的渠道用户名可以重复)--（0:C#，1:浏览器，2:平台1，3:平台2 依次类推）',
  `tokenType` varchar(255) DEFAULT NULL,
  `accessToken` text COMMENT '博趣 平台 用户唯一标识',
  `expiresIn` bigint(20) DEFAULT NULL COMMENT 'token 过期时间(刷新token时 的当前时间+过期的时间段）',
  `accountId` varchar(100) DEFAULT NULL COMMENT '账号id',
  `facebookId` varchar(100) DEFAULT NULL COMMENT 'facebookid',
  `img` varchar(2000) DEFAULT '' COMMENT '图像url',
  `joinTime` bigint(20) DEFAULT NULL COMMENT '帐号创建时间',
  `lastLoginTime` bigint(20) DEFAULT NULL COMMENT '上次登陆时间',
  `role` int(11) NOT NULL DEFAULT '0' COMMENT '权限',
  `lockStatus` int(11) NOT NULL DEFAULT '0' COMMENT '锁定状态',
  `muteTime` int(11) NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `muteReason` varchar(256) DEFAULT NULL COMMENT '锁定原因',
  `phoneNum` varchar(32) DEFAULT NULL COMMENT '手机号',
  `deviceMac` varchar(50) DEFAULT NULL COMMENT '设备MAC地址',
  `twitterId` varchar(100) DEFAULT '' COMMENT 'twitterId',
  `deviceId` varchar(50) DEFAULT NULL,
  `macAddress` varchar(50) DEFAULT NULL,
  `androidId` varchar(50) DEFAULT NULL,
  `updateFbInfo` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `deviceMac` (`deviceMac`) USING BTREE,
  KEY `accountId` (`accountId`) USING BTREE,
  KEY `facebookId` (`facebookId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10003 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user_info
-- ----------------------------
INSERT INTO `t_user_info` VALUES ('1702', '1702', null, null, 'c#_client', null, null, null, '-1702', '-1', 'head_3.png', '1523620627756', '0', '0', '0', '0', '', '18675894237', 'adfadfadf675', '-1', 'localhost', null, '1234567890', '0');
INSERT INTO `t_user_info` VALUES ('1703', '1703', null, null, 'c#_client', null, null, null, '-1703', '-1', 'head_6.png', '1523848939972', '0', '2', '0', '0', '', null, 'Robot_173800879', '-1', null, null, '777', '0');
INSERT INTO `t_user_info` VALUES ('1704', '1704', null, null, 'c#_client', null, null, null, '-1704', '-1', 'head_2.png', '1523849220943', '0', '2', '0', '0', '', null, 'Robot_173800999', '-1', null, null, '777', '0');
INSERT INTO `t_user_info` VALUES ('1705', '1705', null, null, 'c#_client', null, null, null, '-1705', '-1', 'head_3.png', '1523849892007', '0', '2', '0', '0', '', null, 'Robot_173800998', '-1', null, null, '777', '0');
INSERT INTO `t_user_info` VALUES ('1706', '1706', null, null, 'c#_client', null, null, null, '-1706', '-1', 'head_9.png', '1523931762129', '0', '0', '0', '0', '', null, 'c1fc0454024a51e8d87721b2fa90712355', '-1', '868643036963435', '02:00:00:00:00:00', '96a7e927fff4773e', '0');
INSERT INTO `t_user_info` VALUES ('1707', '1707', null, null, 'c#_client', null, null, null, '-1707', '-1', 'head_8.png', '1524727943480', '0', '0', '0', '0', '', null, 'c1fc0454024a51e8d87721b2fa907123555555', '-1', '868643036963435', '02:00:00:00:00:00', '96a7e927fff4773e', '0');
INSERT INTO `t_user_info` VALUES ('1708', '1708', null, null, 'c#_client', null, null, null, '-1708', '-1', 'head_3.png', '1524728512184', '0', '0', '0', '0', '', null, 'c1fc0454024a51e8d87721b2fa90712332365', '-1', '868643036963435', '02:00:00:00:00:00', '96a7e927fff4773e', '0');
INSERT INTO `t_user_info` VALUES ('10001', '10001', null, null, 'c#_client', null, null, null, '-10001', '-1', 'head_1.png', '1524728649725', '0', '0', '0', '0', '', null, 'c1fc0454024a51e8d87721b2fa9071236565', '-1', '868643036963435', '02:00:00:00:00:00', '96a7e927fff4773e', '0');
INSERT INTO `t_user_info` VALUES ('10002', '10002', null, null, 'c#_client', null, null, null, '-10002', '-1', 'head_2.png', '1524728688067', '0', '0', '0', '0', '', null, 'c1fc0454024a51e8d87721b2fa907123', '-1', '868643036963435', '02:00:00:00:00:00', '96a7e927fff4773e', '0');

-- ----------------------------
-- Table structure for `t_user_location`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_location`;
CREATE TABLE `t_user_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户的经纬度等位置信息',
  `user_id` int(11) NOT NULL COMMENT '用户的ID',
  `country` varchar(128) DEFAULT NULL COMMENT '国家',
  `city` varchar(128) DEFAULT NULL COMMENT '城市',
  `latitude` double NOT NULL COMMENT '维度',
  `longitude` double NOT NULL COMMENT '经度',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user_location
-- ----------------------------

-- ----------------------------
-- Table structure for `t_weixin_user_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_weixin_user_info`;
CREATE TABLE `t_weixin_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `toUserName` varchar(256) DEFAULT NULL,
  `fromUserName` varchar(256) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `msgType` varchar(255) DEFAULT NULL,
  `msgContent` text,
  `msgId` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL COMMENT '是否是活跃的，1：是，0 否， 如果活跃 可以接受系统发送的模板消息，否则不接受',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_weixin_user_info
-- ----------------------------

-- ----------------------------
-- Table structure for `w_access_token`
-- ----------------------------
DROP TABLE IF EXISTS `w_access_token`;
CREATE TABLE `w_access_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) DEFAULT NULL,
  `access_token` varchar(256) DEFAULT NULL,
  `expires_in` bigint(20) DEFAULT NULL,
  `refresh_token` varchar(256) DEFAULT NULL,
  `openid` varchar(32) DEFAULT NULL,
  `scope` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of w_access_token
-- ----------------------------
